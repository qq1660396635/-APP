// 自动生成脚本变量库
// 源目录: /storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/
// 生成时间: 2025-11-16 07:38:44
// 总计: 23 个文件

var aa = {
  index: 1,
  filename: '1. 本地服务/A. 开机启动脚本（3.7版）.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/1. 本地服务/A. 开机启动脚本（3.7版）.bash',
  content: `######################### 一键安装 begin #########################
# 0. 如有旧文件先清掉（可选）
rm -f $PREFIX/2025/kw.txt $PREFIX/2025/start

# 1. 确保目录存在
mkdir -p $PREFIX/2025

# 2. 写入核心关键词
cat > $PREFIX/2025/kw.txt <<'EOF'
进程调度
内存管理
虚拟文件系统
网络子系统
中断处理
系统调用
文件描述符
缺页异常
信号量
死锁
cron
EOF

# 3. 生成 start 脚本
cat > $PREFIX/2025/start <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
while :; do
    kw=$(shuf -n 1 $PREFIX/2025/kw.txt)
    response=$(curl -s "https://baike.baidu.com/api/openapi/BaikeLemmaCardApi?scope=103&format=json&appid=379020&bk_key=$kw")
    abstract=$(echo "$response" | jq -r '.abstract // ""')
    [[ -n $abstract ]] && break
done

# 自然分段处理：将句号替换为换行，去除多余内容，每行前加两个空格
abstract=$(echo "$abstract" | sed 's/。/。\\n/g' | sed 's/\\[[0-9]*\\]//g' | sed 's/^[[:space:]]*//' | sed '/^$/d' | sed 's/^/  /')
printf "【%s】\\n%s\\n" "$kw" "$abstract"
EOF

# 4. 赋权 & 注入 .bashrc
chmod +x $PREFIX/2025/start
sed -i '\\|$PREFIX/.*/start|d' $HOME/.bashrc
echo '$PREFIX/2025/start' >> $HOME/.bashrc
######################### 一键安装 end #########################





######################### 精简关键词更新脚本 begin #########################
#!/bin/bash

# 删除旧的关键词文件
rm -f $PREFIX/2025/kw.txt

# 创建新的关键词文件，只包含5个核心术语
cat > $PREFIX/2025/kw.txt <<'EOF'
Linux内核
进程调度
内存管理
STM32
嵌入式系统
EOF

echo "关键词列表已精简更新完成！共包含 $(wc -l < $PREFIX/2025/kw.txt) 个核心术语。"
echo "下次启动Termux时将显示随机术语的百度百科摘要。"
######################### 精简关键词更新脚本 end #########################




#########################1.  脚本3 添加力扣功能 begin #########################
# 创建力扣题目文件（新格式）
cat > $PREFIX/2025/leetcode_short.txt <<'EOF'
100. Same Tree｜两棵二叉树长得一模一样吗？｜像比较两盆盆栽，先比根，再递归比左右枝｜算法思想：分治；数据结构：树
101. Symmetric Tree｜二叉树是不是左右照镜子？｜把树对折，看两边叶脉能否重叠｜算法思想：分治；数据结构：树
102. Binary Tree Level Order Traversal｜把树按楼层拍照｜用队列当电梯，一层层把人放出来合影｜算法思想：图遍历-BFS；数据结构：队列+树
103. Binary Tree Zigzag Level Order Traversal｜蛇形排队拍照｜电梯每层换方向，左→右→左→右｜算法思想：图遍历-BFS；数据结构：队列+树
104. Maximum Depth of Binary Tree｜树最高到几楼？｜从根往下扔石子，看最深溅起的水花｜算法思想：分治；数据结构：树
EOF

# 创建力扣题目随机显示脚本（新格式版）
cat > $PREFIX/2025/leetcode.sh <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
FILE="$PREFIX/2025/leetcode_short.txt"
if [ -f "$FILE" ]; then
    echo  # 换行
    echo  # 换行
    line=$(shuf -n 1 "$FILE")
    
    # 使用｜分割各个部分
    IFS='｜' read -ra parts <<< "$line"
    
    # 输出格式化内容
    echo "\${parts[0]}"  # 题目名称
    echo "  题目说明：\${parts[1]}"  # 题目人话说明
    echo "  思路说明：\${parts[2]}"  # 思路人话说明
    echo "  算法与数据结构：\${parts[3]}"  # 算法思想和数据结构
else
    echo "Leetcode file not found."
fi
EOF

# 赋予执行权限
chmod +x $PREFIX/2025/leetcode.sh

# 注入到.bashrc（只添加力扣部分）
sed -i '\\|$PREFIX/2025/leetcode.sh|d' $HOME/.bashrc
echo '$PREFIX/2025/leetcode.sh' >> $HOME/.bashrc

echo "力扣功能添加完成！重启Termux或运行 'source ~/.bashrc' 查看效果。"
######################### 添加力扣功能 end #########################






#########################1. 添加力扣功能 begin #########################
# 创建力扣题目文件（100-150题，全部使用中文）
cat > $PREFIX/2025/leetcode_short.txt <<'EOF'
100. 判断两棵二叉树是否相同｜两棵二叉树长得一模一样吗？｜像比较两盆盆栽，先比根，再递归比左右枝｜算法思想：分治；数据结构：树
101. 判断二叉树是否对称｜二叉树是不是左右照镜子？｜把树对折，看两边叶脉能否重叠｜算法思想：分治；数据结构：树
102. 二叉树的层序遍历｜把树按楼层拍照｜用队列当电梯，一层层把人放出来合影｜算法思想：图遍历-BFS；数据结构：队列+树
103. 二叉树的锯齿形层序遍历｜蛇形排队拍照｜电梯每层换方向，左→右→左→右｜算法思想：图遍历-BFS；数据结构：队列+树
104. 二叉树的最大深度｜树最高到几楼？｜从根往下扔石子，看最深溅起的水花｜算法思想：分治；数据结构：树
105. 根据前序和中序遍历序列构造二叉树｜Preorder当"骨架"，Inorder当"肉"｜像拼乐高，先放主梁，再左右插砖｜算法思想：分治；数据结构：树
106. 根据中序和后序遍历序列构造二叉树｜Postorder当"倒骨架"｜从后往前像倒着拆快递，边拆边复原｜算法思想：分治；数据结构：树
107. 二叉树的层序遍历II｜自底向上拍楼层｜把楼层照片倒序排，像翻书从最后一页看｜算法思想：图遍历-BFS；数据结构：队列+数组
108. 将有序数组转换为二叉搜索树｜把排好序的"台阶"折成平衡树｜找中间当支点，左右继续折｜算法思想：分治；数据结构：树
109. 将有序链表转换为二叉搜索树｜把有序链表折成树｜快慢指针找中点，像折纸飞机找重心｜算法思想：分治；数据结构：链表+树
110. 判断平衡二叉树｜树是不是"歪脖子"？｜检查任意子树两叉深度差≤1，像看盆景平衡｜算法思想：分治；数据结构：树
111. 二叉树的最小深度｜树最浅到根叶子几步？｜BFS找到第一个叶子即停，像迷宫最短出口｜算法思想：图遍历-BFS；数据结构：队列+树
112. 路径总和｜根到叶子有没有一条"刚好"钱数的路径？｜DFS一路扣极钱，到叶子看钱包空不空｜算法思想：图遍历-DFS；数据结构：树
113. 路径总和II｜把所有刚好花光钱的路径都记下来｜DFS走到叶子若清零，则拍照留念｜算法思想：图遍历-DFS；数据结构：树+数组
114. 二叉树展开为链表｜把树压成右斜"糖葫芦"｜后序先压左右，再把左子树挂到右下｜算法思想：图遍历-DFS；数据结构：树
115. 不同的子序列｜字符串T在S里能"跳房子"几次？｜DP跳棋盘，匹配则继承左上，否则继承上方｜算法思想：动态规划；数据结构：数组
116. 填充每个节点的下一个右侧节点指针I｜把满二叉树每层连"横丝"｜BFS队列像串珍珠，左右邻居牵手｜算法思想：图遍历-BFS；数据结构：队列+树
117. 填充每个节点的下一个右侧节点指针II｜普通二叉树也连横丝｜用"上一层的横丝"当链表，节省队列｜算法思想：图遍历-BFS；数据结构：链表+树
118. 杨辉三角｜打印杨辉三角｜每行两端放1，中间是上一行两肩相加｜算法思想：动态规划；数据结构：数组
119. 杨辉三角II｜只要第k行｜滚动数组，只存当前行，像折扇只展开一层｜算法思想：动态规划；数据结构：数组
120. 三角形最小路径和｜从三角塔顶往下走，和最小？｜自底向上DP，像叠积木，每层选便宜底座｜算法思想：动态规划；数据结构：数组
121. 买卖股票的最佳时机｜低买高卖一次，最大差？｜一次遍历，记录历史最低，今天卖能赚多少｜算法思想：贪心；数据结构：数组
122. 买卖股票的最佳时机II｜可以多次买卖，当天可卖再买｜只要明天比今天贵就今天买明天卖，像"搬砖套利"｜算法思想：贪心；数据结构：数组
123. 买卖股票的最佳时机III｜最多两次交易｜DP四状态：第一次买、卖、第二次买、卖，像两条心跳曲线｜算法思想：动态规划；数据结构：数组
124. 二叉树中的最大路径和｜二叉树任意路径最大和｜后序遍历，左右子树贡献正数，像"树枝快递"只送不亏本的｜算法思想：分治；数据结构：树
125. 验证回文串｜过滤后是否回文？｜双指针从两头往中间夹，像吃甘蔗剥叶子｜算法思想：双指针；数据结构：数组
126. 单词接龙II｜字典里变单词，最短所有路径｜BFS建图+DFS回溯，像地铁换乘所有最短路线｜算法思想：图遍历+回溯；数据结构：图+队列
127. 单词接龙｜只想要最短长度｜单向/双向BFS，像两束激光对射碰头｜算法思想：图遍历-BFS；数据结构：队列+哈希表
128. 最长连续序列｜无序数组最长连续数列｜哈希表当"抽屉"，先全放再O(n)找每个数列开头｜算法思想：哈希；数据结构：哈希表
129. 求根节点到叶节点数字之和｜根到叶子路径数字和｜DFS一路拼数字，到叶子加总，像"拨号盘"累计｜算法思想：图遍历-DFS；数据结构：树
130. 被围绕的区域｜棋盘边界O不会包围的X才变O｜先DFS边界O做"救生圈"，再扫描中间沉的｜算法思想：图遍历-DFS；数据结构：数组
131. 分割回文串｜把字符串切成每块都是回文｜回溯+DP预处理回文，像切蛋糕先画虚线｜算法思想：回溯；数据结构：数组
132. 分割回文串II｜最少切几刀能全回文｜DP：若s[i..j]回文则dp[j]=min(dp[j],dp[i-1]+1)｜算法思想：动态规划；数据结构：数组
133. 克隆图｜深度拷贝无向图｜DFS/BFS+哈希"影印"节点，像复印机边翻页边影印｜算法思想：图遍历；数据结构：图+哈希表
134. 加油站｜环形路油站能否跑一圈｜总油≥总耗即可，起点找"亏空"后一站，像接力棒找起跑点｜算法思想：贪心；数据结构：数组
135. 分发糖果｜分糖果，评分高的比邻居多｜两遍贪心：左→右保证右邻居，右→左保证左邻居｜算法思想：贪心；数据结构：数组
136. 只出现一次的数字｜众数成双，落单是谁？｜全员异或，相同归零，落单现身｜算法思想：数学位运算；数据结构：数组
137. 只出现一次的数字II｜三个数成对，落单是谁？｜位计数模3，像"三进制"里找余1位｜算法思想：数学位运算；数据结构：数组
138. 复制带随机指针的链表｜链表带随机指针深拷贝｜第一次串next并建哈希，第二次补random，像先搭骨架再连神经｜算法思想：哈希；数据结构：链表+哈希表
139. 单词拆分｜字典能否拼出字符串？｜DP：s[0..i]可拼当存在j<i且s[j+1..i]在字典｜算法思想：动态规划；数据结构：数组+哈希表
140. 单词拆分II｜拼法所有句子｜DP预处理可行+回溯拼句子，像先筛乐高底座再搭造型｜算法思想：动态规划+回溯；数据结构：数组+哈希表
141. 环形链表｜链表有环吗？｜快慢指针，像跑道套圈，相遇则有环｜算法思想：双指针；数据结构：链表
142. 环形链表II｜环起点在哪？｜快慢相遇后，慢回头到起点，再同步走到环口｜算法思想：双指针；数据结构：链表
143. 重排链表｜链表L0→Ln→L1→Ln-1…重排｜找中点+反转后半+合并，像折扇收拢再穿插｜算法思想：分治+链表操作；数据结构：链表
144. 二叉树的前序遍历｜根左右顺序输出｜递归/迭代栈，像探险先插旗再探左右｜算法思想：图遍历-DFS；数据结构：树+栈
145. 二叉树的后序遍历｜左右根顺序输出｜递归/迭代，像清理战场先清左右再汇报｜算法思想：图遍历-DFS；数据结构：树+栈
146. LRU缓存｜最近最少用缓存｜哈希+双向链表，像书架+便签，用完放最前，满时扔末尾｜算法思想：哈希+链表；数据结构：哈希表+双向链表
147. 对链表进行插入排序｜链表插入排序｜断链重插，像打扑克摸一张插一张｜算法思想：暴力枚举；数据结构：链表
148. 排序链表｜链表归并排序｜快慢找中点+归并，像把珍珠链先掰半再合并｜算法思想：分治；数据结构：链表
149. 直线上最多的点数｜平面上最多点共线｜对每点极角排序，滑动窗口数同斜率，像雷达扫射｜算法思想：暴力枚举+哈希；数据结构：数组+哈希表
150. 逆波兰表达式求值｜后缀表达式求值｜栈当"算盘"，遇数压栈，遇符弹两数算完压回｜算法思想：栈；数据结构：栈
EOF

# 创建力扣题目随机显示脚本
cat > $PREFIX/2025/leetcode.sh <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
FILE="$PREFIX/2025/leetcode_short.txt"
if [ -f "$FILE" ]; then
    echo
    echo
    line=$(shuf -n 1 "$FILE")
    IFS='｜' read -ra parts <<< "$line"
    echo "【\${parts[0]}】"
    echo "题目说明：\${parts[1]}"
    echo "思路说明：\${parts[2]}"
    echo "算法与数据结构：\${parts[3]}"
else
    echo "Leetcode file not found."
fi
EOF

# 赋予执行权限
chmod +x $PREFIX/2025/leetcode.sh

# 注入到.bashrc（只添加力扣部分）
sed -i '\\|$PREFIX/2025/leetcode.sh|d' $HOME/.bashrc
echo '$PREFIX/2025/leetcode.sh' >> $HOME/.bashrc

echo "力扣功能添加完成！重启Termux或运行 'source ~/.bashrc' 查看效果。"
######################### 添加力扣功能 end #########################`,
  type: 'bash',
  varName: 'aa',
  size: 6916
};
var ab = {
  index: 2,
  filename: '1. 本地服务/A. 猜数字（获取输入）.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/1. 本地服务/A. 猜数字（获取输入）.bash',
  content: `#!/data/data/com.termux/files/usr/bin/bash
# Termux猜数字游戏
# 作者：根据你的需求定制
# L.说明 ，后续可自行拓展。猜老师，猜对跳转网址。自己刷题，100道等

echo "🎯 欢迎来到Termux猜数字游戏！"
echo "================================"

# 生成1-100之间的随机数
target=$(( RANDOM % 100 + 1 ))
attempts=0
max_attempts=10

echo "我已经想了一个1到100之间的神秘数字。"
echo "你有 $max_attempts 次机会猜中它！"
echo ""

while [ $attempts -lt $max_attempts ]; do
    remaining=$((max_attempts - attempts))
    echo "📊 你还剩 $remaining 次机会"
    read -p "请输入你猜的数字（1-100）: " guess
    
    # 检查输入是否为数字
    if ! [[ "$guess" =~ ^[0-9]+$ ]]; then
        echo "❌ 请输入有效的数字！"
        continue
    fi
    
    guess=$((guess))
    attempts=$((attempts + 1))
    
    if [ $guess -eq $target ]; then
        echo "🎉 恭喜你！猜对了！"
        echo "✅ 你用了 $attempts 次猜中了数字 $target"
        break
    elif [ $guess -lt $target ]; then
        echo "📈 太小了！往大点猜。"
    else
        echo "📉 太大了！往小点猜。"
    fi
    
    # 给出提示
    difference=$((guess - target))
    if [ \${difference#-} -le 5 ]; then
        echo "🔥 非常接近了！"
    elif [ \${difference#-} -le 15 ]; then
        echo "💡 有点接近了！"
    fi
    echo ""
done

if [ $attempts -eq $max_attempts ] && [ $guess -ne $target ]; then
    echo "💀 游戏结束！数字是 $target"
    echo "💡 下次运气会更好！"
fi

echo ""
echo "感谢游玩！"
`,
  type: 'bash',
  varName: 'ab',
  size: 1231
};
var ac = {
  index: 3,
  filename: '1. 本地服务/B.  91学习视频转PDF.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/1. 本地服务/B.  91学习视频转PDF.bash',
  content: `一  需求分析
1. 需求：视频转PDF工具，我们家下载的91学习视频「1991年数学视频」，转PDF

2. 功能：将视频文件每隔10秒提取一帧图片，合并生成PDF文档

3. 执行流程：
   1. ffmpeg按时间间隔提取视频帧为JPG图片
   2. ImageMagick将图片序列合并为PDF文件
   3. 清理临时文件并输出结果
   
二   代码 
 #!/data/data/com.termux/files/usr/bin/bash
# 设置路径
INPUT_VIDEO="/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/2025-ouikk-4.mp4"
OUTPUT_DIR="$(dirname "$INPUT_VIDEO")/temp_frames"
PDF_OUTPUT="\${INPUT_VIDEO%.mp4}.pdf"

echo "开始处理视频: $INPUT_VIDEO"
echo "输出目录: $OUTPUT_DIR"
echo "PDF输出: $PDF_OUTPUT"

# 创建临时目录
mkdir -p "$OUTPUT_DIR"
cd "$(dirname "$INPUT_VIDEO")"

# 提取帧（每10秒一帧）
echo "正在提取视频帧..."
ffmpeg -v error -i "$INPUT_VIDEO" -vf "fps=1/10" -q:v 2 "temp_frames/frame_%04d.jpg"

# 检查提取结果
FRAME_COUNT=$(ls "$OUTPUT_DIR"/*.jpg 2>/dev/null | wc -l)
if [ $FRAME_COUNT -eq 0 ]; then
    echo "❌ 错误：未提取到任何帧！"
    echo "可能原因："
    echo "1. 输入视频路径不正确"
    echo "2. ffmpeg未正确安装"
    echo "3. 视频格式不支持"
    exit 1
else
    echo "✅ 成功提取 $FRAME_COUNT 帧图像"
fi

# 合并为PDF
echo "正在合并帧为PDF..."
cd "temp_frames"
mapfile -t FRAMES < <(ls *.jpg 2>/dev/null | sort)
magick "\${FRAMES[@]}" "$PDF_OUTPUT"

# 清理
cd ..
rm -rf "temp_frames"

echo "✅ PDF合并完成: $PDF_OUTPUT"
echo "✅ 文件大小: $(du -h "$PDF_OUTPUT" | cut -f1)"
`,
  type: 'bash',
  varName: 'ac',
  size: 1195
};
var ad = {
  index: 4,
  filename: '1. 本地服务/B. 加密91学习视频.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/1. 本地服务/B. 加密91学习视频.bash',
  content: `需求，还在担心视频被百度网盘迅雷封杀吗？

脚本01  加密91视频 ，全部MP4转TXT
#!/data/data/com.termux/files/usr/bin/bash
cd "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/02 不可描述/A" || exit 1
find . -type f -iname '*.mp4' -exec sh -c 'mv "$1" "\${1%.mp4}.txt"' _ {} \\;



脚本02  解密91视频，全部TXT转MP4
#!/data/data/com.termux/files/usr/bin/bash
cd "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/02 不可描述/A" || exit 1
find . -type f -iname '*.txt' -exec sh -c 'mv "$1" "\${1%.txt}.mp4"' _ {} \\;
`,
  type: 'bash',
  varName: 'ad',
  size: 486
};
var ae = {
  index: 5,
  filename: '2. 网络爬取/3.  判断91视频是否失效.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/2. 网络爬取/3.  判断91视频是否失效.bash',
  content: ` # 判断视频是否失效，，，或者扫描端口下的资源。
base="https:视频链接"
outdir="/storage/emulated/0/Download/OnePlus Share"
outfile="$outdir/scan_result.txt"
mkdir -p "$outdir"; >"$outfile"

for ((i=87000;i<=87200;i++)); do
  url="$base/$i/index.m3u8"
  # 发 GET，只拉 1k 字节，带跳转
  resp=$(curl -s -r 0-1023 -L --max-time 5 "$url")
  # 简单判断：返回里出现 #EXTM3U 就说明是合法 m3u8
  if grep -q "^#EXTM3U" <<<"$resp"; then
    echo "[OK]  $url" | tee -a "$outfile"
  else
    echo "[404] $url" >> "$outfile"
  fi
done
echo "扫描完成，结果已保存到：$outfile"`,
  type: 'bash',
  varName: 'ae',
  size: 496
};
var af = {
  index: 6,
  filename: '2. 网络爬取/3. 爬取91 学习资料网站.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/2. 网络爬取/3. 爬取91 学习资料网站.bash',
  content: `需求    爬取91视频 学习网站
修改    输入地址。保存目录地址。  「视频地址可以在源码中获得。」
未完成  没有针对下载速度优化，没有对观看限额进行优化，   没有更换公网IP，换源等

一.  源码
ffmpeg -loglevel error -stats -progress pipe:1 \\
  -user_agent "Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36" \\
  -i "视频网站地址，18＋教学视频，未成年人不可观看「输入你自己的地址💊💊💊」" \\
  -c copy \\
  "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/2025-ouikk-4.mp4" 2>&1 | \\
awk -F'=' '/^progress=end/ {print; fflush(); exit}
           /^progress=/    {print; fflush()}
           /^size=|^time=/ {printf "%s  ", $0; fflush()}' | \\
while read -r line; do echo "$(date '+%H:%M:%S')  $line"; sleep 10; done


二.   代码解析
ffmpeg -loglevel error -stats -progress pipe:1 \\
# ffmpeg: 多媒体处理工具
# -loglevel error: 只显示错误日志（error级别）
# -stats: 显示编码统计信息
# -progress pipe:1: 将进度信息输出到标准输出（管道1）
# \\: 行续接符，表示命令继续到下一行

  -user_agent "Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36" \\
  # -user_agent: 设置HTTP请求的User-Agent头部
  # "Mozilla/...": 模拟Android设备的浏览器标识
  # \\: 行续接符

  -i "视频网站地址，18＋教学视频，未成年人不可观看「输入你自己的地址💊💊💊    " \\
  # -i: 指定输入文件/URL
  # "https://...": HLS视频流的m3u8索引文件地址
  # \\: 行续接符

  -c copy \\
  # -c copy: 流复制模式（不重新编码，直接复制原始流）
  # \\: 行续接符

  "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/2025-ouikk-4.mp4" 2>&1 | \\
  # 输出文件路径（Android设备存储路径）
  # 2>&1: 将标准错误(stderr)重定向到标准输出(stdout)
  # |: 管道符，将前命令输出作为后命令输入

awk -F'=' '/^progress=end/ {print; fflush(); exit}
           # awk: 文本处理工具
           # -F'=': 设置字段分隔符为等号(=)
           # /^progress=end/: 匹配以"progress=end"开头的行
           # {print; fflush(); exit}: 打印该行，立即刷新缓冲区，然后退出awk

           /^progress=/    {print; fflush()}
           # /^progress=/: 匹配以"progress="开头的行（不含end）
           # {print; fflush()}: 打印该行并刷新缓冲区

           /^size=|^time=/ {printf "%s  ", $0; fflush()}' | \\
           # /^size=|^time=/: 匹配以"size="或"time="开头的行
           # {printf "%s  ", $0}: 打印整行内容（末尾加两个空格）
           # fflush(): 立即刷新输出缓冲区
           # |: 管道符

while read -r line; do echo "$(date '+%H:%M:%S')  $line"; sleep 10; done
# while read -r line: 逐行读取输入（-r防止反斜杠转义）
# do...done: 循环体开始/结束
# echo "$(date '+%H:%M:%S')  $line": 打印当前时间(时:分:秒) + 行内容
# sleep 10: 每次循环暂停10秒（控制输出频率）

`,
  type: 'bash',
  varName: 'af',
  size: 2146
};
var ag = {
  index: 7,
  filename: '2. 网络爬取/4. 扫描端口并下载91学习视频 .bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/2. 网络爬取/4. 扫描端口并下载91学习视频 .bash',
  content: `#!/data/data/com.termux/files/usr/bin/bash
# -*- coding: utf-8 -*-
# 87000 固定，87100-87200 随到随下
# 单线程 + 极简提示 + 跳过 >500 MB 文件

BASE_URL="https://视频地址🔗🔗🔗/87000"
START_ID=87100
END_ID=87200
SAVE_ROOT="/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/02 不可描述"
UA="Mozilla/5.0 (Linux; Android 13; SM-G973F) AppleWebKit/537.36"

mkdir -p "$SAVE_ROOT"

#---- 1-2 秒快速估算大小 ----
get_size_mb(){
  local m3u8="$1"
  seg=$(curl -sL -H "User-Agent: $UA" "$m3u8" | sed -n '/^[^#]/p' | head -1)
  [ -z "$seg" ] && { echo 0; return; }
  seg_url=$(dirname "$m3u8")/$seg

  # 拿 bitrate，失败就给 1 Mbps
  br=$(curl -sL -r 0-1023 -H "User-Agent: $UA" "$seg_url" \\
       | ffprobe -v error -show_entries format=bit_rate -of csv=p=0 - 2>/dev/null)
  case "$br" in ''|*[!0-9]*) br=1000000 ;; esac

  # 拿总时长，失败给 0
  dur=$(curl -sL -H "User-Agent: $UA" "$m3u8" \\
        | awk -F: '/^#EXTINF:/{s+=$2} END{printf "%.0f",s}')
  [ -z "$dur" ] && dur=0

  echo $(( br * dur / 8 / 1024 / 1024 ))
}

for id in $(seq "$START_ID" "$END_ID"); do
  m3u8_url="$BASE_URL/$id/index.m3u8"

  curl -s -r 0-1023 -L --max-time 5 -H "User-Agent: $UA" "$m3u8_url" | grep -q "^#EXTM3U" || {
    echo "[跳过] $id  无法获取 m3u8"; continue
  }

  folder_start=$((START_ID + ((id - START_ID) / 20) * 20))
  folder="$SAVE_ROOT/\${folder_start}-$((folder_start+19))"
  mkdir -p "$folder"
  out="$folder/$id.mp4"
  [ -f "$out" ] && { echo "[存在] $id.mp4"; continue; }

  echo "[探测] $id  估算大小中..."
  size_mb=$(get_size_mb "$m3u8_url")
  [ "$size_mb" -gt 500 ] && {
    echo "[跳过] $id  估算 \${size_mb}MB (>500MB)"; continue
  }

  echo "[下载] $id  估算 \${size_mb}MB → $out"
  ffmpeg -hide_banner -loglevel error -nostats -nostdin -y \\
    -user_agent "$UA" -i "$m3u8_url" -c copy "$out" && \\
    echo "[完成] $id.mp4" || echo "[失败] $id.mp4"
done

echo ">>> 全部结束！"
`,
  type: 'bash',
  varName: 'ag',
  size: 1805
};
var ah = {
  index: 8,
  filename: '3. 项目分析/4. ctags分析文件并美化.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/4. ctags分析文件并美化.bash',
  content: `f="/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/[9] GPIO输出与点灯/Core/Src/main.c"
ctags --output-format=json --fields=+KnzSst --kinds-c=+cdefglmnpstuvxL --extras=+qF "$f" 2>/dev/null |
jq -r 'select(.name|startswith("__anon")|not) | (.kind+"\\t"+.name+"\\t"+(.scope//"-")+"\\t"+(.line|tostring)+"\\t"+(.static//"no"))' |
awk -v f="$f" '
BEGIN{
  print "┌────────────────────────────────────────────────────────────┐"
  print "│                    符号分析报告                           │"
  print "├────────────────────────────────────────────────────────────┤"
  print "│ 文件: " f
  print "├────────────────────────────────────────────────────────────┤"
}
# 1. 函数原型放最上
$1=="prototype" {prototypes[++pcount] = $0; next}
# 2. 其余所有函数定义（全局可见）都归到"全局函数"
$1=="function" && $3=="-" {functions[++fcount] = $0; next}
# 3. 变量/局部量/结构体等保持原样
$1=="macro"   {macros[++mcount] = $0; next}
$1=="struct"  {structs[++scount] = $0; next}
$1=="union"   {unions[++ucount] = $0; next}
$1=="enum"    {enums[++ecount] = $0; next}
$1=="enumerator"{enumerators[++evcount] = $0; next}
$1=="typedef" {typedefs[++tcount] = $0; next}
$1=="variable"&&$5=="yes"&&$3=="-"{static_globals[++sgcount] = $0; next}
$1=="variable"&&$5=="no"&&$3=="-" {globals[++gcount] = $0; next}
$1=="local"   {locals[++lcount] = $0; next}
END{
  # 先输出函数原型
  if (pcount > 0) {
    print "│"
    print "│ [函数原型]"
    for (i=1; i<=pcount; i++) {
      split(prototypes[i], parts, "\\t")
      printf "│   %-40s (原型)\\n", parts[2]
    }
  }
  
  # 然后输出全局函数
  if (fcount > 0) {
    print "│"
    print "│ [全局函数]"
    for (i=1; i<=fcount; i++) {
      split(functions[i], parts, "\\t")
      printf "│   %-40s (函数)\\n", parts[2]
    }
  }
  
  # 输出其他部分
  if (mcount > 0) {
    print "│"
    print "│ [宏定义]"
    for (i=1; i<=mcount; i++) {
      split(macros[i], parts, "\\t")
      printf "│   %-40s (宏)\\n", parts[2]
    }
  }
  if (scount > 0) {
    print "│"
    print "│ [结构体]"
    for (i=1; i<=scount; i++) {
      split(structs[i], parts, "\\t")
      printf "│   %-40s (结构体)\\n", parts[2]
    }
  }
  if (ucount > 0) {
    print "│"
    print "│ [联合体]"
    for (i=1; i<=ucount; i++) {
      split(unions[i], parts, "\\t")
      printf "│   %-40s (联合体)\\n", parts[2]
    }
  }
  if (ecount > 0) {
    print "│"
    print "│ [枚举类型]"
    for (i=1; i<=ecount; i++) {
      split(enums[i], parts, "\\t")
      printf "│   %-40s (枚举)\\n", parts[2]
    }
  }
  if (evcount > 0) {
    print "│"
    print "│ [枚举值]"
    for (i=1; i<=evcount; i++) {
      split(enumerators[i], parts, "\\t")
      printf "│   %-40s (枚举值)\\n", parts[2]
    }
  }
  if (tcount > 0) {
    print "│"
    print "│ [类型定义]"
    for (i=1; i<=tcount; i++) {
      split(typedefs[i], parts, "\\t")
      printf "│   %-40s (typedef)\\n", parts[2]
    }
  }
  if (sgcount > 0) {
    print "│"
    print "│ [静态全局变量]"
    for (i=1; i<=sgcount; i++) {
      split(static_globals[i], parts, "\\t")
      printf "│   %-40s (static 全局)\\n", parts[2]
    }
  }
  if (gcount > 0) {
    print "│"
    print "│ [全局变量]"
    for (i=1; i<=gcount; i++) {
      split(globals[i], parts, "\\t")
      printf "│   %-40s (全局)\\n", parts[2]
    }
  }
  if (lcount > 0) {
    print "│"
    print "│ [局部变量]"
    for (i=1; i<=lcount; i++) {
      split(locals[i], parts, "\\t")
      printf "│   %-40s (局部，位于: %s)\\n", parts[2], parts[3]
    }
  }
  print "└────────────────────────────────────────────────────────────┘"
  print "符号分析完成。"
}'
`,
  type: 'bash',
  varName: 'ah',
  size: 3415
};
var ai = {
  index: 9,
  filename: '3. 项目分析/5. ctags分析文件并美化（单模块）常用.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/5. ctags分析文件并美化（单模块）常用.bash',
  content: `TARGET_DIR="/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/[9] GPIO输出与点灯/Core"
REPORT="$TARGET_DIR/文件分析报告.txt"

# 报告头
{
  echo "文件分析报告"
  echo "生成时间: $(date)"
  echo "========================================================="
  echo ""
} > "$REPORT"

# 逐个文件分析
find "$TARGET_DIR" -type f \\( -name '*.c' -o -name '*.h' \\) | sort -V | nl -w1 -s'. ' | while read -r idx f; do
  # 只保留最后三级目录
  short=$(echo "$f" | sed -E 's|.*(/[^/]+/[^/]+/[^/]+/[^/]+)$|\\1|')
  {
    echo ""
    echo "🟢 $idx $(basename "$f")"
    echo "🔻🔻🔻🔻🔻🔻🔻"
    echo "📁 $short"
    echo "┌────────────────────────────────────────────────────────────┐"
    echo "│                    文件分析                               │"
    echo "├────────────────────────────────────────────────────────────┤"
    echo "│ 文件: $short"
    echo "├────────────────────────────────────────────────────────────┤"

    # 以下完全沿用你最开始那套 json 流水线
    ctags --output-format=json --fields=+KnzSst --kinds-c=+cdefglmnpstuvxL --extras=+qF "$f" 2>/dev/null |
    jq -r 'select(.name|startswith("__anon")|not) | (.kind+"\\t"+.name+"\\t"+(.scope//"-")+"\\t"+(.line|tostring)+"\\t"+(.static//"no"))' |
    awk '
    $1=="prototype" {prototypes[++pcount] = $0; next}
    $1=="function" && $3=="-" {functions[++fcount] = $0; next}
    $1=="macro"   {macros[++mcount] = $0; next}
    $1=="struct"  {structs[++scount] = $0; next}
    $1=="union"   {unions[++ucount] = $0; next}
    $1=="enum"    {enums[++ecount] = $0; next}
    $1=="enumerator"{enumerators[++evcount] = $0; next}
    $1=="typedef" {typedefs[++tcount] = $0; next}
    $1=="variable"&&$5=="yes"&&$3=="-"{static_globals[++sgcount] = $0; next}
    $1=="variable"&&$5=="no"&&$3=="-" {globals[++gcount] = $0; next}
    $1=="local"   {locals[++lcount] = $0; next}
    END{
      if (pcount > 0) {
        print "│"; print "│ [函数原型]"
        for (i=1; i<=pcount; i++) {split(prototypes[i], parts, "\\t"); printf "│   %-40s (原型)\\n", parts[2]}
      }
      if (fcount > 0) {
        print "│"; print "│ [全局函数]"
        for (i=1; i<=fcount; i++) {split(functions[i], parts, "\\t"); printf "│   %-40s (函数)\\n", parts[2]}
      }
      if (mcount > 0) {
        print "│"; print "│ [宏定义]"
        for (i=1; i<=mcount; i++) {split(macros[i], parts, "\\t"); printf "│   %-40s (宏)\\n", parts[2]}
      }
      if (scount > 0) {
        print "│"; print "│ [结构体]"
        for (i=1; i<=scount; i++) {split(structs[i], parts, "\\t"); printf "│   %-40s (结构体)\\n", parts[2]}
      }
      if (ucount > 0) {
        print "│"; print "│ [联合体]"
        for (i=1; i<=ucount; i++) {split(unions[i], parts, "\\t"); printf "│   %-40s (联合体)\\n", parts[2]}
      }
      if (ecount > 0) {
        print "│"; print "│ [枚举类型]"
        for (i=1; i<=ecount; i++) {split(enums[i], parts, "\\t"); printf "│   %-40s (枚举)\\n", parts[2]}
      }
      if (evcount > 0) {
        print "│"; print "│ [枚举值]"
        for (i=1; i<=evcount; i++) {split(enumerators[i], parts, "\\t"); printf "│   %-40s (枚举值)\\n", parts[2]}
      }
      if (tcount > 0) {
        print "│"; print "│ [类型定义]"
        for (i=1; i<=tcount; i++) {split(typedefs[i], parts, "\\t"); printf "│   %-40s (typedef)\\n", parts[2]}
      }
      if (sgcount > 0) {
        print "│"; print "│ [静态全局变量]"
        for (i=1; i<=sgcount; i++) {split(static_globals[i], parts, "\\t"); printf "│   %-40s (static 全局)\\n", parts[2]}
      }
      if (gcount > 0) {
        print "│"; print "│ [全局变量]"
        for (i=1; i<=gcount; i++) {split(globals[i], parts, "\\t"); printf "│   %-40s (全局)\\n", parts[2]}
      }
      if (lcount > 0) {
        print "│"; print "│ [局部变量]"
        for (i=1; i<=lcount; i++) {split(locals[i], parts, "\\t"); printf "│   %-40s (局部，位于: %s)\\n", parts[2], parts[3]}
      }
      print "└────────────────────────────────────────────────────────────┘"
      print ""
      print "========================================================="
    }'
  } >> "$REPORT"
done

echo "分析完成！报告已保存到：$REPORT"
`,
  type: 'bash',
  varName: 'ai',
  size: 3937
};
var aj = {
  index: 10,
  filename: '3. 项目分析/6. 野火小智项目分析（API）.bash',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/6. 野火小智项目分析（API）.bash',
  content: `下面这段 直接复制进 Termux 回车即可跑：
1. 一次性扫描
 /storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/ 
下 所有 项目文件夹（不管编号是多少）：
 
如果目录里有  Core  → 扫  Core 
 
如果目录里有  User  → 扫  User 
 
如果目录里有  APP  → 扫  APP 

2. 每个项目生成一份 独立报告，文件名就是 项目文件夹名字.txt，统一放到：
 /storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/项目分析报告/ 
 
3. 路径只保留最后三级，报告格式和你刚才 最满意的那版完全一致。

# 一次性复制即可
BASE="/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档"
OUT_DIR="$BASE/项目分析报告"
mkdir -p "$OUT_DIR"

# 遍历所有项目文件夹
find "$BASE" -maxdepth 1 -type d ! -path "$BASE" | while read -r proj; do
  proj_name=$(basename "$proj")
  report_file="$OUT_DIR/\${proj_name}.txt"

  # 决定到底扫哪个子目录
  if   [ -d "$proj/Core" ]; then SCAN_DIR="$proj/Core"
  elif [ -d "$proj/User" ]; then SCAN_DIR="$proj/User"
  elif [ -d "$proj/APP"  ]; then SCAN_DIR="$proj/APP"
  else continue; fi

  # 写报告头
  {
    echo "文件分析报告"
    echo "生成时间: $(date)"
    echo "========================================================="
    echo ""
  } > "$report_file"

  # 逐个文件分析
  find "$SCAN_DIR" -type f \\( -name '*.c' -o -name '*.h' \\) | sort -V | nl -w1 -s'. ' | while read -r idx f; do
    short=$(echo "$f" | sed -E 's|.*(/[^/]+/[^/]+/[^/]+/[^/]+)$|\\1|')
    {
      echo ""
      echo "🟢 $idx $(basename "$f")"
      echo "🔻🔻🔻🔻🔻🔻🔻"
      echo "📁 $short"
      echo "┌────────────────────────────────────────────────────────────┐"
      echo "│                    文件分析                               │"
      echo "├────────────────────────────────────────────────────────────┤"
      echo "│ 文件: $short"
      echo "├────────────────────────────────────────────────────────────┤"

      ctags --output-format=json --fields=+KnzSst --kinds-c=+cdefglmnpstuvxL --extras=+qF "$f" 2>/dev/null |
      jq -r 'select(.name|startswith("__anon")|not) | (.kind+"\\t"+.name+"\\t"+(.scope//"-")+"\\t"+(.line|tostring)+"\\t"+(.static//"no"))' |
      awk '
      $1=="prototype" {prototypes[++pcount] = $0; next}
      $1=="function" && $3=="-" {functions[++fcount] = $0; next}
      $1=="macro"   {macros[++mcount] = $0; next}
      $1=="struct"  {structs[++scount] = $0; next}
      $1=="union"   {unions[++ucount] = $0; next}
      $1=="enum"    {enums[++ecount] = $0; next}
      $1=="enumerator"{enumerators[++evcount] = $0; next}
      $1=="typedef" {typedefs[++tcount] = $0; next}
      $1=="variable"&&$5=="yes"&&$3=="-"{static_globals[++sgcount] = $0; next}
      $1=="variable"&&$5=="no"&&$3=="-" {globals[++gcount] = $0; next}
      $1=="local"   {locals[++lcount] = $0; next}
      END{
        if (pcount > 0) {
          print "│"; print "│ [函数原型]"
          for (i=1; i<=pcount; i++) {split(prototypes[i], parts, "\\t"); printf "│   %-40s (原型)\\n", parts[2]}
        }
        if (fcount > 0) {
          print "│"; print "│ [全局函数]"
          for (i=1; i<=fcount; i++) {split(functions[i], parts, "\\t"); printf "│   %-40s (函数)\\n", parts[2]}
        }
        if (mcount > 0) {
          print "│"; print "│ [宏定义]"
          for (i=1; i<=mcount; i++) {split(macros[i], parts, "\\t"); printf "│   %-40s (宏)\\n", parts[2]}
        }
        if (scount > 0) {
          print "│"; print "│ [结构体]"
          for (i=1; i<=scount; i++) {split(structs[i], parts, "\\t"); printf "│   %-40s (结构体)\\n", parts[2]}
        }
        if (ucount > 0) {
          print "│"; print "│ [联合体]"
          for (i=1; i<=ucount; i++) {split(unions[i], parts, "\\t"); printf "│   %-40s (联合体)\\n", parts[2]}
        }
        if (ecount > 0) {
          print "│"; print "│ [枚举类型]"
          for (i=1; i<=ecount; i++) {split(enums[i], parts, "\\t"); printf "│   %-40s (枚举)\\n", parts[2]}
        }
        if (evcount > 0) {
          print "│"; print "│ [枚举值]"
          for (i=1; i<=evcount; i++) {split(enumerators[i], parts, "\\t"); printf "│   %-40s (枚举值)\\n", parts[2]}
        }
        if (tcount > 0) {
          print "│"; print "│ [类型定义]"
          for (i=1; i<=tcount; i++) {split(typedefs[i], parts, "\\t"); printf "│   %-40s (typedef)\\n", parts[2]}
        }
        if (sgcount > 0) {
          print "│"; print "│ [静态全局变量]"
          for (i=1; i<=sgcount; i++) {split(static_globals[i], parts, "\\t"); printf "│   %-40s (static 全局)\\n", parts[2]}
        }
        if (gcount > 0) {
          print "│"; print "│ [全局变量]"
          for (i=1; i<=gcount; i++) {split(globals[i], parts, "\\t"); printf "│   %-40s (全局)\\n", parts[2]}
        }
        if (lcount > 0) {
          print "│"; print "│ [局部变量]"
          for (i=1; i<=lcount; i++) {split(locals[i], parts, "\\t"); printf "│   %-40s (局部，位于: %s)\\n", parts[2], parts[3]}
        }
        print "└────────────────────────────────────────────────────────────┘"
        print ""
        print "========================================================="
      }'
    } >> "$report_file"
  done
done

echo "全部完成！报告已集中放到：$OUT_DIR"
`,
  type: 'bash',
  varName: 'aj',
  size: 4798
};
var ak = {
  index: 11,
  filename: '1. 本地服务/A. 手机跑简易服务器.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/1. 本地服务/A. 手机跑简易服务器.py',
  content: `需求，手机启动服务器。并且可以在网站中链接这个服务器

一  代码部分
python3 -x <<'EOF'
# -*- coding: utf-8 -*-
from http.server import HTTPServer, BaseHTTPRequestHandler as RH

class H(RH):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write('<html><meta charset=utf-8><body><h1>你好世界</h1></body></html>'.encode('utf-8'))

HTTPServer(('', 8080), H).serve_forever()
EOF


二 访问网站
http://127.0.0.1:8080


三  简单优化，可双向通信
python3 -x <<'EOF'
# -*- coding: utf-8 -*-
import json
import socket
import subprocess
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
import threading

# 全局消息队列和锁
message_queue = []
queue_lock = threading.Lock()

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """支持多线程的HTTP服务器"""

class RequestHandler(BaseHTTPRequestHandler):
    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html; charset=utf-8')
        self.end_headers()
    
    def do_GET(self):
        if self.path == '/':
            self._set_headers()
            self.wfile.write(self._create_html().encode('utf-8'))
        elif self.path == '/messages':
            self._handle_messages()
        elif self.path == '/ip':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            # 获取热点IP地址
            hotspot_ip = self.get_hotspot_ip()
            self.wfile.write(json.dumps({"ip": hotspot_ip}).encode('utf-8'))
        else:
            self.send_error(404)
    
    def do_POST(self):
        if self.path == '/send':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            self._process_message(post_data)
            self._set_headers()
            self.wfile.write(b'Message received')
        else:
            self.send_error(404)
    
    def get_hotspot_ip(self):
        """获取手机热点IP地址"""
        try:
            # 尝试获取wlan0接口的IP（热点接口）
            result = subprocess.run(['ip', 'addr', 'show', 'wlan0'], capture_output=True, text=True)
            if result.returncode == 0:
                # 查找IPv4地址
                import re
                ip_match = re.search(r'inet (\\d+\\.\\d+\\.\\d+\\.\\d+)/', result.stdout)
                if ip_match:
                    return ip_match.group(1)
            
            # 如果wlan0没有IP，尝试其他方法
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect(("8.8.8.8", 80))
                return s.getsockname()[0]
            finally:
                s.close()
        except:
            return "无法获取IP"
    
    def _process_message(self, data):
        try:
            message = json.loads(data.decode('utf-8'))['message']
            with queue_lock:
                message_queue.append(message)
            print(f"\\n\\033[1;35m收到消息: \\033[1;36m{message}\\033[0m")
        except:
            print("\\n\\033[1;31m无效消息格式\\033[0m")
    
    def _handle_messages(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        with queue_lock:
            response = json.dumps({"messages": message_queue.copy()})
            message_queue.clear()
        self.wfile.write(response.encode('utf-8'))
    
    def _create_html(self):
        return f"""
        <!DOCTYPE html>
        <html lang="zh-CN">
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>Termux 通信中心</title>
            <style>
                body {{
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
                    color: white;
                    margin: 0;
                    padding: 20px;
                    min-height: 100vh;
                }}
                .container {{
                    max-width: 800px;
                    margin: 0 auto;
                    background: rgba(255, 255, 255, 0.1);
                    backdrop-filter: blur(10px);
                    border-radius: 20px;
                    padding: 30px;
                    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
                }}
                h1 {{
                    text-align: center;
                    font-size: 2.5rem;
                    margin-bottom: 30px;
                    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.3);
                }}
                .message-box {{
                    background: rgba(255, 255, 255, 0.15);
                    border-radius: 15px;
                    padding: 20px;
                    margin-bottom: 25px;
                    max-height: 300px;
                    overflow-y: auto;
                }}
                .message {{
                    background: rgba(255, 255, 255, 0.2);
                    border-radius: 10px;
                    padding: 12px 15px;
                    margin-bottom: 10px;
                    animation: fadeIn 0.5s;
                }}
                @keyframes fadeIn {{
                    from {{ opacity: 0; transform: translateY(10px); }}
                    to {{ opacity: 1; transform: translateY(0); }}
                }}
                .input-group {{
                    display: flex;
                    gap: 10px;
                }}
                input {{
                    flex: 1;
                    padding: 15px;
                    border: none;
                    border-radius: 50px;
                    background: rgba(255, 255, 255, 0.2);
                    color: white;
                    font-size: 1rem;
                    outline: none;
                }}
                input::placeholder {{ color: rgba(255, 255, 255, 0.7); }}
                button {{
                    background: #ff2e63;
                    color: white;
                    border: none;
                    border-radius: 50px;
                    padding: 0 30px;
                    font-size: 1rem;
                    font-weight: bold;
                    cursor: pointer;
                    transition: all 0.3s;
                }}
                button:hover {{
                    background: #ff5c8d;
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(255, 46, 99, 0.4);
                }}
                .status {{
                    text-align: center;
                    margin-top: 20px;
                    font-size: 0.9rem;
                    opacity: 0.8;
                }}
                .ip-info {{
                    background: rgba(0, 0, 0, 0.2);
                    border-radius: 10px;
                    padding: 10px;
                    margin-top: 20px;
                    text-align: center;
                    font-size: 0.9rem;
                }}
                .copy-btn {{
                    background: #4CAF50;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    padding: 5px 10px;
                    margin-left: 10px;
                    cursor: pointer;
                    font-size: 0.8rem;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>✨ Termux 通信中心 ✨</h1>
                
                <div class="message-box" id="messageBox">
                    <div class="message">📢 已连接到Termux服务器！</div>
                </div>
                
                <div class="input-group">
                    <input type="text" id="messageInput" placeholder="输入消息发送到Termux终端...">
                    <button onclick="sendMessage()">发送</button>
                </div>
                
                <div class="status">
                    <p>连接状态: <span id="status">🟢 在线</span></p>
                </div>
                
                <div class="ip-info">
                    <p>其他设备访问地址: <span id="ipAddress">正在获取...</span>
                    <button class="copy-btn" onclick="copyIP()">复制</button></p>
                </div>
            </div>

            <script>
                const messageBox = document.getElementById('messageBox');
                const messageInput = document.getElementById('messageInput');
                const statusElem = document.getElementById('status');
                const ipAddressElem = document.getElementById('ipAddress');
                
                // 添加新消息到消息框
                function addMessage(text) {{
                    const msgDiv = document.createElement('div');
                    msgDiv.className = 'message';
                    msgDiv.textContent = text;
                    messageBox.prepend(msgDiv);
                    messageBox.scrollTop = 0;
                }}
                
                // 发送消息到服务器
                function sendMessage() {{
                    const message = messageInput.value.trim();
                    if (message) {{
                        fetch('/send', {{
                            method: 'POST',
                            headers: {{ 'Content-Type': 'application/json' }},
                            body: JSON.stringify({{ message }})
                        }});
                        addMessage(\`📤 你: \${{message}}\`);
                        messageInput.value = '';
                    }}
                }}
                
                // 按Enter发送消息
                messageInput.addEventListener('keypress', (e) => {{
                    if (e.key === 'Enter') sendMessage();
                }});
                
                // 轮询获取新消息
                async function fetchMessages() {{
                    try {{
                        const response = await fetch('/messages');
                        const data = await response.json();
                        data.messages.forEach(msg => addMessage(\`📥 Termux: \${{msg}}\`));
                        statusElem.innerHTML = '🟢 在线';
                    }} catch (error) {{
                        statusElem.innerHTML = '🔴 离线 - 尝试重新连接...';
                    }}
                    setTimeout(fetchMessages, 2000);
                }}
                
                // 获取服务器IP地址
                async function getServerIP() {{
                    try {{
                        const response = await fetch('/ip');
                        const data = await response.json();
                        ipAddressElem.textContent = \`http://\${{data.ip}}:8080\`;
                    }} catch (error) {{
                        ipAddressElem.textContent = '无法获取IP地址';
                    }}
                }}
                
                // 复制IP地址到剪贴板
                function copyIP() {{
                    const text = ipAddressElem.textContent;
                    navigator.clipboard.writeText(text)
                        .then(() => alert('地址已复制到剪贴板'))
                        .catch(err => console.error('复制失败:', err));
                }}
                
                // 初始化
                fetchMessages();
                getServerIP();
            </script>
        </body>
        </html>
        """

if __name__ == '__main__':
    host = '0.0.0.0'  # 绑定到所有网络接口
    port = 8080
    
    # 获取热点IP地址
    def get_hotspot_ip():
        """获取手机热点IP地址"""
        try:
            # 尝试获取wlan0接口的IP（热点接口）
            result = subprocess.run(['ip', 'addr', 'show', 'wlan0'], capture_output=True, text=True)
            if result.returncode == 0:
                # 查找IPv4地址
                import re
                ip_match = re.search(r'inet (\\d+\\.\\d+\\.\\d+\\.\\d+)/', result.stdout)
                if ip_match:
                    return ip_match.group(1)
            
            # 如果wlan0没有IP，尝试其他方法
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect(("8.8.8.8", 80))
                return s.getsockname()[0]
            finally:
                s.close()
        except:
            return "无法获取IP"
    
    hotspot_ip = get_hotspot_ip()

    print("\\033[1;32m启动Termux通信服务器...\\033[0m")
    print(f"\\033[1;33m本机访问: \\033[1;34mhttp://localhost:{port}\\033[0m")
    print(f"\\033[1;33m热点IP: \\033[1;34mhttp://{hotspot_ip}:{port}\\033[0m")
    print("\\033[1;33m等待网页连接...\\033[0m")
    
    server = ThreadedHTTPServer((host, port), RequestHandler)
    server.serve_forever()
EOF
`,
  type: 'python',
  varName: 'ak',
  size: 12514
};
var al = {
  index: 12,
  filename: '1. 本地服务/B html定长转图片.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/1. 本地服务/B html定长转图片.py',
  content: `python3 -x <<'EOF'
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
2000×3000 固定截图（一次成型）
"""
import os, subprocess, sys
from PIL import Image

# ---------- 可配参数 ----------
HTML_FILE   = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/项目分析报告/main差异分析HTML/项目08_vs_[25-2] TIM通道捕获应用之超声波测距_差异分析.html"
OUTPUT_FILE = "/storage/emulated/0/Download/QQ/项目08_vs_[16] 火焰传感器触发蜂鸣器_差异分析_optimized.png"
WIDTH       = 2000   # 固定宽度
HEIGHT      = 3000   # 固定高度
# ------------------------------

def shoot(html, out, width=2000, height=3000):
    cmd = ["chromium-browser", "--headless", "--disable-gpu", "--no-sandbox",
           "--run-all-compositor-stages-before-draw", "--virtual-time-budget=30000",
           f"--window-size={width},{height}", f"--screenshot={out}", f"file://{html}"]
    return subprocess.run(cmd, capture_output=True).returncode == 0

def main():
    print(f"截图 {WIDTH}×{HEIGHT} …")
    if shoot(HTML_FILE, OUTPUT_FILE, WIDTH, HEIGHT):
        print(f"✅ 完成！{WIDTH}×{HEIGHT}\\n📁 {OUTPUT_FILE}")
    else:
        print("截图失败")

if __name__ == "__main__":
    main()
EOF





#   脚本二  ，遍历整个目录下的html合并
python3 -x <<'EOF'
import os, subprocess, glob, tempfile, shutil

# ① 路径带空格 → 用引号包起来
DIR   = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/项目分析报告/main差异分析HTML"
WIDTH = 2000
HEIGHT = 3000
PDF   = os.path.join(DIR, "merged.pdf")

# ② 找 chromium
chromium = shutil.which("chromium-browser") or shutil.which("chrome") or "chromium-browser"

def shot(html, png):
    cmd = [chromium, "--headless", "--disable-gpu", "--no-sandbox",
           "--run-all-compositor-stages-before-draw", "--virtual-time-budget=30000",
           f"--window-size={WIDTH},{HEIGHT}", f"--screenshot={png}", f"file://{html}"]
    cp = subprocess.run(cmd, capture_output=True, text=True)
    if cp.returncode != 0:
        print("!!! chromium 报错:\\n", cp.stderr[:400])
    return cp.returncode == 0

with tempfile.TemporaryDirectory() as tmp:
    pngs = []
    for f in sorted(glob.glob(os.path.join(DIR, "*.html"))):
        png = os.path.join(tmp, os.path.basename(f).replace(".html", ".png"))
        if shot(f, png):
            pngs.append(png)
        else:
            break
    if not pngs:
        print("❌ 无 PNG"); exit()

    subprocess.run(["magick"] + pngs + [PDF], check=True)
    print("✅ merged.pdf 完成 →", os.path.basename(PDF))

# 临时 PNG 随 tmp 目录自动消失
EOF
`,
  type: 'python',
  varName: 'al',
  size: 2391
};
var am = {
  index: 13,
  filename: '2. 网络爬取/1. 批量写小说.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/2. 网络爬取/1. 批量写小说.py',
  content: `python3 - <<'EOF'
import os,sys,pathlib,time,requests,re
from docx import Document

# ==================== 配置区（只改这里） ====================
API_KEY = "sk-哥们你自己🔑🔑🔑🔑"
MODEL   = "kimi-k2-turbo-preview"
ROOT    = pathlib.Path("/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/3. ESP32-小智/副本/章节")
TOTAL   = 30
# ===========================================================

DOCX_PATH = pathlib.Path("/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/3. ESP32-小智/副本/（合并）g南堂  小说架构（10.2）.docx")
if not DOCX_PATH.exists():
    sys.exit("原始.docx 不存在，请检查路径")

ROOT.mkdir(parents=True, exist_ok=True)
WORLD_TEXT = "\\n".join(p.text for p in Document(DOCX_PATH).paragraphs if p.text.strip())

BIBLE = f"""
{WORLD_TEXT}

【补充强制意象】
糖=承诺，琴=家书，纸鸢=归否，桃花=凉安，空锅=执念。
每章必须出现至少1个意象，并翻转其原义。

【反派三级】
①袁潾（门阀） ②赫连曜（流民帅） ③乱世本身

【强制转折表】
1.南风渡夜逃→上巳游园（清谈斗诗）
2.游园→绛台朱门拒入（门阀嘲白衣）
3.绛台→纸鸢盟（城墙双线立誓）
4.纸鸢→流民帅夜袭（火乌鸦第一次）
5.夜袭→镜湖软禁（袁氏做局）
6.镜湖→雪夜断指（凉安断指换她命）
7.断指→南风渡立旗（南棠自封渡主）
"""

TURN_LIST = [l.strip() for l in """
南风渡夜逃→上巳游园（清谈斗诗）
游园→绛台朱门拒入（门阀嘲白衣）
绛台→纸鸢盟（城墙双线立誓）
纸鸢→流民帅夜袭（火乌鸦第一次）
夜袭→镜湖软禁（袁氏做局）
镜湖→雪夜断指（凉安断指换她命）
断指→南风渡立旗（南棠自封渡主）
""".strip().splitlines() if l.strip()]

memory_file = ROOT / "memory.txt"
written     = sorted(ROOT.glob("ch*.txt"), key=lambda x: int(x.stem[2:]))
next_ch     = len(written) + 1
memory      = "\\n".join(ch.read_text(encoding='utf-8') for ch in written)

url = "https://api.moonshot.cn/v1/chat/completions"
hdr = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

def chat(prompt: str) -> str:
    for i in range(1, 8):
        try:
            r = requests.post(url, headers=hdr,
                              json={"model": MODEL, "messages": [{"role": "user", "content": prompt}],
                                    "temperature": 0.32}, timeout=300)     # ← 只改这里：120→300
            if r.status_code == 429: time.sleep(2 ** i); continue
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
        except Exception as e:
            print(f"[ERR] {e}"); time.sleep(2)
    raise RuntimeError("重试失败")

if next_ch > TOTAL:
    print("[*] 卷一已完成"); exit(0)

for ch in range(next_ch, TOTAL + 1):
    turn = TURN_LIST[(ch - 1) // 5] if (ch - 1) // 5 < len(TURN_LIST) else "自由推进"
    temp = "45→60→70→30℃".split("→")[(ch - 1) // 10]

    print(f"[INFO] 正在生成 ch{ch:02d} ...")
    title = chat(f"{BIBLE}\\n{memory[-1200:]}\\n请起第{ch}章标题（≤12字），仅返回标题。").strip()
    title = re.sub(r"[\\"\\"''。,，!?？！]", "", title)
    print(f"[INFO] 标题：{title}")

    # ↓↓↓ 只改这里：prompt 加长 + 明确字数/token 上限 ↓↓↓
    body = chat(f"{BIBLE}\\n前文摘要：{memory[-1200:]}\\n强制转折：{turn}\\n感情温度：{temp}\\n标题：{title}\\n"
                f"要求：\\n"
                f"1. 本章《{title}》正文 2200-2600 字；\\n"
                f"2. 五个意象“糖/琴/纸鸢/桃花/空锅”只能各出现一次，且必须翻转其原义；\\n"
                f"3. 战争描写≤15%，禁用“雪夜断指”做任何标题或情节复用；\\n"
                f"4. 结尾留半句，标题必须全新，不得与前面任何章节重复；\\n"
                f"5. 禁止自我重复、禁止大段排比、禁止解释性旁白。")
    print(f"[INFO] 返回字数：{len(body)}")

    f = ROOT / f"ch{ch:02d}.txt"
    f.write_text(f"第{ch}章　{title}\\n\\n{body.strip()}", encoding='utf-8')
    memory += f"\\n\\n{body.strip()}"
    with memory_file.open("a", encoding='utf-8') as m:
        m.write(f"\\n\\n{body.strip()}")

    kw = re.findall(r"糖|琴|纸鸢|桃花|空锅", body)
    print(f"[OK] ch{ch:02d}《{title}》{len(body)}字  意象:{kw}")

# 合并终稿
all_txt = "\\n".join(ch.read_text(encoding='utf-8') for ch in sorted(ROOT.glob("ch*.txt"), key=lambda x: int(x.stem[2:])))
(ROOT / "VOL1_final.txt").write_text(all_txt, encoding='utf-8')
print("[ALL DONE] 总卷 → ", ROOT / "VOL1_final.txt")
EOF
`,
  type: 'python',
  varName: 'am',
  size: 3547
};
var an = {
  index: 14,
  filename: '2. 网络爬取/1. 批量回答问题（不截断）.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/2. 网络爬取/1. 批量回答问题（不截断）.py',
  content: `需求   一次性 bash 内嵌 Python3脚本
1.     一次性读取 30 个问题（自动校验，不足 30 个直接退出）。
2.    每问一次 Moonshot API，不携带历史，保证全新回答。
3.    回答按「教科书大纲：章节速览 → 一级→二级→正文（TXT 代码块，人话+名词解释）」格式输出。
4.    结果保存在
 /storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/回答/YYYYmmdd_HHMMSS/ 
文件名为  Q01.txt  …  Q30.txt ，序号与 questions.txt 严格对应。
---------------- 复制即跑 ----------------


python3 - <<'EOF'
# ---------- 唯一需要改的 ----------
API_KEY = "sk-哥们你自己的要是🔑🔑🔑"
QUESTIONS_FILE = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/questions.txt"
OUTPUT_DIR_PARENT = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01"
# ----------------------------------

import sys, time, pathlib, requests, datetime

q_path = pathlib.Path(QUESTIONS_FILE)
if not q_path.exists():
    sys.exit(f"[ERR] 问题文件不存在：{q_path}")

# 轻量校验：必须恰好 30 行非空问题
with q_path.open(encoding='utf-8') as f:
    questions = [line.strip() for line in f if line.strip()]
if len(questions) != 30:
    sys.exit(f"[ERR] 问题数量必须是 30 个，当前 {len(questions)} 个")

# 创建输出目录：项目01/回答/YYYYmmdd_HHMMSS/
ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
out_dir = pathlib.Path(OUTPUT_DIR_PARENT) / "回答" / ts
out_dir.mkdir(parents=True, exist_ok=True)

url = "https://api.moonshot.cn/v1/chat/completions"
hdr = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

def ask_once(q: str) -> str:
    """单问单答，失败抛异常"""
    prompt = f"""
【教科书大纲示例】（EXT4 进化史）
结论一句话：EXT4 就是把 32 位限制砸掉、再给小文件“拼车”、给大文件“包机”的 EXT3 超级升级版，至今仍是 Linux 默认根文件系统老大哥。
----------------------------------------------------------------
第0章 读前防呆
0.1 只聊“EXT 家史”+EXT4 质变，不教 mkfs 参数
0.2 生词→右侧“人话卡”秒懂
0.3 每章末尾“快问快答”——面试/装系统/吹水前背两句
----------------------------------------------------------------
第1章 四代同堂一张图
1.1 1992 EXT——婴儿期
（以下继续照此风格展开）

你是一位「Linux 内存管理」课程助教，请把回答整理成“教科书”风格：
1. 先给【章节速览】一句话总结；
2. 正文按 一级标题→二级标题→正文 逐级展开；
3. 正文使用 TXT 代码块（\`\`\`txt ... \`\`\`）包裹；
4. 遇到专业名词，用括号插播一句“人话解释”；
5. 保持口语化，禁止跑题；
6. 不输出任何与课程无关的寒暄。

问题：{q}
"""
    payload = {
        "model": "kimi-k2-turbo-preview",
        "messages": [{"role": "user", "content": prompt.strip()}],
        "temperature": 0.35,
        "max_tokens": 32000
    }
    for attempt in range(1, 6):
        try:
            r = requests.post(url, headers=hdr, json=payload, timeout=180)
            if r.status_code == 429:
                time.sleep(2 ** attempt)
                continue
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            print(f"[WARN] 第{attempt}次失败: {e}")
            time.sleep(2)
    raise RuntimeError("多次重试仍失败")

# 再读一次文件，逐条处理，保证“一次只读一个问题”
with q_path.open(encoding='utf-8') as f:
    for idx, raw_line in enumerate(f, 1):
        q = raw_line.strip()
        if not q:           # 跳过空行
            continue
        print(f"[{idx:02}/30] 提问：{q}")
        ans = ask_once(q)
        out_file = out_dir / f"Q{idx:02d}.txt"
        out_file.write_text(ans, encoding='utf-8')
        print(f"      已写入：{out_file.name}  （{len(ans)} 字）")

print(f"\\n[ALL DONE] 30 个回答已保存到 → {out_dir}")
EOF
`,
  type: 'python',
  varName: 'an',
  size: 3053
};
var ao = {
  index: 15,
  filename: '2. 网络爬取/2.  抓取冷笑话.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/2. 网络爬取/2.  抓取冷笑话.py',
  content: `python3 -c "
import requests
import re
import random

try:
    # 尝试多个可能的笑话网站
    urls = [
        'http://xiaohua.zol.com.cn/lengxiaohua/',
        'https://www.xiaohua.com/duanzi',
        'https://www.lengxiaohua.com/'
    ]
    
    # 尝试不同的用户代理
    user_agents = [
        'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X)',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'
    ]
    
    for url in urls:
        try:
            response = requests.get(
                url, 
                headers={'User-Agent': random.choice(user_agents)}, 
                timeout=10
            )
            html_content = response.text
            
            # 尝试多种提取方法
            patterns = [
                r'<div class=\\"article-text\\">(.*?)</div>',
                r'<div class=\\"content\\">(.*?)</div>',
                r'<p>(.*?)</p>',
                r'<div class=\\"detail-text\\">(.*?)</div>'
            ]
            
            jokes = []
            for pattern in patterns:
                found = re.findall(pattern, html_content, re.S)
                if found:
                    jokes.extend(found)
            
            if jokes:
                # 清理HTML标签
                clean_jokes = []
                for joke in jokes:
                    joke = re.sub(r'<[^>]+>', '', joke)
                    joke = re.sub(r'\\s+', ' ', joke)
                    joke = joke.strip()
                    if len(joke) > 20 and '笑话' not in joke and 'http' not in joke:
                        clean_jokes.append(joke)
                
                if clean_jokes:
                    selected_joke = random.choice(clean_jokes)
                    print('='*50)
                    print('随机笑话:')
                    print('='*50)
                    print(selected_joke)
                    print('='*50)
                    exit(0)  # 成功找到笑话，退出程序
            
            print(f'在 {url} 未找到笑话，尝试下一个网站...')
            
        except Exception as e:
            print(f'访问 {url} 失败: {e}')
            continue
    
    # 如果所有网站都失败，使用备用笑话
    backup_jokes = [
        '为什么数学书总是很悲伤？因为它有太多的问题。',
        '程序员去商店买牛奶，店员问：要不要来点面包？程序员回答：不用了，我家还有。',
        '有一天，三角形、圆形和正方形比赛跑步。圆形滚得最快，正方形卡住了，三角形一直转圈。',
        '为什么电脑永远不会感冒？因为它有Windows，但总是会打开。'
    ]
    
    print('='*50)
    print('网络笑话获取失败，使用备用笑话:')
    print('='*50)
    print(random.choice(backup_jokes))
    print('='*50)

except Exception as e:
    print(f'程序执行失败: {e}')
"
`,
  type: 'python',
  varName: 'ao',
  size: 2545
};
var ap = {
  index: 16,
  filename: '2. 网络爬取/2. 批量抓取力扣题目.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/2. 网络爬取/2. 批量抓取力扣题目.py',
  content: `     Mr.L  需求「一次复制，两行直接跑」的脚本：   termux的bash脚本 
1.   先抓 全部 1000 题 的题干（英文纯文本）
2.   按 每 50 题切一个文件（共 20 个文件）
3.   文件名自动编号： leetcode_001_050.json  …  leetcode_951_1000.json 
4.   目录若不存在会自动建，跑完打印 ✅ 列表。   


python3 -x <<'PYEOF'
import json, urllib.request, pathlib, re, html

root = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/leetcode_split"
pathlib.Path(root).mkdir(parents=True, exist_ok=True)

# ① 按 ID 升序拿前 1000 题
list_url = "https://leetcode.com/api/problems/all/"
req = urllib.request.Request(list_url, headers={
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
with urllib.request.urlopen(req) as resp:
    pairs = sorted(
        [(q["stat"]["frontend_question_id"], q["stat"]["question__title_slug"])
         for q in json.loads(resp.read().decode())["stat_status_pairs"]],
        key=lambda x: x[0])[:1000]

# ② GraphQL 模板
query = """
query questionData($titleSlug: String!) {
  question(titleSlug: $titleSlug) { content difficulty }
}"""

def fetch(qid, slug):
    payload = json.dumps({
        "operationName": "questionData",
        "query": query,
        "variables": {"titleSlug": slug}
    }).encode()
    greq = urllib.request.Request(
        "https://leetcode.com/graphql",
        data=payload,
        headers={"Content-Type": "application/json",
                 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"})
    with urllib.request.urlopen(greq) as r:
        d = json.loads(r.read().decode())["data"]["question"]
    text = html.unescape(re.sub(r'<[^>]+>', '', d["content"])) if d["content"] else ""
    return {"id": qid, "slug": slug, "difficulty": d["difficulty"], "content": text.strip()}

# ③ 每 50 题写一文件（存在就跳过）
batch = 50
for i in range(0, 1000, batch):
    file = pathlib.Path(root) / f"leetcode_{i+1:03d}_{min(i+batch, 1000):03d}.json"
    if file.exists():
        print(f"⏭ 跳过 {file}")
        continue
    chunk = [fetch(qid, slug) for qid, slug in pairs[i:i+batch]]
    with open(file, "w", encoding="utf-8") as f:
        json.dump(chunk, f, ensure_ascii=False, indent=2)
    print(f"✅ 已写入 {file}  （ID {chunk[0]['id']} ~ {chunk[-1]['id']}）")

print("全部完成！")
PYEOF
`,
  type: 'python',
  varName: 'ap',
  size: 2184
};
var aq = {
  index: 17,
  filename: '2. 网络爬取/4. 下载91学习视频（python版）.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/2. 网络爬取/4. 下载91学习视频（python版）.py',
  content: `#   L.  已对代码进行优化，便于人类阅读，先看main
 
python3 -x <<'EOF'   #   Python转bash
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
M3U8视频下载脚本
87000固定，87100-87200随到随下
单线程+极简提示+跳过>500MB文件
"""

import os
import subprocess
import requests
from pathlib import Path

# ==================== 配置常量 ====================
BASE_URL = "https://你的视频地址🔗🔗🔗🔗🔗🔗/87000"
START_ID = 87100
END_ID = 87200
SAVE_ROOT = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/02 不可描述"
USER_AGENT = "Mozilla/5.0 (Linux; Android 13; SM-G973F) AppleWebKit/537.36"
MAX_FILE_SIZE_MB = 500
REQUEST_TIMEOUT = 10
DOWNLOAD_TIMEOUT = 3600

HEADERS = {"User-Agent": USER_AGENT}


# ==================== 功能函数（按调用顺序排列） ====================
def check_m3u8_accessible(m3u8_url: str) -> bool:
    """
    检查M3U8文件是否可访问
    
    参数: m3u8_url - M3U8文件URL
    返回: 布尔值
    """
    try:
        response = requests.get(m3u8_url, headers=HEADERS, timeout=5)
        return response.text.startswith("#EXTM3U")
    except requests.RequestException:
        return False


def get_save_folder(video_id: int, start_id: int, save_root: str) -> Path:
    """
    获取视频保存文件夹路径
    
    参数: 
        video_id - 视频ID
        start_id - 起始ID  
        save_root - 保存根目录
    返回: 文件夹Path对象
    """
    # 每20个视频一个文件夹
    folder_start = start_id + ((video_id - start_id) // 20) * 20
    folder_name = f"{folder_start}-{folder_start + 19}"
    folder_path = Path(save_root) / folder_name
    folder_path.mkdir(parents=True, exist_ok=True)
    
    return folder_path


def get_video_size_mb(m3u8_url: str) -> int:
    """
    估算M3U8视频文件大小(MB)
    
    参数: m3u8_url - M3U8文件URL
    返回: 估算大小(MB)，失败返回0
    """
    try:
        # 1. 获取M3U8内容
        response = requests.get(m3u8_url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        lines = [line.strip() for line in response.text.splitlines() if line.strip()]
        
        # 2. 查找分片信息
        segment_line = next((line for line in lines if not line.startswith("#")), None)
        if not segment_line:
            return 0
        
        # 3. 构建分片URL
        base_url = m3u8_url.rsplit("/", 1)[0]
        segment_url = f"{base_url}/{segment_line}"
        
        # 4. 获取分片头部估算比特率
        segment_head = requests.get(
            segment_url, 
            headers={**HEADERS, "Range": "bytes=0-1023"}, 
            timeout=REQUEST_TIMEOUT
        ).content
        
        # 5. 使用ffprobe获取比特率
        bitrate_output = subprocess.check_output(
            ["ffprobe", "-v", "error", "-show_entries", "format=bit_rate", "-of", "csv=p=0", "-"],
            input=segment_head, 
            stderr=subprocess.DEVNULL,
        ).decode().strip()
        
        bitrate = int(bitrate_output) if bitrate_output.isdigit() else 1_000_000
        
        # 6. 计算总时长
        total_duration = 0.0
        for line in lines:
            if line.startswith("#EXTINF:"):
                total_duration += float(line.split(":")[1].split(",")[0])
        
        return int(bitrate * total_duration / 8 / 1024 / 1024) if total_duration > 0 else 0
        
    except Exception:
        return 0


def download_video(m3u8_url: str, output_file: Path, video_id: int) -> bool:
    """
    下载M3U8视频文件
    
    参数:
        m3u8_url - M3U8文件URL
        output_file - 输出文件路径  
        video_id - 视频ID
    返回: 布尔值
    """
    try:
        result = subprocess.run(
            [
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-nostats", "-y",
                "-user_agent", USER_AGENT, "-i", m3u8_url, "-c", "copy", str(output_file)
            ],
            timeout=DOWNLOAD_TIMEOUT
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        print(f"[超时] {video_id}")
        return False
    except Exception as error:
        print(f"[错误] {video_id}: {error}")
        return False


def main():
    """主函数"""
    # 一、初始化
    Path(SAVE_ROOT).mkdir(parents=True, exist_ok=True)
    print(f"[开始] 下载范围 {START_ID}-{END_ID}")
    
    success_count, skip_count, fail_count = 0, 0, 0
    
    # 二、遍历视频ID
    for video_id in range(START_ID, END_ID + 1):
        m3u8_url = f"{BASE_URL}/{video_id}/index.m3u8"
        
        # 1. 检查可访问性
        if not check_m3u8_accessible(m3u8_url):
            print(f"[跳过] {video_id} 不可访问")
            skip_count += 1
            continue
        
        # 2. 获取保存路径
        save_folder = get_save_folder(video_id, START_ID, SAVE_ROOT)
        output_file = save_folder / f"{video_id}.mp4"
        
        # 3. 检查文件存在
        if output_file.exists():
            print(f"[存在] {video_id}.mp4")
            skip_count += 1
            continue
        
        # 4. 估算文件大小
        file_size = get_video_size_mb(m3u8_url)
        if file_size > MAX_FILE_SIZE_MB:
            print(f"[跳过] {video_id} 大小{file_size}MB>500MB")
            skip_count += 1
            continue
        
        # 5. 下载视频
        print(f"[下载] {video_id} 大小{file_size}MB")
        if download_video(m3u8_url, output_file, video_id):
            print(f"[完成] {video_id}.mp4")
            success_count += 1
        else:
            print(f"[失败] {video_id}.mp4")
            fail_count += 1
    
    # 三、输出总结
    print(f">>> 全部结束! 成功:{success_count}, 跳过:{skip_count}, 失败:{fail_count}")


if __name__ == "__main__":
    main()

EOF`,
  type: 'python',
  varName: 'aq',
  size: 5262
};
var ar = {
  index: 18,
  filename: '3. 项目分析/1. 项目分析报告（API）.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/1. 项目分析报告（API）.py',
  content: `# 单文件 ，先ctags,jq分析 ，   再  文件＋ctags＋提示词分析
# 粘贴termux直接运行,  .py格式为了便于阅读
python3 - <<'EOF'
import os, subprocess, pathlib, requests, time, sys
from requests.exceptions import HTTPError

API_KEY = 'sk-哥们儿，别薅羊毛了。我也没钱🔑🔑🔑'
MODEL   = 'kimi-k2-turbo-preview'
SRC     = pathlib.Path('/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/3. ESP32-小智/副本/xiaozhi-esp32-main/main/application.cc')
OUT_DIR = pathlib.Path('/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/3. ESP32-小智/副本/xiaozhi-esp32-main/项目分析报告')

OUT_DIR.mkdir(parents=True, exist_ok=True)
TAGS_FILE = OUT_DIR / f'{SRC.stem}.cc_ctags.txt'
BRAIN_FILE= OUT_DIR / f'{SRC.stem}.cc_脑图.txt'

mode = 'c' if SRC.suffix == '.c' else 'cpp'
# 1. 完整 ctags + jq + awk 管道（含 macro）
cmd = f'''
ctags --output-format=json --kinds-c++=+c+d+e+f+g+l+m+n+p+s+t+u+v+x "{SRC}" 2>/dev/null |
jq -r \\'select((.kind=="function" or .kind=="member" or .kind=="macro" or .kind=="struct" or .kind=="typedef" or .kind=="variable") and (.name|startswith("__anon")|not))
        | . as $$r
        | if   $$r.kind=="macro"    then "MACRO\\\\t\\\\($$r.name)"
          elif $$r.kind=="function" then "FUNC\\\\t\\\\($$r.name)\\\\t\\\\($$r.scope//"-")"
          elif $$r.kind=="member"   then "MEMBER\\\\t\\\\($$r.name)\\\\t\\\\($$r.scope)"
          elif $$r.kind=="struct"   then "STRUCT\\\\t\\\\($$r.name)"
          elif $$r.kind=="typedef"  then "TYPEDEF\\\\t\\\\($$r.name)"
          elif $$r.kind=="variable" then "VAR\\\\t\\\\($$r.name)"
          else empty end\\' |
awk -v mode="{mode}" \\'
BEGIN{{print "[宏定义]"}}
$1=="MACRO"   {{printf "  %-30s （宏）\\\\n",$2; next}}
$1=="STRUCT"  {{if(!s_h){{print "\\\\n[结构体]";s_h=1}} printf "  %-30s （结构体）\\\\n",$2; next}}
$1=="TYPEDEF" {{if(!t_h){{print "\\\\n[类型别名]";t_h=1}} printf "  %-30s （类型别名）\\\\n",$2; next}}
$1=="VAR"     {{if(!v_h){{print "\\\\n[变量]";v_h=1}} printf "  %-30s （变量）\\\\n",$2; next}}
mode=="c" && $1=="FUNC" {{if(!f_h){{print "\\\\n[函数]";f_h=1}} printf "  %-30s （函数）\\\\n",$2; next}}
mode=="cpp" && $1=="FUNC" {{
    cls=$3; if(cls=="-"){{if(!g_h){{print "\\\\n[全局函数]";g_h=1}} printf "  %-30s （函数）\\\\n",$2; next}}
    else{{if(!(cls in done)){{printf "\\\\n[类 %s]\\\\n",cls; done[cls]=1}} printf "  %-30s （成员函数）\\\\n",$2; next}}
}}
mode=="cpp" && $1=="MEMBER" {{
    cls=$3; if(!(cls in done)){{printf "\\\\n[类 %s]\\\\n",cls; done[cls]=1}} printf "  %-30s （成员变量）\\\\n",$2; next}}
\\'
'''
symbols = subprocess.check_output(cmd, shell=True, text=True)
TAGS_FILE.write_text(symbols, encoding='utf-8')
print('[OK] 符号 →', TAGS_FILE)

code = SRC.read_text(encoding='utf-8', errors='ignore')

def chat(msgs):
    attempt = 0
    while True:
        try:
            r = requests.post(
                'https://api.moonshot.cn/v1/chat/completions',
                headers={'Authorization': f'Bearer {API_KEY}', 'Content-Type': 'application/json'},
                json={'model': MODEL, 'messages': msgs, 'temperature': 0.1},
                timeout=90)
            r.raise_for_status()
            return r.json()['choices'][0]['message']['content']
        except HTTPError as e:
            if e.response.status_code == 429:
                attempt += 1
                wait = 2 ** attempt
                print(f'\\n！429限速，{wait}s后重试(第{attempt}次)', file=sys.stderr)
                time.sleep(wait)
                continue
            raise

prompt = f"""下方给出两份材料：
1. ctags 抓取的符号清单（已去重）；
2. 完整 C/C++ 源码。

请以符号清单为基准，对照源码，按下面 3 点返回中文说明（英文标识符保留，括号内中文）：
1. 每个引入头文件的作用；
2. 所有自定义常量/宏；
3. 成员（含类型/函数/回调/变量）。

格式示例（必须严格照此输出，不要多一行解释）：
【头文件】
freertos/FreeRTOS.h（FreeRTOS主要头文件）

【宏常量】
TAG → "APP"（日志标签）

【类】
class Application（应用主类）：
- void start()（启动函数）
- static QueueHandle_t msgq（消息队列句柄）

符号清单（{symbols.count(chr(10))} 行）：
{symbols}

源码：
{code}"""

BRAIN_FILE.write_text(chat([{'role': 'user', 'content': prompt}]), encoding='utf-8')
print('[OK] 脑图 →', BRAIN_FILE)
EOF
`,
  type: 'python',
  varName: 'ar',
  size: 3782
};
var as = {
  index: 19,
  filename: '3. 项目分析/2. 生成项目依赖树（无黑名单）.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/2. 生成项目依赖树（无黑名单）.py',
  content: `#!/usr/bin/env bash # 指定用 bash 解释器      Mr.L bah脚本 ，.py只是为了阅读
#!/usr/bin/env bash # 指定用 bash 解释器
# ===================== 配置区 =====================
PROJECT_ROOT="/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/3. ESP32-小智/副本/xiaozhi-esp32-main" # 项目根目录
IDF_ROOT="/storage/emulated/0/Download/OnePlus Share/ESP-IDF源码/esp-idf-v5.5.1" # ESP-IDF 根目录
ENTRY_FILE="main/main.cc" # 入口源文件
OUT_SUBDIR="项目分析报告" # 输出子目录
# =================================================
set -euo pipefail # 开启严格模式：遇错退出、未定义变量报错、管道失败即失败

main(){ # 主函数
    local ENTRY_FULL="\${PROJECT_ROOT}/\${ENTRY_FILE}" # 拼接入口文件完整路径
    local OUT_FULL="\${PROJECT_ROOT}/\${OUT_SUBDIR}/$(basename "\${ENTRY_FILE}")-层级依赖树.txt" # 输出文件完整路径
    mkdir -p "$(dirname "\${OUT_FULL}")" # 若输出目录不存在则递归创建

    echo "⏳ 正在扫描头文件，请稍等..." # 打印提示
    declare -A HDR_MAP # 声明关联数组，用于存储头文件映射
    while IFS= read -r -d '' h; do # 以 null 为分隔符读取所有 .h 文件
        HDR_MAP["$(basename "$h")"]+="$h"$'\\n' # 以文件名为键，完整路径为值，允许多路径
    done < <(find "\${PROJECT_ROOT}" "\${IDF_ROOT}" -type f -iname '*.h' -print0) # 在项目根和 IDF 根下查找所有头文件

    extract(){ # 定义提取头文件名的函数
        grep -oE '^\\s*#\\s*include\\s+["<][^">]+[">]' "$1" 2>/dev/null | # 匹配 #include 行
        sed -E 's/^[^"<]*["<]//; s/[">].*$//' | # 去掉前后缀，保留文件名
        xargs -n1 basename 2>/dev/null || true # 取 basename，忽略错误
    }

    declare -A SEEN_INC        # 仅用于“已打印”去重
    declare -A STACK           # 用于循环依赖检测
    local ROOT_IDX=1 # 根序号从 1 开始

    # DFS 递归
    walk(){ # 递归遍历依赖
        local prefix=$1 inc=$2 lvl=$3 # 参数：前缀、当前头文件、层级
        [[ -n "\${STACK[$inc]:-}" ]] && { printf "%*s%s: %s  [Circular Dependency!]\\n" $((lvl*2)) "" "\${prefix}" "\${inc}"; return; } # 检测到循环依赖
        [[ -n "\${SEEN_INC[\${inc}]:-}" ]] && return   # 已打印过就不再展开
        SEEN_INC["\${inc}"]=1 # 标记已打印
        STACK["\${inc}"]=1 # 入栈，用于循环检测

        local found= # 是否找到标志
        local cand # 候选路径
        while IFS= read -r cand; do # 读取该头文件所有可能路径
            [[ -f "$cand" ]] || continue # 文件不存在则跳过
            local sub_counter=1 sub_inc # 子序号与头文件
            for sub_inc in $(extract "$cand"); do # 提取该头文件包含的子头文件
                local new_prefix="\${prefix}.\${sub_counter}" # 构造新前缀
                printf "%*s%s: %s\\n" $((lvl*2)) "" "\${new_prefix}" "\${sub_inc}" # 打印子节点
                walk "\${new_prefix}" "\${sub_inc}" $((lvl+1)) # 递归
                ((sub_counter++)) # 序号自增
            done
            found=1 # 找到至少一个有效路径
            break # 只取第一个有效路径
        done < <(printf '%s' "\${HDR_MAP[$inc]:-}") # 从映射中读取路径列表

        [[ $found ]] || printf "%*s%s: %s  [Not Found]\\n" $((lvl*2)) "" "\${prefix}" "\${inc}" # 未找到文件
        unset STACK["\${inc}"]    # 回溯出栈
    }

    { # 开始重定向到输出文件
        printf "=== 层级依赖树（无黑名单，已检测循环依赖） ===\\n" # 标题
        printf "0: %s\\n" "$(basename "\${ENTRY_FILE}")" # 打印入口文件名
        local inc # 临时变量
        for inc in $(extract "\${ENTRY_FULL}"); do # 提取入口文件直接包含的头文件
            printf "%d: %s\\n" "\${ROOT_IDX}" "\${inc}" # 打印第一层
            walk "\${ROOT_IDX}" "\${inc}" 1 # 递归展开
            ((ROOT_IDX++)) # 根序号自增
        done
    } > "\${OUT_FULL}" # 全部写入文件

    echo "✅ 新格式层级依赖树已写入：\${OUT_FULL}" # 完成提示
}

main "$@" # 传入所有参数并执行主函数
`,
  type: 'python',
  varName: 'as',
  size: 3123
};
var at = {
  index: 20,
  filename: '3. 项目分析/3. tm分析stm32项目.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/3. tm分析stm32项目.py',
  content: `“把 8~20 号例程文件夹里的 Core 子目录 tree 结果，连同对应文件夹名，一次性追加写进
/storage/emulated/0/Download/OnePlus\\ Share/GITHUB\\ 开源项目/项目01/野火小智文档/core_summary.txt”  

python3 -c "
# 引入 subprocess 用于在 Python 内调用外部命令（如 tree）
# 引入 pathlib 用于面向对象地操作文件系统路径
# 引入 re 用于正则表达式匹配目录名
import subprocess, pathlib, re

# 将根目录字符串封装为 Path 对象，后续可直接用 / 拼接子路径
root = pathlib.Path('/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档')

# 拼接输出文件完整路径，等价于 os.path.join(root, 'core_summary.txt')
out  = root/'core_summary.txt'

# 以 UTF-8 编码、覆盖写模式打开文件；with 块结束时会自动 flush 并关闭文件
with out.open('w', encoding='utf-8') as f:
    # 循环生成 8 到 20（含）共 13 个实验编号
    for n in range(8, 21):
        # 为当前编号构造正则关键字：
        # 非 19 时精确匹配 "[n]"；19 时匹配 "[19" 前缀，从而覆盖 19-1 到 19-10
        key = fr'\\[{n}\\]' if n != 19 else r'\\[19'

        # 按字典序遍历根目录下所有直接子项（文件或文件夹）
        for d in sorted(root.iterdir()):
            # 只处理目录，且目录名必须满足上面构造的正则
            if d.is_dir() and re.search(key, d.name):
                # 定位到该实验目录下的 Core 子目录
                core = d/'Core'
                # 只有 Core 目录真实存在时才写入标题并生成树状图
                if core.exists():
                    # 写入分隔行，方便阅读
                    f.write(f'\\n======== {d.name} ========\\n')
                    # 调用系统 tree 命令，把树状图直接重定向到文件；
                    # stderr 也合并到 stdout，保证报错信息不会出现在终端
                    subprocess.run(['tree', str(core)], stdout=f, stderr=subprocess.STDOUT)
                # 不 break，继续循环，确保同一编号（尤其是 19-x）全部被抓取
"
`,
  type: 'python',
  varName: 'at',
  size: 1441
};
var au = {
  index: 21,
  filename: '3. 项目分析/7. 生成文件差异报告（两文件）2版.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/7. 生成文件差异报告（两文件）2版.py',
  content: `python3 -x <<'EOF'   #   Python转bash
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import re
import difflib
import argparse
from datetime import datetime
from pathlib import Path

def parse_arguments():
    """处理命令行参数或使用默认路径"""
    if len(sys.argv) == 4:  # 三个参数：文件1、文件2、输出目录
        file1, file2, report_dir = sys.argv[1], sys.argv[2], sys.argv[3]
    elif len(sys.argv) == 1:  # 无参数，使用默认路径
        file1 = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/[19-5]串口接收之中断接收定长数据/Core/Src/main.c"
        file2 = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/[19-7]串口接收之空闲中断接收不定长数据/Core/Src/main.c"
        report_dir = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档/项目分析报告/差异文件/"
    else:  # 参数数量不正确
        print(f"用法: {sys.argv[0]} [文件1 文件2 输出目录]")
        print(f"示例: {sys.argv[0]} /path/to/file1.c /path/to/file2.c /path/to/output")
        print("注意: 不带参数使用默认路径")
        sys.exit(1)
    
    return file1, file2, report_dir

def initialize_settings(report_dir):
    """创建时间戳和报告文件路径"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    html_diff_report = os.path.join(report_dir, f"代码差异报告_{timestamp}.html")
    analysis_report = os.path.join(report_dir, f"差异分析报告_{timestamp}.txt")
    
    # 创建输出目录
    Path(report_dir).mkdir(parents=True, exist_ok=True)
    
    return timestamp, html_diff_report, analysis_report

def check_files(file1, file2):
    """验证文件是否存在且可访问"""
    if not os.path.isfile(file1):
        raise FileNotFoundError(f"文件不存在: {file1}")
    if not os.path.isfile(file2):
        raise FileNotFoundError(f"文件不存在: {file2}")

def safe_read_file(filepath):
    """安全读取文件，处理编码问题"""
    encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1']
    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding) as f:
                return f.readlines(), encoding
        except UnicodeDecodeError:
            continue
    # 如果所有编码都失败，使用忽略错误的方式读取
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        return f.readlines(), 'utf-8'

def generate_html_diff_report(file1, file2, html_report_path):
    """生成HTML格式的差异报告"""
    file1_lines, enc1 = safe_read_file(file1)
    file2_lines, enc2 = safe_read_file(file2)
    
    # 生成HTML格式的diff报告
    html_diff = difflib.HtmlDiff().make_file(
        file1_lines, file2_lines, 
        fromdesc=file1, todesc=file2,
        context=True, numlines=3
    )
    
    with open(html_report_path, 'w', encoding='utf-8') as html_file:
        html_file.write(html_diff)
    
    return html_diff

def get_file_info(filepath):
    """获取文件基本信息 - 大小、行数等"""
    file_stat = os.stat(filepath)
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        line_count = sum(1 for _ in f)
    
    return {
        'name': os.path.basename(filepath),
        'path': os.path.dirname(filepath),
        'size': file_stat.st_size,
        'lines': line_count
    }

def generate_diff_content(file1, file2):
    """生成内存中的diff内容用于分析"""
    file1_lines, enc1 = safe_read_file(file1)
    file2_lines, enc2 = safe_read_file(file2)
    
    # 生成unified diff格式
    diff = difflib.unified_diff(file1_lines, file2_lines, 
                               fromfile=file1, tofile=file2, n=3)
    
    return list(diff)

def analyze_diff_statistics(diff_content):
    """分析差异统计 - 统计新增行、删除行、变更区块"""
    added = sum(1 for line in diff_content if line.startswith('+') and not line.startswith('+++'))
    deleted = sum(1 for line in diff_content if line.startswith('-') and not line.startswith('---'))
    changed_blocks = sum(1 for line in diff_content if line.startswith('@@'))
    
    return added, deleted, changed_blocks

def parse_diff_blocks(diff_content, limit=50):
    """解析diff区块 - 提取变更的详细位置信息"""
    blocks = []
    current_block = {}
    
    for line in diff_content[:limit]:  # 限制分析行数
        if line.startswith('@@'):
            # 解析区块头信息：@@ -开始行,行数 +开始行,行数 @@
            match = re.match(r'@@ -(\\d+),?(\\d*) \\+(\\d+),?(\\d*) @@', line)
            if match:
                if current_block:  # 保存上一个区块
                    blocks.append(current_block)
                
                # 解析行号信息
                start1 = int(match.group(1))
                count1 = int(match.group(2)) if match.group(2) else 1
                start2 = int(match.group(3))
                count2 = int(match.group(4)) if match.group(4) else 1
                
                current_block = {
                    'header': line.strip(),
                    'start1': start1,
                    'end1': start1 + count1 - 1,
                    'start2': start2,
                    'end2': start2 + count2 - 1,
                    'changes': []
                }
        elif line.startswith('-') and not line.startswith('---'):
            current_block['changes'].append(('delete', line[1:].rstrip()))
        elif line.startswith('+') and not line.startswith('+++'):
            current_block['changes'].append(('add', line[1:].rstrip()))
    
    if current_block:
        blocks.append(current_block)
    
    return blocks

def detect_key_changes(diff_content, keywords):
    """检测关键变更 - 识别特定的代码模式（如串口相关变更）"""
    key_changes = []
    for line in diff_content:
        if any(keyword.lower() in line.lower() for keyword in keywords):
            change_type = 'delete' if line.startswith('-') else 'add' if line.startswith('+') else 'context'
            key_changes.append((change_type, line.rstrip()))
    
    return key_changes

def generate_analysis_report(file1_info, file2_info, diff_content, analysis_report_path):
    """生成文本格式的详细分析报告"""
    with open(analysis_report_path, 'w', encoding='utf-8') as report:
        # 报告头部
        report.write("=" * 60 + "\\n")
        report.write("                  代码差异分析报告\\n")
        report.write("=" * 60 + "\\n")
        report.write(f"生成时间: {datetime.now()}\\n")
        report.write(f"比较文件: {file1_info['name']} ↔ {file2_info['name']}\\n\\n")
        
        # 1. 文件基本信息
        report.write("一、文件基本信息\\n")
        report.write("=" * 25 + "\\n")
        report.write("1. 源文件:\\n")
        report.write(f"   - 文件名: {file1_info['name']}\\n")
        report.write(f"   - 路径: {file1_info['path']}\\n")
        report.write(f"   - 大小: {file1_info['size']} 字节\\n")
        report.write(f"   - 行数: {file1_info['lines']} 行\\n\\n")
        
        report.write("2. 目标文件:\\n")
        report.write(f"   - 文件名: {file2_info['name']}\\n")
        report.write(f"   - 路径: {file2_info['path']}\\n")
        report.write(f"   - 大小: {file2_info['size']} 字节\\n")
        report.write(f"   - 行数: {file2_info['lines']} 行\\n\\n")
        
        # 2. 差异统计
        added, deleted, changed_blocks = analyze_diff_statistics(diff_content)
        report.write("二、差异统计摘要\\n")
        report.write("=" * 25 + "\\n")
        report.write("1. 基本统计:\\n")
        report.write(f"   - 源文件总行数: {file1_info['lines']}\\n")
        report.write(f"   - 目标文件总行数: {file2_info['lines']}\\n")
        report.write(f"   - 行数差异: {file2_info['lines'] - file1_info['lines']} 行\\n\\n")
        
        report.write("2. 变更统计:\\n")
        report.write(f"   - 新增行数: {added}\\n")
        report.write(f"   - 删除行数: {deleted}\\n")
        report.write(f"   - 变更区块数: {changed_blocks}\\n\\n")
        
        # 3. 详细差异分析
        report.write("三、详细差异分析\\n")
        report.write("=" * 25 + "\\n")
        
        if added == 0 and deleted == 0:
            report.write("✅ 两个文件内容完全一致\\n")
        else:
            report.write(f"❌ 文件存在差异，共发现 {changed_blocks} 个变更区块\\n\\n")
            
            blocks = parse_diff_blocks(diff_content)
            for i, block in enumerate(blocks, 1):
                if i > 1:
                    report.write("\\n\\n")  # 区块间空行
                
                report.write(f"【变更区块 {i}】@@{block['start1']}-{block['end1']}行 ↔ {block['start2']}-{block['end2']}行@@\\n")
                
                for change_type, content in block['changes'][:10]:  # 限制每个区块显示10个变更
                    if change_type == 'delete':
                        report.write(f"  ❌ 删除: {content}\\n")
                    else:
                        report.write(f"      ✅ 新增: {content}\\n")
            report.write("\\n")
        
        # 4. 关键变更识别
        report.write("四、关键变更识别\\n")
        report.write("=" * 25 + "\\n")
        uart_keywords = ['HAL_UART', 'USART', '中断', 'interrupt']
        key_changes = detect_key_changes(diff_content, uart_keywords)
        
        if key_changes:
            report.write("🔧 检测到串口相关变更:\\n")
            for change_type, content in key_changes[:5]:  # 显示前5个关键变更
                if change_type == 'delete':
                    report.write(f"  ❌ 删除: {content}\\n")
                elif change_type == 'add':
                    report.write(f"     ✅ 新增: {content}\\n")
        else:
            report.write("   未检测到明显的串口相关变更\\n")
        report.write("\\n")
        
        # 5. 总结与建议
        report.write("五、总结与建议\\n")
        report.write("=" * 25 + "\\n")
        
        if added == 0 and deleted == 0:
            report.write("✅ 文件完全相同，无需进一步操作\\n")
        else:
            total_changes = added + deleted
            total_lines = max(file1_info['lines'], 1)  # 避免除零
            change_ratio = (total_changes * 100) // total_lines
            
            report.write("📊 变更程度分析:\\n")
            report.write(f"   - 总变更行数: {total_changes}\\n")
            report.write(f"   - 变更率: {change_ratio}%\\n\\n")
            report.write("💡 处理建议:\\n")
            
            if change_ratio < 10:
                report.write("   轻微变更 - 建议重点审查具体变更行\\n")
            elif change_ratio < 30:
                report.write("   中等变更 - 需要仔细审查变更逻辑\\n")
            else:
                report.write("   重大变更 - 建议全面测试验证\\n")
        
        report.write("\\n" + "=" * 60 + "\\n")
        report.write("报告生成完成\\n")
        report.write("=" * 60 + "\\n")

def main():
    """主函数 - 协调整个差异分析流程"""
    try:
        # 1. 参数解析
        file1, file2, report_dir = parse_arguments()
        
        # 2. 初始化设置
        timestamp, html_diff_report, analysis_report = initialize_settings(report_dir)
        
        # 3. 文件检查
        check_files(file1, file2)
        
        # 4. 获取文件信息
        file1_info = get_file_info(file1)
        file2_info = get_file_info(file2)
        
        # 5. 生成HTML格式的差异报告
        generate_html_diff_report(file1, file2, html_diff_report)
        
        # 6. 生成内存中的diff内容用于分析
        diff_content = generate_diff_content(file1, file2)
        
        # 7. 生成文本格式的详细分析报告
        generate_analysis_report(file1_info, file2_info, diff_content, analysis_report)
        
        # 8. 输出完成信息
        print("✅ 差异分析完成！\\n")
        print("📊 生成的报告文件:")
        print(f"   1. HTML代码差异报告: {html_diff_report}")
        print(f"   2. 文本差异分析报告: {analysis_report}\\n")
        print("💡 使用提示:")
        print("   - HTML报告提供直观的代码差异可视化")
        print("   - 文本分析报告包含所有关键差异信息")
        print(f"   - 可通过参数指定文件路径: {sys.argv[0]} 文件1 文件2 输出目录")
        
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

EOF`,
  type: 'python',
  varName: 'au',
  size: 11071
};
var av = {
  index: 22,
  filename: '3. 项目分析/8. 生成文件差异报告（项目）.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/8. 生成文件差异报告（项目）.py',
  content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import re
import difflib
import glob
from datetime import datetime
from pathlib import Path

# 基础目录配置
BASE_DIR = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档"
REPORT_DIR = os.path.join(BASE_DIR, "项目分析报告", "main差异分析")
HTML_REPORT_DIR = os.path.join(BASE_DIR, "项目分析报告", "main差异分析HTML")  # HTML报告目录
BASE_PROJECT = "[8] STM32CubeMX新建MDK工程"  # 基准项目名称

def safe_read_file(filepath):
    """安全读取文件，处理编码问题"""
    encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1']
    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding) as f:
                return f.readlines(), encoding
        except UnicodeDecodeError:
            continue
    # 如果所有编码都失败，使用忽略错误的方式读取
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        return f.readlines(), 'utf-8'

def get_file_info(filepath):
    """获取文件基本信息 - 大小、行数等"""
    if not os.path.isfile(filepath):
        return None
    
    file_stat = os.stat(filepath)
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        line_count = sum(1 for _ in f)
    
    return {
        'name': os.path.basename(filepath),
        'path': os.path.dirname(filepath),
        'size': file_stat.st_size,
        'lines': line_count
    }

def generate_html_diff_report(file1, file2, html_report_path):
    """生成HTML格式的差异报告"""
    file1_lines, enc1 = safe_read_file(file1)
    file2_lines, enc2 = safe_read_file(file2)
    
    # 生成HTML格式的diff报告
    html_diff = difflib.HtmlDiff(
        tabsize=4,
        wrapcolumn=80,
        linejunk=None,
        charjunk=difflib.IS_CHARACTER_JUNK
    ).make_file(
        file1_lines, file2_lines, 
        fromdesc=os.path.basename(file1), 
        todesc=os.path.basename(file2),
        context=True, numlines=5
    )
    
    # 添加自定义CSS样式
    html_diff = html_diff.replace(
        '</head>',
        '<style>\\n'
        '  body { font-family: Arial, sans-serif; }\\n'
        '  table.diff { width: 100%; border-collapse: collapse; }\\n'
        '  .diff_header { background-color: #f0f0f0; font-weight: bold; }\\n'
        '  td.diff_header { text-align: right; padding: 4px 8px; }\\n'
        '  .diff_next { background-color: #c0c0c0; }\\n'
        '  .diff_add { background-color: #aaffaa; }\\n'
        '  .diff_chg { background-color: #ffff77; }\\n'
        '  .diff_sub { background-color: #ffaaaa; }\\n'
        '  .diff_pagenav { text-align: center; padding: 10px; }\\n'
        '  .diff_add:hover, .diff_chg:hover, .diff_sub:hover { background-color: #ffd700; }\\n'
        '  .diff_line { font-family: "Courier New", monospace; font-size: 14px; }\\n'
        '</style>\\n'
        '</head>'
    )
    
    with open(html_report_path, 'w', encoding='utf-8') as html_file:
        html_file.write(html_diff)
    
    return html_diff

def generate_diff_content(file1, file2):
    """生成内存中的diff内容用于分析"""
    file1_lines, enc1 = safe_read_file(file1)
    file2_lines, enc2 = safe_read_file(file2)
    
    # 生成unified diff格式
    diff = difflib.unified_diff(file1_lines, file2_lines, 
                               fromfile=file1, tofile=file2, n=3)
    
    return list(diff)

def analyze_diff_statistics(diff_content):
    """分析差异统计 - 统计新增行、删除行、变更区块"""
    added = sum(1 for line in diff_content if line.startswith('+') and not line.startswith('+++'))
    deleted = sum(1 for line in diff_content if line.startswith('-') and not line.startswith('---'))
    changed_blocks = sum(1 for line in diff_content if line.startswith('@@'))
    
    return added, deleted, changed_blocks

def parse_diff_blocks(diff_content, limit=50):
    """解析diff区块 - 提取变更的详细位置信息"""
    blocks = []
    current_block = {}
    
    for line in diff_content[:limit]:  # 限制分析行数
        if line.startswith('@@'):
            # 解析区块头信息：@@ -开始行,行数 +开始行,行数 @@
            match = re.match(r'@@ -(\\d+),?(\\d*) \\+(\\d+),?(\\d*) @@', line)
            if match:
                if current_block:  # 保存上一个区块
                    blocks.append(current_block)
                
                # 解析行号信息
                start1 = int(match.group(1))
                count1 = int(match.group(2)) if match.group(2) else 1
                start2 = int(match.group(3))
                count2 = int(match.group(4)) if match.group(4) else 1
                
                current_block = {
                    'header': line.strip(),
                    'start1': start1,
                    'end1': start1 + count1 - 1,
                    'start2': start2,
                    'end2': start2 + count2 - 1,
                    'changes': []
                }
        elif line.startswith('-') and not line.startswith('---'):
            current_block['changes'].append(('delete', line[1:].rstrip()))
        elif line.startswith('+') and not line.startswith('+++'):
            current_block['changes'].append(('add', line[1:].rstrip()))
    
    if current_block:
        blocks.append(current_block)
    
    return blocks

def detect_key_changes(diff_content, keywords):
    """检测关键变更 - 识别特定的代码模式（如串口相关变更）"""
    key_changes = []
    for line in diff_content:
        if any(keyword.lower() in line.lower() for keyword in keywords):
            change_type = 'delete' if line.startswith('-') else 'add' if line.startswith('+') else 'context'
            key_changes.append((change_type, line.rstrip()))
    
    return key_changes

def generate_analysis_report(file1_info, file2_info, diff_content, analysis_report_path):
    """生成文本格式的详细分析报告"""
    with open(analysis_report_path, 'w', encoding='utf-8') as report:
        # 报告头部
        report.write("=" * 60 + "\\n")
        report.write("                  代码差异分析报告\\n")
        report.write("=" * 60 + "\\n")
        report.write(f"生成时间: {datetime.now()}\\n")
        report.write(f"比较文件: {file1_info['name']} ↔ {file2_info['name']}\\n\\n")
        
        # 1. 文件基本信息
        report.write("一、文件基本信息\\n")
        report.write("=" * 25 + "\\n")
        report.write("1. 源文件 (基准项目08):\\n")
        report.write(f"   - 文件名: {file1_info['name']}\\n")
        report.write(f"   - 路径: {file1_info['path']}\\n")
        report.write(f"   - 大小: {file1_info['size']} 字节\\n")
        report.write(f"   - 行数: {file1_info['lines']} 行\\n\\n")
        
        report.write("2. 目标文件:\\n")
        report.write(f"   - 文件名: {file2_info['name']}\\n")
        report.write(f"   - 路径: {file2_info['path']}\\n")
        report.write(f"   - 大小: {file2_info['size']} 字节\\n")
        report.write(f"   - 行数: {file2_info['lines']} 行\\n\\n")
        
        # 2. 差异统计
        added, deleted, changed_blocks = analyze_diff_statistics(diff_content)
        report.write("二、差异统计摘要\\n")
        report.write("=" * 25 + "\\n")
        report.write("1. 基本统计:\\n")
        report.write(f"   - 基准文件总行数: {file1_info['lines']}\\n")
        report.write(f"   - 目标文件总行数: {file2_info['lines']}\\n")
        report.write(f"   - 行数差异: {file2_info['lines'] - file1_info['lines']} 行\\n\\n")
        
        report.write("2. 变更统计:\\n")
        report.write(f"   - 新增行数: {added}\\n")
        report.write(f"   - 删除行数: {deleted}\\n")
        report.write(f"   - 变更区块数: {changed_blocks}\\n\\n")
        
        # 3. 详细差异分析
        report.write("三、详细差异分析\\n")
        report.write("=" * 25 + "\\n")
        
        if added == 0 and deleted == 0:
            report.write("✅ 两个文件内容完全一致\\n")
        else:
            report.write(f"❌ 文件存在差异，共发现 {changed_blocks} 个变更区块\\n\\n")
            
            blocks = parse_diff_blocks(diff_content)
            for i, block in enumerate(blocks, 1):
                if i > 1:
                    report.write("\\n\\n")  # 区块间空行
                
                report.write(f"【变更区块 {i}】@@{block['start1']}-{block['end1']}行 ↔ {block['start2']}-{block['end2']}行@@\\n")
                
                for change_type, content in block['changes'][:10]:  # 限制每个区块显示10个变更
                    if change_type == 'delete':
                        report.write(f"  ❌ 删除: {content}\\n")
                    else:
                        report.write(f"      ✅ 新增: {content}\\n")
            report.write("\\n")
        
        # 4. 关键变更识别
        report.write("四、关键变更识别\\n")
        report.write("=" * 25 + "\\n")
        uart_keywords = ['HAL_UART', 'USART', '中断', 'interrupt']
        key_changes = detect_key_changes(diff_content, uart_keywords)
        
        if key_changes:
            report.write("🔧 检测到串口相关变更:\\n")
            for change_type, content in key_changes[:5]:  # 显示前5个关键变更
                if change_type == 'delete':
                    report.write(f"  ❌ 删除: {content}\\n")
                elif change_type == 'add':
                    report.write(f"     ✅ 新增: {content}\\n")
        else:
            report.write("   未检测到明显的串口相关变更\\n")
        report.write("\\n")
        
        # 5. 总结与建议
        report.write("五、总结与建议\\n")
        report.write("=" * 25 + "\\n")
        
        if added == 0 and deleted == 0:
            report.write("✅ 文件完全相同，无需进一步操作\\n")
        else:
            total_changes = added + deleted
            total_lines = max(file1_info['lines'], 1)  # 避免除零
            change_ratio = (total_changes * 100) // total_lines
            
            report.write("📊 变更程度分析:\\n")
            report.write(f"   - 总变更行数: {total_changes}\\n")
            report.write(f"   - 变更率: {change_ratio}%\\n\\n")
            report.write("💡 处理建议:\\n")
            
            if change_ratio < 10:
                report.write("   轻微变更 - 建议重点审查具体变更行\\n")
            elif change_ratio < 30:
                report.write("   中等变更 - 需要仔细审查变更逻辑\\n")
            else:
                report.write("   重大变更 - 建议全面测试验证\\n")
        
        report.write("\\n" + "=" * 60 + "\\n")
        report.write("报告生成完成\\n")
        report.write("=" * 60 + "\\n")
        
        # 添加HTML报告提示
        report.write("\\n提示: 更直观的HTML格式差异报告可在 main差异分析HTML 目录中查看\\n")

def find_project_main_files():
    """查找所有项目中的main.c文件 - 使用Bash脚本相同的扫描逻辑"""
    projects = {}
    base_project_path = None
    
    # 查找所有项目文件夹
    project_dirs = [d for d in os.listdir(BASE_DIR) 
                   if os.path.isdir(os.path.join(BASE_DIR, d)) 
                   and d != "项目分析报告"]
    
    for project_dir in project_dirs:
        full_path = os.path.join(BASE_DIR, project_dir)
        
        # 确定扫描目录 - 与Bash脚本相同的逻辑
        scan_dir = None
        if os.path.exists(os.path.join(full_path, "Core")):
            scan_dir = os.path.join(full_path, "Core")
        elif os.path.exists(os.path.join(full_path, "User")):
            scan_dir = os.path.join(full_path, "User")
        elif os.path.exists(os.path.join(full_path, "APP")):
            scan_dir = os.path.join(full_path, "APP")
        
        if not scan_dir:
            continue
        
        # 查找main.c文件
        main_c_path = os.path.join(scan_dir, "Src", "main.c")
        if os.path.isfile(main_c_path):
            # 保存项目信息
            projects[project_dir] = main_c_path
            
            # 检查是否是基准项目
            if project_dir == BASE_PROJECT:
                base_project_path = main_c_path
    
    return projects, base_project_path

def compare_with_base_project():
    """将所有项目与基准项目08进行比较"""
    # 确保报告目录存在
    Path(REPORT_DIR).mkdir(parents=True, exist_ok=True)
    Path(HTML_REPORT_DIR).mkdir(parents=True, exist_ok=True)  # 创建HTML报告目录
    
    # 查找所有项目中的main.c文件
    projects, base_project_path = find_project_main_files()
    if not projects:
        print("未找到任何项目中的main.c文件")
        return
    
    if not base_project_path:
        print(f"错误: 未找到基准项目 {BASE_PROJECT} 的 main.c 文件")
        return
    
    # 获取基准项目文件信息
    base_info = get_file_info(base_project_path)
    if not base_info:
        print(f"错误: 无法读取基准项目文件 {base_project_path}")
        return
    
    # 比较所有项目与基准项目
    for project_name, project_file in projects.items():
        # 跳过基准项目自身
        if project_name == BASE_PROJECT:
            continue
        
        # 获取项目文件信息
        project_info = get_file_info(project_file)
        if not project_info:
            print(f"跳过对比: {project_file} 不存在")
            continue
        
        # 生成文本报告文件名
        report_name = f"项目08_vs_{project_name}_差异分析.txt"
        report_path = os.path.join(REPORT_DIR, report_name)
        
        # 生成HTML报告文件名
        html_report_name = f"项目08_vs_{project_name}_差异分析.html"
        html_report_path = os.path.join(HTML_REPORT_DIR, html_report_name)
        
        # 生成差异内容
        diff_content = generate_diff_content(base_project_path, project_file)
        
        # 生成HTML差异报告
        generate_html_diff_report(base_project_path, project_file, html_report_path)
        
        # 生成文本分析报告
        generate_analysis_report(base_info, project_info, diff_content, report_path)
        
        print(f"已生成对比报告: 项目08 vs {project_name}")
        print(f"   - 文本报告: {report_path}")
        print(f"   - HTML报告: {html_report_path}")

def main():
    """主函数 - 协调整个差异分析流程"""
    try:
        print("开始扫描项目并与项目08进行对比...")
        compare_with_base_project()
        print("\\n✅ 所有差异分析完成！")
        print(f"📊 文本报告已保存至: {REPORT_DIR}")
        print(f"🌐 HTML报告已保存至: {HTML_REPORT_DIR}")
        
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()  # 打印详细的错误堆栈
        sys.exit(1)

if __name__ == "__main__":
    main()
`,
  type: 'python',
  varName: 'av',
  size: 13297
};
var aw = {
  index: 23,
  filename: '3. 项目分析/9. 项目模块 main函数差异.py',
  fullPath: '/storage/emulated/0/Download/OnePlus Share/03 - 个人测试/常用工具转安卓/常用脚本/B_10月脚本/3. 项目分析/9. 项目模块 main函数差异.py',
  content: `# 生成项目 函数差异报告，便于AI分析
python3 -x <<'EOF'   #   Python转bash
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import re
import difflib
from datetime import datetime
from pathlib import Path

# ==================== 配置文件区域 ====================
# 用户可以修改以下配置参数

# 基础目录配置
BASE_DIR = "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/野火小智文档"
REPORT_DIR_NAME = "main函数差异"  # 报告目录名称
BASE_PROJECT = "[8] STM32CubeMX新建MDK工程"  # 基准项目名称
REPORT_EXTENSION = ".c"  # 报告文件扩展名

# 文件扫描配置
SCAN_DIRS = ["Core", "User", "APP"]  # 扫描的目录名称
MAIN_FILE_PATH = "Src"  # main.c文件所在的子目录

# 函数提取配置
FUNCTION_PATTERN = r'(\\w+[\\w\\s*]+\\s+\\**\\s*(\\w+)\\s*\\([^{]*\\))\\s*\\{'  # 匹配函数定义的正则表达式

# 报告格式配置
REPORT_WIDTH = 60  # 报告分隔线宽度
SECTION_WIDTH = 25  # 章节标题宽度

# ==================== 以下为程序代码 ====================

# 计算完整的报告目录路径
REPORT_DIR = os.path.join(BASE_DIR, "项目分析报告", REPORT_DIR_NAME)

def safe_read_file(filepath):
    """安全读取文件，处理编码问题"""
    encodings = ['utf-8', 'gbk', 'gb2312', 'latin-1']
    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding) as f:
                return f.read(), encoding
        except UnicodeDecodeError:
            continue
    # 如果所有编码都失败，使用忽略错误的方式读取
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        return f.read(), 'utf-8'

def get_file_info(filepath):
    """获取文件基本信息 - 大小、行数等"""
    if not os.path.isfile(filepath):
        return None
    
    file_stat = os.stat(filepath)
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        line_count = sum(1 for _ in f)
    
    return {
        'name': os.path.basename(filepath),
        'path': os.path.dirname(filepath),
        'size': file_stat.st_size,
        'lines': line_count
    }

def extract_functions(content):
    """从C代码中提取函数定义"""
    functions = {}
    
    # 查找所有函数定义
    matches = list(re.finditer(FUNCTION_PATTERN, content, re.MULTILINE | re.DOTALL))
    
    for i, match in enumerate(matches):
        func_signature = match.group(1)  # 完整的函数签名
        func_name = match.group(2)      # 函数名
        
        # 查找函数的开始和结束位置
        start_pos = match.start()
        
        # 查找匹配的大括号来确定函数体范围
        brace_count = 0
        func_start = -1
        func_end = -1
        
        # 从匹配位置开始查找函数体的开始
        pos = content.find('{', start_pos)
        if pos != -1:
            func_start = pos
            brace_count = 1
            pos += 1
            
            # 查找匹配的结束大括号
            while pos < len(content) and brace_count > 0:
                if content[pos] == '{':
                    brace_count += 1
                elif content[pos] == '}':
                    brace_count -= 1
                pos += 1
            
            if brace_count == 0:
                func_end = pos
                func_body = content[func_start:func_end]
                functions[func_name] = {
                    'signature': func_signature,
                    'body': func_body,
                    'full_function': func_signature + func_body
                }
    
    return functions

def compare_functions(base_functions, target_functions):
    """比较两个文件中的函数差异"""
    differences = {
        'added': {},      # 目标文件中新增的函数
        'deleted': {},    # 目标文件中删除的函数  
        'modified': {}    # 修改的函数（两个文件中都有但内容不同）
    }
    
    # 查找新增的函数
    for func_name in target_functions:
        if func_name not in base_functions:
            differences['added'][func_name] = target_functions[func_name]
    
    # 查找删除的函数
    for func_name in base_functions:
        if func_name not in target_functions:
            differences['deleted'][func_name] = base_functions[func_name]
    
    # 查找修改的函数
    for func_name in base_functions:
        if func_name in target_functions:
            base_func = base_functions[func_name]['full_function']
            target_func = target_functions[func_name]['full_function']
            
            if base_func != target_func:
                differences['modified'][func_name] = {
                    'base': base_functions[func_name],
                    'target': target_functions[func_name]
                }
    
    return differences

def generate_function_diff_report(file1_info, file2_info, differences, report_path):
    """生成函数级别的差异报告（带序号和表情符号）"""
    with open(report_path, 'w', encoding='utf-8') as report:
        # 报告头部
        report.write("=" * REPORT_WIDTH + "\\n")
        report.write("                  函数级别差异分析报告\\n")
        report.write("=" * REPORT_WIDTH + "\\n")
        report.write(f"生成时间: {datetime.now()}\\n")
        report.write(f"比较文件: {file1_info['name']} ↔ {file2_info['name']}\\n\\n")
        
        # 1. 文件基本信息
        report.write("一、文件基本信息\\n")
        report.write("=" * SECTION_WIDTH + "\\n")
        report.write("1. 源文件 (基准项目08):\\n")
        report.write(f"   - 文件名: {file1_info['name']}\\n")
        report.write(f"   - 路径: {file1_info['path']}\\n")
        report.write(f"   - 大小: {file1_info['size']} 字节\\n")
        report.write(f"   - 行数: {file1_info['lines']} 行\\n\\n")
        
        report.write("2. 目标文件:\\n")
        report.write(f"   - 文件名: {file2_info['name']}\\n")
        report.write(f"   - 路径: {file2_info['path']}\\n")
        report.write(f"   - 大小: {file2_info['size']} 字节\\n")
        report.write(f"   - 行数: {file2_info['lines']} 行\\n\\n")
        
        # 2. 函数差异统计
        report.write("二、函数差异统计\\n")
        report.write("=" * SECTION_WIDTH + "\\n")
        report.write(f"1. 新增函数: {len(differences['added'])} 个\\n")
        report.write(f"2. 删除函数: {len(differences['deleted'])} 个\\n")
        report.write(f"3. 修改函数: {len(differences['modified'])} 个\\n")
        report.write(f"4. 总差异函数: {len(differences['added']) + len(differences['deleted']) + len(differences['modified'])} 个\\n\\n")
        
        # 3. 详细函数差异（带序号和表情符号）
        report.write("三、详细函数差异\\n")
        report.write("=" * SECTION_WIDTH + "\\n")
        
        # 3.1 新增函数（使用绿色对勾表情和序号）
        if differences['added']:
            report.write("\\n🎯 新增函数:\\n")
            report.write("-" * 20 + "\\n")
            for i, (func_name, func_info) in enumerate(differences['added'].items(), 1):
                report.write(f"\\n🔸 第{i}个新增函数: {func_name}\\n")
                report.write(f"完整函数:\\n{func_info['full_function']}\\n")
                report.write("-" * 40 + "\\n")
        
        # 3.2 删除函数（使用红色叉号表情和序号）
        if differences['deleted']:
            report.write("\\n🎯 删除函数:\\n")
            report.write("-" * 20 + "\\n")
            for i, (func_name, func_info) in enumerate(differences['deleted'].items(), 1):
                report.write(f"\\n❌ 第{i}个删除函数: {func_name}\\n")
                report.write(f"完整函数:\\n{func_info['full_function']}\\n")
                report.write("-" * 40 + "\\n")
        
        # 3.3 修改函数（使用黄色警告表情和序号）
        if differences['modified']:
            report.write("\\n🎯 修改函数:\\n")
            report.write("-" * 20 + "\\n")
            for i, (func_name, func_info) in enumerate(differences['modified'].items(), 1):
                report.write(f"\\n⚠️ 第{i}个修改函数: {func_name}\\n")
                
                report.write("\\n📄 基准项目中的函数:\\n")
                report.write(func_info['base']['full_function'])
                
                report.write("\\n\\n📄 目标项目中的函数:\\n")
                report.write(func_info['target']['full_function'])
                
                report.write("\\n" + "=" * 50 + "\\n")
        
        # 4. 总结
        report.write("\\n四、总结\\n")
        report.write("=" * SECTION_WIDTH + "\\n")
        
        total_changes = len(differences['added']) + len(differences['deleted']) + len(differences['modified'])
        
        if total_changes == 0:
            report.write("✅ 两个文件的函数内容完全一致\\n")
        else:
            report.write(f"📊 共发现 {total_changes} 个函数存在差异\\n")
            report.write("\\n💡 处理建议:\\n")
            
            if len(differences['modified']) > 0:
                report.write("   ⚠️  重点关注修改函数，检查逻辑变更\\n")
            if len(differences['added']) > 0:
                report.write("   🔸 验证新增函数的功能和必要性\\n")
            if len(differences['deleted']) > 0:
                report.write("   ❌ 确认删除函数不会影响现有功能\\n")
        
        report.write("\\n" + "=" * REPORT_WIDTH + "\\n")
        report.write("报告生成完成\\n")
        report.write("=" * REPORT_WIDTH + "\\n")

def find_project_main_files():
    """查找所有项目中的main.c文件"""
    projects = {}
    base_project_path = None
    
    # 查找所有项目文件夹
    project_dirs = [d for d in os.listdir(BASE_DIR) 
                   if os.path.isdir(os.path.join(BASE_DIR, d)) 
                   and d != "项目分析报告"]
    
    for project_dir in project_dirs:
        full_path = os.path.join(BASE_DIR, project_dir)
        
        # 确定扫描目录
        scan_dir = None
        for possible_dir in SCAN_DIRS:
            if os.path.exists(os.path.join(full_path, possible_dir)):
                scan_dir = os.path.join(full_path, possible_dir)
                break
        
        if not scan_dir:
            continue
        
        # 查找main.c文件
        main_c_path = os.path.join(scan_dir, MAIN_FILE_PATH, "main.c")
        if os.path.isfile(main_c_path):
            projects[project_dir] = main_c_path
            
            # 检查是否是基准项目
            if project_dir == BASE_PROJECT:
                base_project_path = main_c_path
    
    return projects, base_project_path

def compare_with_base_project():
    """将所有项目与基准项目08进行比较"""
    # 确保报告目录存在
    Path(REPORT_DIR).mkdir(parents=True, exist_ok=True)
    
    # 查找所有项目中的main.c文件
    projects, base_project_path = find_project_main_files()
    if not projects:
        print("未找到任何项目中的main.c文件")
        return
    
    if not base_project_path:
        print(f"错误: 未找到基准项目 {BASE_PROJECT} 的 main.c 文件")
        return
    
    # 获取基准项目文件信息
    base_info = get_file_info(base_project_path)
    if not base_info:
        print(f"错误: 无法读取基准项目文件 {base_project_path}")
        return
    
    # 读取基准项目内容并提取函数
    base_content, base_encoding = safe_read_file(base_project_path)
    base_functions = extract_functions(base_content)
    print(f"基准项目 {BASE_PROJECT} 中找到 {len(base_functions)} 个函数")
    
    # 比较所有项目与基准项目
    for project_name, project_file in projects.items():
        # 跳过基准项目自身
        if project_name == BASE_PROJECT:
            continue
        
        # 获取项目文件信息
        project_info = get_file_info(project_file)
        if not project_info:
            print(f"跳过对比: {project_file} 不存在")
            continue
        
        # 读取目标项目内容并提取函数
        project_content, project_encoding = safe_read_file(project_file)
        project_functions = extract_functions(project_content)
        print(f"项目 {project_name} 中找到 {len(project_functions)} 个函数")
        
        # 比较函数差异
        differences = compare_functions(base_functions, project_functions)
        
        # 生成报告文件名
        report_name = f"项目08_vs_{project_name}_函数差异分析{REPORT_EXTENSION}"
        report_path = os.path.join(REPORT_DIR, report_name)
        
        # 生成函数级别分析报告
        generate_function_diff_report(base_info, project_info, differences, report_path)
        
        print(f"已生成函数对比报告: 项目08 vs {project_name}")
        print(f"   - 报告路径: {report_path}")
        print(f"   - 发现差异: 新增{len(differences['added'])}个, 删除{len(differences['deleted'])}个, 修改{len(differences['modified'])}个函数")

def main():
    """主函数 - 协调整个函数差异分析流程"""
    try:
        print("开始扫描项目并与项目08进行函数级别对比...")
        compare_with_base_project()
        print("\\n✅ 所有函数差异分析完成！")
        print(f"📊 报告已保存至: {REPORT_DIR}")
        
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()

EOF`,
  type: 'python',
  varName: 'aw',
  size: 11662
};
var scriptCount = 23;
var indexToVarName = {
  1: 'aa',
  2: 'ab',
  3: 'ac',
  4: 'ad',
  5: 'ae',
  6: 'af',
  7: 'ag',
  8: 'ah',
  9: 'ai',
  10: 'aj',
  11: 'ak',
  12: 'al',
  13: 'am',
  14: 'an',
  15: 'ao',
  16: 'ap',
  17: 'aq',
  18: 'ar',
  19: 'as',
  20: 'at',
  21: 'au',
  22: 'av',
  23: 'aw'
};