// ==========================================
// 自动生成于 2025-11-21 13:05:40
// 源文件: /storage/emulated/0/Download/OnePlus Share/03 - 个人测试/测试网页/2025_GITHUB项目_去重后.txt
// 变量前缀: gh
// 共 300 个项目
// ==========================================

// [001] vinta/awesome-python
var gh001 = {
  index: 1,
  repo: 'vinta/awesome-python',
  desc: '这是一个关于优秀Python框架、库和资源的精选列表，旨在帮助开发者快速找到所需工具。',
  raw: 'vinta/awesome-python 这是一个关于优秀Python框架、库和资源的精选列表，旨在帮助开发者快速找到所需工具。',
  type: 'github_repo'
};

// [002] Significant-Gravitas/AutoGPT
var gh002 = {
  index: 2,
  repo: 'Significant-Gravitas/AutoGPT',
  desc: 'AutoGPT是一个强大的平台，允许用户创建、部署和管理持续的AI智能体，自动化复杂工作流程。',
  raw: 'Significant-Gravitas/AutoGPT AutoGPT是一个强大的平台，允许用户创建、部署和管理持续的AI智能体，自动化复杂工作流程。',
  type: 'github_repo'
};

// [003] AUTOMATIC1111/stable-diffusion-webui
var gh003 = {
  index: 3,
  repo: 'AUTOMATIC1111/stable-diffusion-webui',
  desc: '该仓库提供Stable Diffusion的网页界面，用户可以通过直观的方式实现文本生成图片及图像处理，如修复、放大和调整参数等功能。',
  raw: 'AUTOMATIC1111/stable-diffusion-webui 该仓库提供Stable Diffusion的网页界面，用户可以通过直观的方式实现文本生成图片及图像处理，如修复、放大和调整参数等功能。',
  type: 'github_repo'
};

// [004] ytdl-org/youtube-dl
var gh004 = {
  index: 4,
  repo: 'ytdl-org/youtube-dl',
  desc: 'youtube-dl是一个命令行程序，用于从YouTube及其他视频网站下载视频，方便用户在各种平台上离线观看。',
  raw: 'ytdl-org/youtube-dl youtube-dl是一个命令行程序，用于从YouTube及其他视频网站下载视频，方便用户在各种平台上离线观看。',
  type: 'github_repo'
};

// [005] yt-dlp/yt-dlp
var gh005 = {
  index: 5,
  repo: 'yt-dlp/yt-dlp',
  desc: 'yt-dlp是一个功能丰富的命令行音视频下载器，支持成千上万的网站，方便用户下载多种格式的媒体内容。',
  raw: 'yt-dlp/yt-dlp yt-dlp是一个功能丰富的命令行音视频下载器，支持成千上万的网站，方便用户下载多种格式的媒体内容。',
  type: 'github_repo'
};

// [006] langflow-ai/langflow
var gh006 = {
  index: 6,
  repo: 'langflow-ai/langflow',
  desc: 'Langflow是一个强大的工具，用于构建和部署AI驱动的代理和工作流程，提供可视化编辑界面和API集成功能。',
  raw: 'langflow-ai/langflow Langflow是一个强大的工具，用于构建和部署AI驱动的代理和工作流程，提供可视化编辑界面和API集成功能。',
  type: 'github_repo'
};

// [007] pytorch/pytorch
var gh007 = {
  index: 7,
  repo: 'pytorch/pytorch',
  desc: 'PyTorch是一个Python库，提供强大的GPU加速的张量计算和基于动态神经网络的自动微分系统，适用于深度学习应用。',
  raw: 'pytorch/pytorch PyTorch是一个Python库，提供强大的GPU加速的张量计算和基于动态神经网络的自动微分系统，适用于深度学习应用。',
  type: 'github_repo'
};

// [008] fastapi/fastapi
var gh008 = {
  index: 8,
  repo: 'fastapi/fastapi',
  desc: 'FastAPI是一个高性能的Python网络框架，旨在快速构建API，易于学习和编码，适合生产使用。',
  raw: 'fastapi/fastapi FastAPI是一个高性能的Python网络框架，旨在快速构建API，易于学习和编码，适合生产使用。',
  type: 'github_repo'
};

// [009] openai/whisper
var gh009 = {
  index: 9,
  repo: 'openai/whisper',
  desc: 'Whisper是一个通用的语音识别模型，能够进行多语言识别、语音翻译和语言识别，基于大规模弱监督训练。',
  raw: 'openai/whisper Whisper是一个通用的语音识别模型，能够进行多语言识别、语音翻译和语言识别，基于大规模弱监督训练。',
  type: 'github_repo'
};

// [010] comfyanonymous/ComfyUI
var gh010 = {
  index: 10,
  repo: 'comfyanonymous/ComfyUI',
  desc: 'ComfyUI是一个强大的模块化视觉AI引擎，提供图形节点界面，适用于开发和使用扩散模型的GUI、API和后端。',
  raw: 'comfyanonymous/ComfyUI ComfyUI是一个强大的模块化视觉AI引擎，提供图形节点界面，适用于开发和使用扩散模型的GUI、API和后端。',
  type: 'github_repo'
};

// [011] 3b1b/manim
var gh011 = {
  index: 11,
  repo: '3b1b/manim',
  desc: 'Manim是一个用于创建数学视频的动画引擎，支持精确的程序化动画创作。',
  raw: '3b1b/manim Manim是一个用于创建数学视频的动画引擎，支持精确的程序化动画创作。',
  type: 'github_repo'
};

// [012] tensorflow/models
var gh012 = {
  index: 12,
  repo: 'tensorflow/models',
  desc: 'TensorFlow模型园区是一个提供多种最新模型及实现的库，旨在帮助用户高效利用TensorFlow进行研究和产品开发。',
  raw: 'tensorflow/models TensorFlow模型园区是一个提供多种最新模型及实现的库，旨在帮助用户高效利用TensorFlow进行研究和产品开发。',
  type: 'github_repo'
};

// [013] fighting41love/funNLP
var gh013 = {
  index: 13,
  repo: 'fighting41love/funNLP',
  desc: 'funNLP是一个中文自然语言处理资源库，提供多种NLP工具和数据集，涵盖敏感词检测、语言识别、信息抽取等功能，适合研究和应用。',
  raw: 'fighting41love/funNLP funNLP是一个中文自然语言处理资源库，提供多种NLP工具和数据集，涵盖敏感词检测、语言识别、信息抽取等功能，适合研究和应用。',
  type: 'github_repo'
};

// [014] hacksider/Deep-Live-Cam
var gh014 = {
  index: 14,
  repo: 'hacksider/Deep-Live-Cam',
  desc: 'Deep-Live-Cam是一个实时换脸和一键视频换脸生成工具，仅需一张图片即可实现深度伪造。',
  raw: 'hacksider/Deep-Live-Cam Deep-Live-Cam是一个实时换脸和一键视频换脸生成工具，仅需一张图片即可实现深度伪造。',
  type: 'github_repo'
};

// [015] microsoft/markitdown
var gh015 = {
  index: 15,
  repo: 'microsoft/markitdown',
  desc: 'MarkItDown是一个轻量级的Python工具，用于将多种文件和办公文档转换为Markdown格式，便于文本分析和处理。',
  raw: 'microsoft/markitdown MarkItDown是一个轻量级的Python工具，用于将多种文件和办公文档转换为Markdown格式，便于文本分析和处理。',
  type: 'github_repo'
};

// [016] abi/screenshot-to-code
var gh016 = {
  index: 16,
  repo: 'abi/screenshot-to-code',
  desc: 'screenshot-to-code是一个将截图、模型和Figma设计转换为干净HTML、Tailwind、React和Vue代码的工具，支持多种AI模型生成代码。',
  raw: 'abi/screenshot-to-code screenshot-to-code是一个将截图、模型和Figma设计转换为干净HTML、Tailwind、React和Vue代码的工具，支持多种AI模型生成代码。',
  type: 'github_repo'
};

// [017] browser-use/browser-use
var gh017 = {
  index: 17,
  repo: 'browser-use/browser-use',
  desc: '这个仓库用于使网页可以被AI代理控制，从而轻松自动化在线任务。',
  raw: 'browser-use/browser-use 这个仓库用于使网页可以被AI代理控制，从而轻松自动化在线任务。',
  type: 'github_repo'
};

// [018] sherlock-project/sherlock
var gh018 = {
  index: 18,
  repo: 'sherlock-project/sherlock',
  desc: 'Sherlock是一个用Python开发的工具，可以根据用户名在多个社交媒体平台上查找相关账户，帮助用户维护在线隐私及安全。',
  raw: 'sherlock-project/sherlock Sherlock是一个用Python开发的工具，可以根据用户名在多个社交媒体平台上查找相关账户，帮助用户维护在线隐私及安全。',
  type: 'github_repo'
};

// [019] ansible/ansible
var gh019 = {
  index: 19,
  repo: 'ansible/ansible',
  desc: 'Ansible是一个简单的IT自动化平台，支持配置管理、应用部署、云服务和网络自动化，旨在提升系统维护与应用部署的效率。',
  raw: 'ansible/ansible Ansible是一个简单的IT自动化平台，支持配置管理、应用部署、云服务和网络自动化，旨在提升系统维护与应用部署的效率。',
  type: 'github_repo'
};

// [020] All-Hands-AI/OpenHands
var gh020 = {
  index: 20,
  repo: 'All-Hands-AI/OpenHands',
  desc: 'OpenHands是一个基于Python的工具，旨在降低编程复杂性，帮助用户更高效地创建项目。',
  raw: 'All-Hands-AI/OpenHands OpenHands是一个基于Python的工具，旨在降低编程复杂性，帮助用户更高效地创建项目。',
  type: 'github_repo'
};

// [021] FoundationAgents/MetaGPT
var gh021 = {
  index: 21,
  repo: 'FoundationAgents/MetaGPT',
  desc: 'MetaGPT 是一个多智能体框架，旨在通过协作处理复杂任务，实现自然语言编程，尤其适合AI软件公司使用。',
  raw: 'FoundationAgents/MetaGPT MetaGPT 是一个多智能体框架，旨在通过协作处理复杂任务，实现自然语言编程，尤其适合AI软件公司使用。',
  type: 'github_repo'
};

// [022] scrapy/scrapy
var gh022 = {
  index: 22,
  repo: 'scrapy/scrapy',
  desc: 'Scrapy是一个高效的Python网页爬虫和数据提取框架，适用于从网站提取结构化数据，支持跨平台使用。',
  raw: 'scrapy/scrapy Scrapy是一个高效的Python网页爬虫和数据提取框架，适用于从网站提取结构化数据，支持跨平台使用。',
  type: 'github_repo'
};

// [023] soimort/you-get
var gh023 = {
  index: 23,
  repo: 'soimort/you-get',
  desc: 'You-Get 是一个简易的命令行工具，用于从网络下载媒体内容（视频、音频、图片），适用于无法直接下载的情况。',
  raw: 'soimort/you-get You-Get 是一个简易的命令行工具，用于从网络下载媒体内容（视频、音频、图片），适用于无法直接下载的情况。',
  type: 'github_repo'
};

// [024] vllm-project/vllm
var gh024 = {
  index: 24,
  repo: 'vllm-project/vllm',
  desc: 'vllm是一个高吞吐量、内存高效的大语言模型推理和服务引擎，旨在为用户提供便捷且经济的LLM部署方案。',
  raw: 'vllm-project/vllm vllm是一个高吞吐量、内存高效的大语言模型推理和服务引擎，旨在为用户提供便捷且经济的LLM部署方案。',
  type: 'github_repo'
};

// [025] commaai/openpilot
var gh025 = {
  index: 25,
  repo: 'commaai/openpilot',
  desc: 'openpilot是一款为机器人提供操作系统的软件，旨在升级300多款汽车的驾驶辅助系统。',
  raw: 'commaai/openpilot openpilot是一款为机器人提供操作系统的软件，旨在升级300多款汽车的驾驶辅助系统。',
  type: 'github_repo'
};

// [026] ageitgey/face_recognition
var gh026 = {
  index: 26,
  repo: 'ageitgey/face_recognition',
  desc: '这是一个简单易用的Python面部识别库，支持命令行操作，能够识别和处理图像中的面部信息。',
  raw: 'ageitgey/face_recognition 这是一个简单易用的Python面部识别库，支持命令行操作，能够识别和处理图像中的面部信息。',
  type: 'github_repo'
};

// [027] ultralytics/yolov5
var gh027 = {
  index: 27,
  repo: 'ultralytics/yolov5',
  desc: 'YOLOv5是一个基于PyTorch的目标检测库，支持导出至ONNX、CoreML和TFLite，方便用户在多平台上进行高效的目标检测应用。',
  raw: 'ultralytics/yolov5 YOLOv5是一个基于PyTorch的目标检测库，支持导出至ONNX、CoreML和TFLite，方便用户在多平台上进行高效的目标检测应用。',
  type: 'github_repo'
};

// [028] AntonOsika/gpt-engineer
var gh028 = {
  index: 28,
  repo: 'AntonOsika/gpt-engineer',
  desc: 'gpt-engineer是一个CLI平台，允许用户通过自然语言指定软件，AI将根据指令生成和执行代码，适合代码生成实验。',
  raw: 'AntonOsika/gpt-engineer gpt-engineer是一个CLI平台，允许用户通过自然语言指定软件，AI将根据指令生成和执行代码，适合代码生成实验。',
  type: 'github_repo'
};

// [029] deepfakes/faceswap
var gh029 = {
  index: 29,
  repo: 'deepfakes/faceswap',
  desc: 'FaceSwap 是一款基于深度学习的工具，用于在图片和视频中识别人脸并进行换脸处理。',
  raw: 'deepfakes/faceswap FaceSwap 是一款基于深度学习的工具，用于在图片和视频中识别人脸并进行换脸处理。',
  type: 'github_repo'
};

// [030] Textualize/rich
var gh030 = {
  index: 30,
  repo: 'Textualize/rich',
  desc: 'Rich是一个Python库，用于在终端中实现丰富的文本和美观的格式化，提升命令行界面的用户体验。',
  raw: 'Textualize/rich Rich是一个Python库，用于在终端中实现丰富的文本和美观的格式化，提升命令行界面的用户体验。',
  type: 'github_repo'
};

// [031] Z4nzu/hackingtool
var gh031 = {
  index: 31,
  repo: 'Z4nzu/hackingtool',
  desc: '这个仓库是一个集成的黑客工具，提供多种功能，如信息收集、网络攻击和逆向工程等，适合黑客和安全研究人员使用。',
  raw: 'Z4nzu/hackingtool 这个仓库是一个集成的黑客工具，提供多种功能，如信息收集、网络攻击和逆向工程等，适合黑客和安全研究人员使用。',
  type: 'github_repo'
};

// [032] psf/requests
var gh032 = {
  index: 32,
  repo: 'psf/requests',
  desc: 'Requests 是一个简单优雅的 HTTP 库，旨在轻松发送 HTTP/1.1 请求，支持多种现代功能，如认证、连接池和自动内容解码等。',
  raw: 'psf/requests Requests 是一个简单优雅的 HTTP 库，旨在轻松发送 HTTP/1.1 请求，支持多种现代功能，如认证、连接池和自动内容解码等。',
  type: 'github_repo'
};

// [033] PaddlePaddle/PaddleOCR
var gh033 = {
  index: 33,
  repo: 'PaddlePaddle/PaddleOCR',
  desc: 'PaddleOCR是一个基于PaddlePaddle的多语言OCR和文档解析工具，支持80多种语言的识别，提供数据标注和合成工具，适用于服务器、移动设备及嵌入式设备的训练和部署。',
  raw: 'PaddlePaddle/PaddleOCR PaddleOCR是一个基于PaddlePaddle的多语言OCR和文档解析工具，支持80多种语言的识别，提供数据标注和合成工具，适用于服务器、移动设备及嵌入式设备的训练和部署。',
  type: 'github_repo'
};

// [034] unclecode/crawl4ai
var gh034 = {
  index: 34,
  repo: 'unclecode/crawl4ai',
  desc: 'Crawl4AI是一个开源的网页爬虫和数据抓取工具，旨在为LLM提供干净的Markdown格式数据，适用于RAG、代理和数据管道。',
  raw: 'unclecode/crawl4ai Crawl4AI是一个开源的网页爬虫和数据抓取工具，旨在为LLM提供干净的Markdown格式数据，适用于RAG、代理和数据管道。',
  type: 'github_repo'
};

// [035] RVC-Boss/GPT-SoVITS
var gh035 = {
  index: 35,
  repo: 'RVC-Boss/GPT-SoVITS',
  desc: 'GPT-SoVITS是一个功能强大的少量样本语音转换和文本到语音的Web界面，允许用户通过1分钟语音数据训练语音合成模型。',
  raw: 'RVC-Boss/GPT-SoVITS GPT-SoVITS是一个功能强大的少量样本语音转换和文本到语音的Web界面，允许用户通过1分钟语音数据训练语音合成模型。',
  type: 'github_repo'
};

// [036] FoundationAgents/OpenManus
var gh036 = {
  index: 36,
  repo: 'FoundationAgents/OpenManus',
  desc: 'OpenManus是一个开放式项目，旨在帮助用户无须邀请代码便能实现各种创意，支持个性化代理的创建及强化学习调优。',
  raw: 'FoundationAgents/OpenManus OpenManus是一个开放式项目，旨在帮助用户无须邀请代码便能实现各种创意，支持个性化代理的创建及强化学习调优。',
  type: 'github_repo'
};

// [037] charlax/professional-programming
var gh037 = {
  index: 37,
  repo: 'charlax/professional-programming',
  desc: '该仓库提供软件工程师学习资源的集合，包括书籍、文章和课程，从而帮助提升专业技能和知识。',
  raw: 'charlax/professional-programming 该仓库提供软件工程师学习资源的集合，包括书籍、文章和课程，从而帮助提升专业技能和知识。',
  type: 'github_repo'
};

// [038] lllyasviel/Fooocus
var gh038 = {
  index: 38,
  repo: 'lllyasviel/Fooocus',
  desc: 'Fooocus 是一款基于 Gradio 的离线图像生成软件，旨在简化用户生成图像的过程，只需关注提示和图像本身，适合快速生成需求。',
  raw: 'lllyasviel/Fooocus Fooocus 是一款基于 Gradio 的离线图像生成软件，旨在简化用户生成图像的过程，只需关注提示和图像本身，适合快速生成需求。',
  type: 'github_repo'
};

// [039] ultralytics/ultralytics
var gh039 = {
  index: 39,
  repo: 'ultralytics/ultralytics',
  desc: 'Ultralytics YOLO是一个基于Python的计算机视觉和深度学习框架，专注于物体检测与实例分割，适用于各种AI应用。',
  raw: 'ultralytics/ultralytics Ultralytics YOLO是一个基于Python的计算机视觉和深度学习框架，专注于物体检测与实例分割，适用于各种AI应用。',
  type: 'github_repo'
};

// [040] unslothai/unsloth
var gh040 = {
  index: 40,
  repo: 'unslothai/unsloth',
  desc: '此仓库提供针对大语言模型的微调和强化学习工具，支持多种模型以提高训练速度和降低内存使用，适合初学者使用。',
  raw: 'unslothai/unsloth 此仓库提供针对大语言模型的微调和强化学习工具，支持多种模型以提高训练速度和降低内存使用，适合初学者使用。',
  type: 'github_repo'
};

// [041] run-llama/llama_index
var gh041 = {
  index: 41,
  repo: 'run-llama/llama_index',
  desc: 'LlamaIndex是一个构建基于大型语言模型的代理框架，专注于数据处理和分析，帮助用户更高效地利用数据。',
  raw: 'run-llama/llama_index LlamaIndex是一个构建基于大型语言模型的代理框架，专注于数据处理和分析，帮助用户更高效地利用数据。',
  type: 'github_repo'
};

// [042] opendatalab/MinerU
var gh042 = {
  index: 42,
  repo: 'opendatalab/MinerU',
  desc: 'MinerU是一款高质量的开源工具，将PDF文件转换为Markdown和JSON格式，便于数据提取和处理。',
  raw: 'opendatalab/MinerU MinerU是一款高质量的开源工具，将PDF文件转换为Markdown和JSON格式，便于数据提取和处理。',
  type: 'github_repo'
};

// [043] coqui-ai/TTS
var gh043 = {
  index: 43,
  repo: 'coqui-ai/TTS',
  desc: 'TTS是一个高级文本转语音生成库，支持多达1100种语言，提供预训练模型和模型训练、微调工具，适用于研究和生产环境。',
  raw: 'coqui-ai/TTS TTS是一个高级文本转语音生成库，支持多达1100种语言，提供预训练模型和模型训练、微调工具，适用于研究和生产环境。',
  type: 'github_repo'
};

// [044] getsentry/sentry
var gh044 = {
  index: 44,
  repo: 'getsentry/sentry',
  desc: 'Sentry是一个以开发者为中心的错误追踪和性能监控平台，帮助开发者快速检测、追踪和修复问题。',
  raw: 'getsentry/sentry Sentry是一个以开发者为中心的错误追踪和性能监控平台，帮助开发者快速检测、追踪和修复问题。',
  type: 'github_repo'
};

// [045] apache/airflow
var gh045 = {
  index: 45,
  repo: 'apache/airflow',
  desc: 'Apache Airflow是一个用于程序化创建、调度和监控工作流的平台，适合数据工程师和开发者使用。',
  raw: 'apache/airflow Apache Airflow是一个用于程序化创建、调度和监控工作流的平台，适合数据工程师和开发者使用。',
  type: 'github_repo'
};

// [046] mingrammer/diagrams
var gh046 = {
  index: 46,
  repo: 'mingrammer/diagrams',
  desc: 'Diagrams库允许用户通过Python代码绘制云系统架构图，适用于快速原型设计和现有系统可视化，支持主要云服务商。',
  raw: 'mingrammer/diagrams Diagrams库允许用户通过Python代码绘制云系统架构图，适用于快速原型设计和现有系统可视化，支持主要云服务商。',
  type: 'github_repo'
};

// [047] zai-org/ChatGLM-6B
var gh047 = {
  index: 47,
  repo: 'zai-org/ChatGLM-6B',
  desc: 'ChatGLM-6B 是一个开源的双语对话语言模型，支持本地部署，优化了中英问答，适合开发者定制应用。',
  raw: 'zai-org/ChatGLM-6B ChatGLM-6B 是一个开源的双语对话语言模型，支持本地部署，优化了中英问答，适合开发者定制应用。',
  type: 'github_repo'
};

// [048] hpcaitech/ColossalAI
var gh048 = {
  index: 48,
  repo: 'hpcaitech/ColossalAI',
  desc: 'ColossalAI旨在降低大型AI模型的成本、加快训练速度，并提高可访问性，适用于研究人员进行高效计算。',
  raw: 'hpcaitech/ColossalAI ColossalAI旨在降低大型AI模型的成本、加快训练速度，并提高可访问性，适用于研究人员进行高效计算。',
  type: 'github_repo'
};

// [049] psf/black
var gh049 = {
  index: 49,
  repo: 'psf/black',
  desc: 'Black是一个不妥协的Python代码格式化工具，旨在提升代码一致性和可读性，节省开发者的格式化时间和精力。',
  raw: 'psf/black Black是一个不妥协的Python代码格式化工具，旨在提升代码一致性和可读性，节省开发者的格式化时间和精力。',
  type: 'github_repo'
};

// [050] mitmproxy/mitmproxy
var gh050 = {
  index: 50,
  repo: 'mitmproxy/mitmproxy',
  desc: 'mitmproxy是一个交互式的HTTP代理工具，支持TLS，用于渗透测试和软件开发，方便用户拦截和修改HTTP请求和响应。',
  raw: 'mitmproxy/mitmproxy mitmproxy是一个交互式的HTTP代理工具，支持TLS，用于渗透测试和软件开发，方便用户拦截和修改HTTP请求和响应。',
  type: 'github_repo'
};

// [051] gradio-app/gradio
var gh051 = {
  index: 51,
  repo: 'gradio-app/gradio',
  desc: 'Gradio是一个用Python构建和分享机器学习应用的工具，简单易用，适合快速创建AI应用。',
  raw: 'gradio-app/gradio Gradio是一个用Python构建和分享机器学习应用的工具，简单易用，适合快速创建AI应用。',
  type: 'github_repo'
};

// [052] google-research/bert
var gh052 = {
  index: 52,
  repo: 'google-research/bert',
  desc: '该仓库提供了BERT模型的TensorFlow代码和预训练模型，包括多个小型BERT模型，适用于资源有限的环境。',
  raw: 'google-research/bert 该仓库提供了BERT模型的TensorFlow代码和预训练模型，包括多个小型BERT模型，适用于资源有限的环境。',
  type: 'github_repo'
};

// [053] harry0703/MoneyPrinterTurbo
var gh053 = {
  index: 53,
  repo: 'harry0703/MoneyPrinterTurbo',
  desc: 'MoneyPrinterTurbo 是一个利用 AI 大模型一键生成高清短视频的工具，用户只需提供主题或关键词即可自动生成视频内容。',
  raw: 'harry0703/MoneyPrinterTurbo MoneyPrinterTurbo 是一个利用 AI 大模型一键生成高清短视频的工具，用户只需提供主题或关键词即可自动生成视频内容。',
  type: 'github_repo'
};

// [054] lm-sys/FastChat
var gh054 = {
  index: 54,
  repo: 'lm-sys/FastChat',
  desc: 'FastChat是一个开放平台，用于训练、服务和评估大型语言模型的聊天机器人，支持模型竞争和用户投票。',
  raw: 'lm-sys/FastChat FastChat是一个开放平台，用于训练、服务和评估大型语言模型的聊天机器人，支持模型竞争和用户投票。',
  type: 'github_repo'
};

// [055] zhayujie/chatgpt-on-wechat
var gh055 = {
  index: 55,
  repo: 'zhayujie/chatgpt-on-wechat',
  desc: 'ChatGPT on WeChat是一个智能聊天机器人，支持多种平台接入，可处理多模态消息，集成多种大模型，适用于智能客服和企业应用。',
  raw: 'zhayujie/chatgpt-on-wechat ChatGPT on WeChat是一个智能聊天机器人，支持多种平台接入，可处理多模态消息，集成多种大模型，适用于智能客服和企业应用。',
  type: 'github_repo'
};

// [056] mem0ai/mem0
var gh056 = {
  index: 56,
  repo: 'mem0ai/mem0',
  desc: 'mem0是一个为AI代理提供的通用记忆层，支持本地和安全的记忆管理，旨在提升个性化AI的性能和效率。',
  raw: 'mem0ai/mem0 mem0是一个为AI代理提供的通用记忆层，支持本地和安全的记忆管理，旨在提升个性化AI的性能和效率。',
  type: 'github_repo'
};

// [057] QuivrHQ/quivr
var gh057 = {
  index: 57,
  repo: 'QuivrHQ/quivr',
  desc: 'Quivr是一个利用生成式AI构建个人助手的工具，支持多种文件格式和LLM，并可自定义快速集成到现有产品中。',
  raw: 'QuivrHQ/quivr Quivr是一个利用生成式AI构建个人助手的工具，支持多种文件格式和LLM，并可自定义快速集成到现有产品中。',
  type: 'github_repo'
};

// [058] 2noise/ChatTTS
var gh058 = {
  index: 58,
  repo: '2noise/ChatTTS',
  desc: 'ChatTTS是一个专为日常对话场景优化的文本转语音模型，旨在提供自然流畅的语音合成。',
  raw: '2noise/ChatTTS ChatTTS是一个专为日常对话场景优化的文本转语音模型，旨在提供自然流畅的语音合成。',
  type: 'github_repo'
};

// [059] TencentARC/GFPGAN
var gh059 = {
  index: 59,
  repo: 'TencentARC/GFPGAN',
  desc: 'GFPGAN旨在开发实用的算法，以实现真实世界中的人脸修复，提供高质量的图像恢复功能。',
  raw: 'TencentARC/GFPGAN GFPGAN旨在开发实用的算法，以实现真实世界中的人脸修复，提供高质量的图像恢复功能。',
  type: 'github_repo'
};

// [060] Aider-AI/aider
var gh060 = {
  index: 60,
  repo: 'Aider-AI/aider',
  desc: 'Aider是一个终端中的AI协同编程工具，允许开发者与大型语言模型共创项目或扩展现有代码库。',
  raw: 'Aider-AI/aider Aider是一个终端中的AI协同编程工具，允许开发者与大型语言模型共创项目或扩展现有代码库。',
  type: 'github_repo'
};

// [061] docling-project/docling
var gh061 = {
  index: 61,
  repo: 'docling-project/docling',
  desc: 'Docling是一个用于准备文档以适配生成式人工智能的工具，旨在提升文档处理效率和质量。',
  raw: 'docling-project/docling Docling是一个用于准备文档以适配生成式人工智能的工具，旨在提升文档处理效率和质量。',
  type: 'github_repo'
};

// [062] hiroi-sora/Umi-OCR
var gh062 = {
  index: 62,
  repo: 'hiroi-sora/Umi-OCR',
  desc: 'Umi-OCR是一个免费的开源离线OCR软件，支持截图、批量图片和PDF文档识别，具有多语言识别能力，使用方便高效。',
  raw: 'hiroi-sora/Umi-OCR Umi-OCR是一个免费的开源离线OCR软件，支持截图、批量图片和PDF文档识别，具有多语言识别能力，使用方便高效。',
  type: 'github_repo'
};

// [063] NanmiCoder/MediaCrawler
var gh063 = {
  index: 63,
  repo: 'NanmiCoder/MediaCrawler',
  desc: 'MediaCrawler是一款多平台自媒体数据采集工具，支持小红书、抖音、快手等平台的公开信息爬取，可用于学习和研究。',
  raw: 'NanmiCoder/MediaCrawler MediaCrawler是一款多平台自媒体数据采集工具，支持小红书、抖音、快手等平台的公开信息爬取，可用于学习和研究。',
  type: 'github_repo'
};

// [064] XingangPan/DragGAN
var gh064 = {
  index: 64,
  repo: 'XingangPan/DragGAN',
  desc: 'DragGAN是一个用于生成图像的交互式点基操控工具，支持用户对生成图像进行高效编辑和修改。',
  raw: 'XingangPan/DragGAN DragGAN是一个用于生成图像的交互式点基操控工具，支持用户对生成图像进行高效编辑和修改。',
  type: 'github_repo'
};

// [065] hankcs/HanLP
var gh065 = {
  index: 65,
  repo: 'hankcs/HanLP',
  desc: 'HanLP是一个多语言自然语言处理库，提供中文分词、词性标注、命名实体识别等多种功能，旨在为研究和企业提供高效、用户友好的解决方案。',
  raw: 'hankcs/HanLP HanLP是一个多语言自然语言处理库，提供中文分词、词性标注、命名实体识别等多种功能，旨在为研究和企业提供高效、用户友好的解决方案。',
  type: 'github_repo'
};

// [066] myshell-ai/OpenVoice
var gh066 = {
  index: 66,
  repo: 'myshell-ai/OpenVoice',
  desc: 'OpenVoice是一个即时语音克隆工具，支持多种语言和口音，并允许用户灵活控制声音样式，适用于多种商业用途。',
  raw: 'myshell-ai/OpenVoice OpenVoice是一个即时语音克隆工具，支持多种语言和口音，并允许用户灵活控制声音样式，适用于多种商业用途。',
  type: 'github_repo'
};

// [067] sqlmapproject/sqlmap
var gh067 = {
  index: 67,
  repo: 'sqlmapproject/sqlmap',
  desc: 'sqlmap是一个开源的渗透测试工具，自动检测和利用SQL注入漏洞，支持数据库接管和系统命令执行。',
  raw: 'sqlmapproject/sqlmap sqlmap是一个开源的渗透测试工具，自动检测和利用SQL注入漏洞，支持数据库接管和系统命令执行。',
  type: 'github_repo'
};

// [068] karpathy/nanochat
var gh068 = {
  index: 68,
  repo: 'karpathy/nanochat',
  desc: 'nanochat是一款简洁易用的全栈实现ChatGPT的程序，支持从训练到推理的一整套流程，用户可以通过简单的网络界面与其交互。',
  raw: 'karpathy/nanochat nanochat是一款简洁易用的全栈实现ChatGPT的程序，支持从训练到推理的一整套流程，用户可以通过简单的网络界面与其交互。',
  type: 'github_repo'
};

// [069] fxsjy/jieba
var gh069 = {
  index: 69,
  repo: 'fxsjy/jieba',
  desc: '结巴中文分词是一个Python中文分词模块，支持多种分词模式，如精确、全模式和搜索引擎模式，方便文本分析和处理。',
  raw: 'fxsjy/jieba 结巴中文分词是一个Python中文分词模块，支持多种分词模式，如精确、全模式和搜索引擎模式，方便文本分析和处理。',
  type: 'github_repo'
};

// [070] python-poetry/poetry
var gh070 = {
  index: 70,
  repo: 'python-poetry/poetry',
  desc: 'Poetry是一个Python项目的依赖管理工具，简化了依赖声明和安装，替代了传统的setup.py等文件，使用pyproject.toml格式管理项目。',
  raw: 'python-poetry/poetry Poetry是一个Python项目的依赖管理工具，简化了依赖声明和安装，替代了传统的setup.py等文件，使用pyproject.toml格式管理项目。',
  type: 'github_repo'
};

// [071] Pythagora-io/gpt-pilot
var gh071 = {
  index: 71,
  repo: 'Pythagora-io/gpt-pilot',
  desc: 'GPT Pilot是一个AI开发者助手，能够生成代码、构建应用、调试功能并与用户互动，提升开发效率。',
  raw: 'Pythagora-io/gpt-pilot GPT Pilot是一个AI开发者助手，能够生成代码、构建应用、调试功能并与用户互动，提升开发效率。',
  type: 'github_repo'
};

// [072] jingyaogong/minimind
var gh072 = {
  index: 72,
  repo: 'jingyaogong/minimind',
  desc: 'Minimind项目旨在用仅3元成本和2小时，从零开始训练一个26M参数的小型GPT语言模型，提供全流程代码教程，助力AI社区进步。',
  raw: 'jingyaogong/minimind Minimind项目旨在用仅3元成本和2小时，从零开始训练一个26M参数的小型GPT语言模型，提供全流程代码教程，助力AI社区进步。',
  type: 'github_repo'
};

// [073] lllyasviel/ControlNet
var gh073 = {
  index: 73,
  repo: 'lllyasviel/ControlNet',
  desc: 'ControlNet是一个神经网络结构，通过添加额外条件来控制扩散模型，方便在小规模数据集上进行训练而不破坏原有模型。',
  raw: 'lllyasviel/ControlNet ControlNet是一个神经网络结构，通过添加额外条件来控制扩散模型，方便在小规模数据集上进行训练而不破坏原有模型。',
  type: 'github_repo'
};

// [074] facebookresearch/detectron2
var gh074 = {
  index: 74,
  repo: 'facebookresearch/detectron2',
  desc: 'Detectron2是一个用于目标检测、分割及其他视觉识别任务的平台，提供先进的算法和丰富的功能，支持研究与生产应用。',
  raw: 'facebookresearch/detectron2 Detectron2是一个用于目标检测、分割及其他视觉识别任务的平台，提供先进的算法和丰富的功能，支持研究与生产应用。',
  type: 'github_repo'
};

// [075] xinntao/Real-ESRGAN
var gh075 = {
  index: 75,
  repo: 'xinntao/Real-ESRGAN',
  desc: 'Real-ESRGAN旨在开发适用于图像和视频恢复的实用算法，提供高效的超分辨率处理效果。',
  raw: 'xinntao/Real-ESRGAN Real-ESRGAN旨在开发适用于图像和视频恢复的实用算法，提供高效的超分辨率处理效果。',
  type: 'github_repo'
};

// [076] explosion/spaCy
var gh076 = {
  index: 76,
  repo: 'explosion/spaCy',
  desc: 'spaCy是一个用于高级自然语言处理的Python库，支持多种语言的标记化、训练和命名实体识别等功能，适用于工业级应用。',
  raw: 'explosion/spaCy spaCy是一个用于高级自然语言处理的Python库，支持多种语言的标记化、训练和命名实体识别等功能，适用于工业级应用。',
  type: 'github_repo'
};

// [077] agno-agi/agno
var gh077 = {
  index: 77,
  repo: 'agno-agi/agno',
  desc: 'Agno是一个开源框架，用于构建具备记忆、知识和推理能力的多智能体系统，支持从简单工具到复杂协作的多层次智能体搭建。',
  raw: 'agno-agi/agno Agno是一个开源框架，用于构建具备记忆、知识和推理能力的多智能体系统，支持从简单工具到复杂协作的多层次智能体搭建。',
  type: 'github_repo'
};

// [078] facebookresearch/fairseq
var gh078 = {
  index: 78,
  repo: 'facebookresearch/fairseq',
  desc: 'Fairseq是一个由Facebook AI Research开发的序列建模工具包，支持训练翻译、摘要、语言建模等自定义模型。',
  raw: 'facebookresearch/fairseq Fairseq是一个由Facebook AI Research开发的序列建模工具包，支持训练翻译、摘要、语言建模等自定义模型。',
  type: 'github_repo'
};

// [079] RVC-Project/Retrieval-based-Voice-Conversion-WebUI
var gh079 = {
  index: 79,
  repo: 'RVC-Project/Retrieval-based-Voice-Conversion-WebUI',
  desc: 'Retrieval-based-Voice-Conversion-WebUI是一个基于VITS的变声框架，用户可以轻松训练适用于10分钟以内语音数据的变声模型。',
  raw: 'RVC-Project/Retrieval-based-Voice-Conversion-WebUI Retrieval-based-Voice-Conversion-WebUI是一个基于VITS的变声框架，用户可以轻松训练适用于10分钟以内语音数据的变声模型。',
  type: 'github_repo'
};

// [080] ocrmypdf/OCRmyPDF
var gh080 = {
  index: 80,
  repo: 'ocrmypdf/OCRmyPDF',
  desc: 'OCRmyPDF为扫描的PDF文件添加OCR文本层，允许搜索和复制粘贴，提升文档的可用性。',
  raw: 'ocrmypdf/OCRmyPDF OCRmyPDF为扫描的PDF文件添加OCR文本层，允许搜索和复制粘贴，提升文档的可用性。',
  type: 'github_repo'
};

// [081] khoj-ai/khoj
var gh081 = {
  index: 81,
  repo: 'khoj-ai/khoj',
  desc: 'khoj是一个自托管的个人AI应用，支持从网络或文档获取答案，构建自定义代理，调度自动化，进行深度研究，帮助用户提升能力。',
  raw: 'khoj-ai/khoj khoj是一个自托管的个人AI应用，支持从网络或文档获取答案，构建自定义代理，调度自动化，进行深度研究，帮助用户提升能力。',
  type: 'github_repo'
};

// [082] huggingface/diffusers
var gh082 = {
  index: 82,
  repo: 'huggingface/diffusers',
  desc: 'diffusers是一个用于生成图像、音频和三维分子结构的预训练扩散模型库，支持简单推理和自定义模型训练，专注于用户体验。',
  raw: 'huggingface/diffusers diffusers是一个用于生成图像、音频和三维分子结构的预训练扩散模型库，支持简单推理和自定义模型训练，专注于用户体验。',
  type: 'github_repo'
};

// [083] tqdm/tqdm
var gh083 = {
  index: 83,
  repo: 'tqdm/tqdm',
  desc: 'tqdm是一个快速、可扩展的Python进度条库，通过简单的封装使循环可视化，支持各种平台的终端和图形用户界面。',
  raw: 'tqdm/tqdm tqdm是一个快速、可扩展的Python进度条库，通过简单的封装使循环可视化，支持各种平台的终端和图形用户界面。',
  type: 'github_repo'
};

// [084] s0md3v/roop
var gh084 = {
  index: 84,
  repo: 's0md3v/roop',
  desc: 'Roop是一个一键换脸工具，可在视频中用选择的人脸替换指定人脸，只需一张目标人脸的图片，无需数据集和训练。',
  raw: 's0md3v/roop Roop是一个一键换脸工具，可在视频中用选择的人脸替换指定人脸，只需一张目标人脸的图片，无需数据集和训练。',
  type: 'github_repo'
};

// [085] nicolargo/glances
var gh085 = {
  index: 85,
  repo: 'nicolargo/glances',
  desc: 'Glances是一个开源的跨平台系统监控工具，实时监测CPU、内存、磁盘和网络等系统信息，适用于多种操作系统。',
  raw: 'nicolargo/glances Glances是一个开源的跨平台系统监控工具，实时监测CPU、内存、磁盘和网络等系统信息，适用于多种操作系统。',
  type: 'github_repo'
};

// [086] iperov/DeepFaceLive
var gh086 = {
  index: 86,
  repo: 'iperov/DeepFaceLive',
  desc: 'DeepFaceLive 是一款实时换脸软件，适用于PC直播和视频通话，可以通过训练的人脸模型实现人脸替换。',
  raw: 'iperov/DeepFaceLive DeepFaceLive 是一款实时换脸软件，适用于PC直播和视频通话，可以通过训练的人脸模型实现人脸替换。',
  type: 'github_repo'
};

// [087] StevenBlack/hosts
var gh087 = {
  index: 87,
  repo: 'StevenBlack/hosts',
  desc: '该仓库是一个代理服务器的统一 hosts 文件聚合器，整合多个来源的优质 hosts 文件，并提供可选扩展，帮助用户屏蔽广告及不良网站。',
  raw: 'StevenBlack/hosts 该仓库是一个代理服务器的统一 hosts 文件聚合器，整合多个来源的优质 hosts 文件，并提供可选扩展，帮助用户屏蔽广告及不良网站。',
  type: 'github_repo'
};

// [088] microsoft/qlib
var gh088 = {
  index: 88,
  repo: 'microsoft/qlib',
  desc: 'Qlib是一个面向AI的量化投资平台，利用AI技术支持量化研究，涵盖从创意探索到生产实施的各个环节，并支持多种机器学习建模方式。',
  raw: 'microsoft/qlib Qlib是一个面向AI的量化投资平台，利用AI技术支持量化研究，涵盖从创意探索到生产实施的各个环节，并支持多种机器学习建模方式。',
  type: 'github_repo'
};

// [089] jumpserver/jumpserver
var gh089 = {
  index: 89,
  repo: 'jumpserver/jumpserver',
  desc: 'JumpServer是一个开源特权访问管理(PAM)工具，为DevOps和IT团队提供通过网页浏览器安全地访问SSH、RDP、Kubernetes、数据库和远程应用程序的功能。',
  raw: 'jumpserver/jumpserver JumpServer是一个开源特权访问管理(PAM)工具，为DevOps和IT团队提供通过网页浏览器安全地访问SSH、RDP、Kubernetes、数据库和远程应用程序的功能。',
  type: 'github_repo'
};

// [090] PostHog/posthog
var gh090 = {
  index: 90,
  repo: 'PostHog/posthog',
  desc: 'PostHog是一个开源的网页和产品分析平台，提供会话录制、功能标记和A/B测试，支持自托管，帮助用户更好地理解产品使用情况。',
  raw: 'PostHog/posthog PostHog是一个开源的网页和产品分析平台，提供会话录制、功能标记和A/B测试，支持自托管，帮助用户更好地理解产品使用情况。',
  type: 'github_repo'
};

// [091] dgtlmoon/changedetection.io
var gh091 = {
  index: 91,
  repo: 'dgtlmoon/changedetection.io',
  desc: 'changedetection.io是一个网站监测工具，自动检测网页变化并即时通知用户，支持内容监控、价格变更和网站篡改警报。',
  raw: 'dgtlmoon/changedetection.io changedetection.io是一个网站监测工具，自动检测网页变化并即时通知用户，支持内容监控、价格变更和网站篡改警报。',
  type: 'github_repo'
};

// [092] datalab-to/marker
var gh092 = {
  index: 92,
  repo: 'datalab-to/marker',
  desc: 'Marker是一个快速准确地将PDF及多种文档格式转换为Markdown和JSON的工具，支持提取图像及格式化复杂内容。',
  raw: 'datalab-to/marker Marker是一个快速准确地将PDF及多种文档格式转换为Markdown和JSON的工具，支持提取图像及格式化复杂内容。',
  type: 'github_repo'
};

// [093] python-telegram-bot/python-telegram-bot
var gh093 = {
  index: 93,
  repo: 'python-telegram-bot/python-telegram-bot',
  desc: 'python-telegram-bot是一个用于开发Telegram机器人的Python封装库，使开发者能够轻松构建和管理Telegram Bot。',
  raw: 'python-telegram-bot/python-telegram-bot python-telegram-bot是一个用于开发Telegram机器人的Python封装库，使开发者能够轻松构建和管理Telegram Bot。',
  type: 'github_repo'
};

// [094] google/python-fire
var gh094 = {
  index: 94,
  repo: 'google/python-fire',
  desc: 'Python Fire是一个库，可以从任何Python对象自动生成命令行接口（CLI），方便开发和调试Python代码。',
  raw: 'google/python-fire Python Fire是一个库，可以从任何Python对象自动生成命令行接口（CLI），方便开发和调试Python代码。',
  type: 'github_repo'
};

// [095] BerriAI/litellm
var gh095 = {
  index: 95,
  repo: 'BerriAI/litellm',
  desc: 'LiteLLM是一个Python SDK和代理服务器，支持调用100多个以OpenAI格式提供的LLM API，如Azure、OpenAI和HuggingFace等，方便用户接入各类语言模型。',
  raw: 'BerriAI/litellm LiteLLM是一个Python SDK和代理服务器，支持调用100多个以OpenAI格式提供的LLM API，如Azure、OpenAI和HuggingFace等，方便用户接入各类语言模型。',
  type: 'github_repo'
};

// [096] JaidedAI/EasyOCR
var gh096 = {
  index: 96,
  repo: 'JaidedAI/EasyOCR',
  desc: 'EasyOCR是一个即用型OCR库，支持80多种语言和多种书写脚本，提供便捷的文字识别功能。',
  raw: 'JaidedAI/EasyOCR EasyOCR是一个即用型OCR库，支持80多种语言和多种书写脚本，提供便捷的文字识别功能。',
  type: 'github_repo'
};

// [097] getredash/redash
var gh097 = {
  index: 97,
  repo: 'getredash/redash',
  desc: 'Redash 是一个数据可视化和共享工具，支持通过 SQL 查询多种数据源，使团队能够快速获取、分析和分享数据，助力数据驱动决策。',
  raw: 'getredash/redash Redash 是一个数据可视化和共享工具，支持通过 SQL 查询多种数据源，使团队能够快速获取、分析和分享数据，助力数据驱动决策。',
  type: 'github_repo'
};

// [098] svc-develop-team/so-vits-svc
var gh098 = {
  index: 98,
  repo: 'svc-develop-team/so-vits-svc',
  desc: 'so-vits-svc是一个用于歌声转换的开源项目，专注于将虚拟角色的声音合成演唱，适合开发者实现动漫角色歌唱功能。',
  raw: 'svc-develop-team/so-vits-svc so-vits-svc是一个用于歌声转换的开源项目，专注于将虚拟角色的声音合成演唱，适合开发者实现动漫角色歌唱功能。',
  type: 'github_repo'
};

// [099] deezer/spleeter
var gh099 = {
  index: 99,
  repo: 'deezer/spleeter',
  desc: 'Spleeter是Deezer开发的源分离库，提供预训练模型，支持音频中人声与伴奏、鼓、低音等音轨的分离，简化了音频处理流程。',
  raw: 'deezer/spleeter Spleeter是Deezer开发的源分离库，提供预训练模型，支持音频中人声与伴奏、鼓、低音等音轨的分离，简化了音频处理流程。',
  type: 'github_repo'
};

// [100] stanford-oval/storm
var gh100 = {
  index: 100,
  repo: 'stanford-oval/storm',
  desc: 'STORM 是一个基于大型语言模型的知识整理系统，能够研究主题并生成带引用的完整报告。',
  raw: 'stanford-oval/storm STORM 是一个基于大型语言模型的知识整理系统，能够研究主题并生成带引用的完整报告。',
  type: 'github_repo'
};

// [101] celery/celery
var gh101 = {
  index: 101,
  repo: 'celery/celery',
  desc: 'Celery 是一个分布式任务队列，用于处理异步任务，支持使用 RabbitMQ 和 Redis 等消息代理进行任务调度和管理。',
  raw: 'celery/celery Celery 是一个分布式任务队列，用于处理异步任务，支持使用 RabbitMQ 和 Redis 等消息代理进行任务调度和管理。',
  type: 'github_repo'
};

// [102] hpcaitech/Open-Sora
var gh102 = {
  index: 102,
  repo: 'hpcaitech/Open-Sora',
  desc: 'Open-Sora旨在以高效方式制作高质量视频，提供开放源代码工具，简化视频生成复杂性，促进创意与创新。',
  raw: 'hpcaitech/Open-Sora Open-Sora旨在以高效方式制作高质量视频，提供开放源代码工具，简化视频生成复杂性，促进创意与创新。',
  type: 'github_repo'
};

// [103] locustio/locust
var gh103 = {
  index: 103,
  repo: 'locustio/locust',
  desc: 'Locust是一个开源的性能/负载测试工具，支持使用Python编写可扩展的测试脚本，适用于HTTP等协议，并提供命令行和Web界面进行实时监控。',
  raw: 'locustio/locust Locust是一个开源的性能/负载测试工具，支持使用Python编写可扩展的测试脚本，适用于HTTP等协议，并提供命令行和Web界面进行实时监控。',
  type: 'github_repo'
};

// [104] github/spec-kit
var gh104 = {
  index: 104,
  repo: 'github/spec-kit',
  desc: 'Spec Kit是一个工具包，支持规范驱动开发，使组织能够专注于产品场景，而不是书写通用代码，从而加快高质量软件的构建。',
  raw: 'github/spec-kit Spec Kit是一个工具包，支持规范驱动开发，使组织能够专注于产品场景，而不是书写通用代码，从而加快高质量软件的构建。',
  type: 'github_repo'
};

// [105] Byaidu/PDFMathTranslate
var gh105 = {
  index: 105,
  repo: 'Byaidu/PDFMathTranslate',
  desc: 'PDFMathTranslate 是一个基于 AI 的 PDF 文档双语翻译工具，能够完整保留排版，支持多种翻译服务。',
  raw: 'Byaidu/PDFMathTranslate PDFMathTranslate 是一个基于 AI 的 PDF 文档双语翻译工具，能够完整保留排版，支持多种翻译服务。',
  type: 'github_repo'
};

// [106] littlecodersh/ItChat
var gh106 = {
  index: 106,
  repo: 'littlecodersh/ItChat',
  desc: 'ItChat是一个方便的微信个人号接口，用户可以用Python轻松创建微信机器人，处理信息交互，提升社交效率。',
  raw: 'littlecodersh/ItChat ItChat是一个方便的微信个人号接口，用户可以用Python轻松创建微信机器人，处理信息交互，提升社交效率。',
  type: 'github_repo'
};

// [107] deepinsight/insightface
var gh107 = {
  index: 107,
  repo: 'deepinsight/insightface',
  desc: 'InsightFace是一个先进的2D和3D人脸分析项目，支持人脸识别和交换等功能，适用于非商业研究。旨在提供高效的面部处理解决方案。',
  raw: 'deepinsight/insightface InsightFace是一个先进的2D和3D人脸分析项目，支持人脸识别和交换等功能，适用于非商业研究。旨在提供高效的面部处理解决方案。',
  type: 'github_repo'
};

// [108] KurtBestor/Hitomi-Downloader
var gh108 = {
  index: 108,
  repo: 'KurtBestor/Hitomi-Downloader',
  desc: 'Hitomi-Downloader是一个桌面工具，允许用户从多个网站下载图片、视频、音乐和文本，具有简单清晰的用户界面和加速下载功能。',
  raw: 'KurtBestor/Hitomi-Downloader Hitomi-Downloader是一个桌面工具，允许用户从多个网站下载图片、视频、音乐和文本，具有简单清晰的用户界面和加速下载功能。',
  type: 'github_repo'
};

// [109] Vision-CAIR/MiniGPT-4
var gh109 = {
  index: 109,
  repo: 'Vision-CAIR/MiniGPT-4',
  desc: 'MiniGPT-4是一个开源项目，集成大型语言模型用于视听语言多任务学习，旨在增强视觉和语言理解能力。',
  raw: 'Vision-CAIR/MiniGPT-4 MiniGPT-4是一个开源项目，集成大型语言模型用于视听语言多任务学习，旨在增强视觉和语言理解能力。',
  type: 'github_repo'
};

// [110] reflex-dev/reflex
var gh110 = {
  index: 110,
  repo: 'reflex-dev/reflex',
  desc: 'Reflex是一个高性能、可定制的Web应用框架，支持用纯Python快速构建和部署Web应用。',
  raw: 'reflex-dev/reflex Reflex是一个高性能、可定制的Web应用框架，支持用纯Python快速构建和部署Web应用。',
  type: 'github_repo'
};

// [111] facefusion/facefusion
var gh111 = {
  index: 111,
  repo: 'facefusion/facefusion',
  desc: 'FaceFusion是一个行业领先的人脸处理平台，支持多种人脸操作和批处理功能，适合技术用户使用。',
  raw: 'facefusion/facefusion FaceFusion是一个行业领先的人脸处理平台，支持多种人脸操作和批处理功能，适合技术用户使用。',
  type: 'github_repo'
};

// [112] squidfunk/mkdocs-material
var gh112 = {
  index: 112,
  repo: 'squidfunk/mkdocs-material',
  desc: 'mkdocs-material是一个强大的文档框架，基于MkDocs，让用户快速编写Markdown文档并创建专业的静态网站，支持多语言和设备。',
  raw: 'squidfunk/mkdocs-material mkdocs-material是一个强大的文档框架，基于MkDocs，让用户快速编写Markdown文档并创建专业的静态网站，支持多语言和设备。',
  type: 'github_repo'
};

// [113] junyanz/pytorch-CycleGAN-and-pix2pix
var gh113 = {
  index: 113,
  repo: 'junyanz/pytorch-CycleGAN-and-pix2pix',
  desc: '这是一个基于PyTorch的图像到图像转换实现，提供了CycleGAN和pix2pix模型，支持无配对和有配对的训练，适合各种风格转换任务。',
  raw: 'junyanz/pytorch-CycleGAN-and-pix2pix 这是一个基于PyTorch的图像到图像转换实现，提供了CycleGAN和pix2pix模型，支持无配对和有配对的训练，适合各种风格转换任务。',
  type: 'github_repo'
};

// [114] black-forest-labs/flux
var gh114 = {
  index: 114,
  repo: 'black-forest-labs/flux',
  desc: 'FLUX是一个开源模型推理库，支持图像生成和编辑，提供简单的本地安装和TensorRT支持。',
  raw: 'black-forest-labs/flux FLUX是一个开源模型推理库，支持图像生成和编辑，提供简单的本地安装和TensorRT支持。',
  type: 'github_repo'
};

// [115] assafelovic/gpt-researcher
var gh115 = {
  index: 115,
  repo: 'assafelovic/gpt-researcher',
  desc: 'GPT Researcher是一个基于大型语言模型的自动化研究工具，能够在本地和网络上进行深入研究，并生成包含引用的详细报告。',
  raw: 'assafelovic/gpt-researcher GPT Researcher是一个基于大型语言模型的自动化研究工具，能够在本地和网络上进行深入研究，并生成包含引用的详细报告。',
  type: 'github_repo'
};

// [116] wangzheng0822/algo
var gh116 = {
  index: 116,
  repo: 'wangzheng0822/algo',
  desc: '该仓库提供了50个常用数据结构和算法的Python代码实现，是学习和掌握算法与数据结构的重要资源。',
  raw: 'wangzheng0822/algo 该仓库提供了50个常用数据结构和算法的Python代码实现，是学习和掌握算法与数据结构的重要资源。',
  type: 'github_repo'
};

// [117] Cinnamon/kotaemon
var gh117 = {
  index: 117,
  repo: 'Cinnamon/kotaemon',
  desc: 'kotaemon是一个开源的RAG工具，旨在与文档进行对话，适合终端用户和开发者使用。',
  raw: 'Cinnamon/kotaemon kotaemon是一个开源的RAG工具，旨在与文档进行对话，适合终端用户和开发者使用。',
  type: 'github_repo'
};

// [118] srbhr/Resume-Matcher
var gh118 = {
  index: 118,
  repo: 'srbhr/Resume-Matcher',
  desc: 'Resume Matcher 是一个AI驱动的简历优化工具，帮助用户根据职位描述调整简历，提供关键词建议和格式优化，提升被招聘系统筛选的几率。',
  raw: 'srbhr/Resume-Matcher Resume Matcher 是一个AI驱动的简历优化工具，帮助用户根据职位描述调整简历，提供关键词建议和格式优化，提升被招聘系统筛选的几率。',
  type: 'github_repo'
};

// [119] fishaudio/fish-speech
var gh119 = {
  index: 119,
  repo: 'fishaudio/fish-speech',
  desc: 'Fish Speech是一个开源的多语言文本转语音（TTS）工具，支持语音克隆，提供最新的技术水平，方便开发者集成和使用。',
  raw: 'fishaudio/fish-speech Fish Speech是一个开源的多语言文本转语音（TTS）工具，支持语音克隆，提供最新的技术水平，方便开发者集成和使用。',
  type: 'github_repo'
};

// [120] jhao104/proxy_pool
var gh120 = {
  index: 120,
  repo: 'jhao104/proxy_pool',
  desc: 'ProxyPool是一个Python项目，用于创建爬虫代理IP池，定期采集和验证免费代理，并提供API和CLI接口。',
  raw: 'jhao104/proxy_pool ProxyPool是一个Python项目，用于创建爬虫代理IP池，定期采集和验证免费代理，并提供API和CLI接口。',
  type: 'github_repo'
};

// [121] Delgan/loguru
var gh121 = {
  index: 121,
  repo: 'Delgan/loguru',
  desc: 'Loguru是一个简单易用的Python日志库，旨在简化日志记录过程，帮助开发者轻松调试应用程序。',
  raw: 'Delgan/loguru Loguru是一个简单易用的Python日志库，旨在简化日志记录过程，帮助开发者轻松调试应用程序。',
  type: 'github_repo'
};

// [122] kovidgoyal/calibre
var gh122 = {
  index: 122,
  repo: 'kovidgoyal/calibre',
  desc: 'calibre是一个电子书管理工具，支持查看、转换、编辑和管理各种电子书格式，并能与电子书阅读器设备通信。',
  raw: 'kovidgoyal/calibre calibre是一个电子书管理工具，支持查看、转换、编辑和管理各种电子书格式，并能与电子书阅读器设备通信。',
  type: 'github_repo'
};

// [123] tornadoweb/tornado
var gh123 = {
  index: 123,
  repo: 'tornadoweb/tornado',
  desc: 'Tornado是一个Python web框架和异步网络库，适合处理大量连接，主要用于长轮询和WebSockets等应用。',
  raw: 'tornadoweb/tornado Tornado是一个Python web框架和异步网络库，适合处理大量连接，主要用于长轮询和WebSockets等应用。',
  type: 'github_repo'
};

// [124] saleor/saleor
var gh124 = {
  index: 124,
  repo: 'saleor/saleor',
  desc: 'Saleor是一个高性能、可组合的无头电商API，支持GraphQL，通过API提供可扩展的电商解决方案。',
  raw: 'saleor/saleor Saleor是一个高性能、可组合的无头电商API，支持GraphQL，通过API提供可扩展的电商解决方案。',
  type: 'github_repo'
};

// [125] Sanster/IOPaint
var gh125 = {
  index: 125,
  repo: 'Sanster/IOPaint',
  desc: 'IOPaint是一个免费的开源图像修复和填充工具，利用SOTA人工智能模型，可以去除不需要的物体、缺陷和人物，支持图像擦除和替换。',
  raw: 'Sanster/IOPaint IOPaint是一个免费的开源图像修复和填充工具，利用SOTA人工智能模型，可以去除不需要的物体、缺陷和人物，支持图像擦除和替换。',
  type: 'github_repo'
};

// [126] mlflow/mlflow
var gh126 = {
  index: 126,
  repo: 'mlflow/mlflow',
  desc: 'MLflow是一个开源平台，旨在帮助开发者自信地构建AI和LLM应用及模型，支持实验跟踪、可观察性及评估，集成于一个平台中。',
  raw: 'mlflow/mlflow MLflow是一个开源平台，旨在帮助开发者自信地构建AI和LLM应用及模型，支持实验跟踪、可观察性及评估，集成于一个平台中。',
  type: 'github_repo'
};

// [127] jina-ai/serve
var gh127 = {
  index: 127,
  repo: 'jina-ai/serve',
  desc: 'Jina-Serve是一个框架，用于构建和部署多模态AI服务，支持gRPC、HTTP和WebSockets通信，方便从本地开发到生产环境的扩展。',
  raw: 'jina-ai/serve Jina-Serve是一个框架，用于构建和部署多模态AI服务，支持gRPC、HTTP和WebSockets通信，方便从本地开发到生产环境的扩展。',
  type: 'github_repo'
};

// [128] microsoft/unilm
var gh128 = {
  index: 128,
  repo: 'microsoft/unilm',
  desc: 'unilm是一个用于大规模自监督预训练的框架，支持语言、任务和模态的多样性，旨在提升基础模型的性能与泛化能力。',
  raw: 'microsoft/unilm unilm是一个用于大规模自监督预训练的框架，支持语言、任务和模态的多样性，旨在提升基础模型的性能与泛化能力。',
  type: 'github_repo'
};

// [129] Anjok07/ultimatevocalremovergui
var gh129 = {
  index: 129,
  repo: 'Anjok07/ultimatevocalremovergui',
  desc: 'Ultimate Vocal Remover GUI是一个基于深度神经网络的语音去除应用，允许用户从音频文件中分离人声。',
  raw: 'Anjok07/ultimatevocalremovergui Ultimate Vocal Remover GUI是一个基于深度神经网络的语音去除应用，允许用户从音频文件中分离人声。',
  type: 'github_repo'
};

// [130] chriskiehl/Gooey
var gh130 = {
  index: 130,
  repo: 'chriskiehl/Gooey',
  desc: 'Gooey是一个Python库，只需一行代码即可将几乎任何命令行程序转换为完整的GUI应用，方便用户使用和配置。',
  raw: 'chriskiehl/Gooey Gooey是一个Python库，只需一行代码即可将几乎任何命令行程序转换为完整的GUI应用，方便用户使用和配置。',
  type: 'github_repo'
};

// [131] ScrapeGraphAI/Scrapegraph-ai
var gh131 = {
  index: 131,
  repo: 'ScrapeGraphAI/Scrapegraph-ai',
  desc: 'Scrapegraph-ai是基于AI的Python网络爬虫，旨在提供快速、简便的方法进行大规模数据抓取，只需五行代码。',
  raw: 'ScrapeGraphAI/Scrapegraph-ai Scrapegraph-ai是基于AI的Python网络爬虫，旨在提供快速、简便的方法进行大规模数据抓取，只需五行代码。',
  type: 'github_repo'
};

// [132] openai/swarm
var gh132 = {
  index: 132,
  repo: 'openai/swarm',
  desc: 'Swarm是一个教育框架，旨在探索轻量级多智能体协调，帮助用户快速构建高效、可测试的智能体系统。',
  raw: 'openai/swarm Swarm是一个教育框架，旨在探索轻量级多智能体协调，帮助用户快速构建高效、可测试的智能体系统。',
  type: 'github_repo'
};

// [133] serengil/deepface
var gh133 = {
  index: 133,
  repo: 'serengil/deepface',
  desc: 'deepface是一个轻量级的面部识别和面部属性分析库，支持年龄、性别、情绪和种族分析，旨在简化Python中的人脸处理任务。',
  raw: 'serengil/deepface deepface是一个轻量级的面部识别和面部属性分析库，支持年龄、性别、情绪和种族分析，旨在简化Python中的人脸处理任务。',
  type: 'github_repo'
};

// [134] danielgatis/rembg
var gh134 = {
  index: 134,
  repo: 'danielgatis/rembg',
  desc: 'Rembg是一个用于移除图片背景的工具，帮助用户快速处理图像，适用于各种应用场景。',
  raw: 'danielgatis/rembg Rembg是一个用于移除图片背景的工具，帮助用户快速处理图像，适用于各种应用场景。',
  type: 'github_repo'
};

// [135] PrefectHQ/prefect
var gh135 = {
  index: 135,
  repo: 'PrefectHQ/prefect',
  desc: 'Prefect是一个Python工作流编排框架，旨在构建可靠的数据管道，帮助用户高效管理数据处理任务。',
  raw: 'PrefectHQ/prefect Prefect是一个Python工作流编排框架，旨在构建可靠的数据管道，帮助用户高效管理数据处理任务。',
  type: 'github_repo'
};

// [136] vanna-ai/vanna
var gh136 = {
  index: 136,
  repo: 'vanna-ai/vanna',
  desc: 'Vanna是一个开源Python框架，通过检索增强生成（RAG）技术，实现与SQL数据库的交互和自动SQL查询生成，简化数据库操作。',
  raw: 'vanna-ai/vanna Vanna是一个开源Python框架，通过检索增强生成（RAG）技术，实现与SQL数据库的交互和自动SQL查询生成，简化数据库操作。',
  type: 'github_repo'
};

// [137] HKUDS/LightRAG
var gh137 = {
  index: 137,
  repo: 'HKUDS/LightRAG',
  desc: 'LightRAG是一个简单快速的检索增强生成模型，旨在提升自然语言处理任务的效率与效果。',
  raw: 'HKUDS/LightRAG LightRAG是一个简单快速的检索增强生成模型，旨在提升自然语言处理任务的效率与效果。',
  type: 'github_repo'
};

// [138] airbytehq/airbyte
var gh138 = {
  index: 138,
  repo: 'airbytehq/airbyte',
  desc: 'Airbyte是一个领先的开源数据集成平台，支持从API、数据库和文件到数据仓库和数据湖的ETL/ELT数据管道。',
  raw: 'airbytehq/airbyte Airbyte是一个领先的开源数据集成平台，支持从API、数据库和文件到数据仓库和数据湖的ETL/ELT数据管道。',
  type: 'github_repo'
};

// [139] Jack-Cherish/python-spider
var gh139 = {
  index: 139,
  repo: 'Jack-Cherish/python-spider',
  desc: 'python-spider是一个基于Python3的网络爬虫实战项目，主要用于从淘宝、京东等平台下载小说、音乐、电影等内容，适合学习和研究目的。',
  raw: 'Jack-Cherish/python-spider python-spider是一个基于Python3的网络爬虫实战项目，主要用于从淘宝、京东等平台下载小说、音乐、电影等内容，适合学习和研究目的。',
  type: 'github_repo'
};

// [140] subframe7536/maple-font
var gh140 = {
  index: 140,
  repo: 'subframe7536/maple-font',
  desc: 'Maple Mono是一款开源的等宽字体，具有圆角设计、连字功能和支持Nerd-Font图标，适合IDE和终端使用，提供细粒度的自定义选项。',
  raw: 'subframe7536/maple-font Maple Mono是一款开源的等宽字体，具有圆角设计、连字功能和支持Nerd-Font图标，适合IDE和终端使用，提供细粒度的自定义选项。',
  type: 'github_repo'
};

// [141] Zeyi-Lin/HivisionIDPhotos
var gh141 = {
  index: 141,
  repo: 'Zeyi-Lin/HivisionIDPhotos',
  desc: 'HivisionIDPhotos是一个轻量级、高效的AI证件照制作工具，支持多种排版和美颜选项，旨在简化证件照的创建和分享。',
  raw: 'Zeyi-Lin/HivisionIDPhotos HivisionIDPhotos是一个轻量级、高效的AI证件照制作工具，支持多种排版和美颜选项，旨在简化证件照的创建和分享。',
  type: 'github_repo'
};

// [142] kaixindelele/ChatPaper
var gh142 = {
  index: 142,
  repo: 'kaixindelele/ChatPaper',
  desc: 'ChatPaper利用ChatGPT加速科研，提供论文总结、翻译、润色、审稿及回复功能，是学术研究的高效助手。',
  raw: 'kaixindelele/ChatPaper ChatPaper利用ChatGPT加速科研，提供论文总结、翻译、润色、审稿及回复功能，是学术研究的高效助手。',
  type: 'github_repo'
};

// [143] w-okada/voice-changer
var gh143 = {
  index: 143,
  repo: 'w-okada/voice-changer',
  desc: 'Voice Changer是一个实时语音变换软件，利用AI技术支持多平台音频转换，适合需要实时声音处理的用户。',
  raw: 'w-okada/voice-changer Voice Changer是一个实时语音变换软件，利用AI技术支持多平台音频转换，适合需要实时声音处理的用户。',
  type: 'github_repo'
};

// [144] iperov/DeepFaceLab
var gh144 = {
  index: 144,
  repo: 'iperov/DeepFaceLab',
  desc: 'DeepFaceLab 是创建深度伪造技术的领先软件，广泛应用于视频制作和特效编辑。',
  raw: 'iperov/DeepFaceLab DeepFaceLab 是创建深度伪造技术的领先软件，广泛应用于视频制作和特效编辑。',
  type: 'github_repo'
};

// [145] jantic/DeOldify
var gh145 = {
  index: 145,
  repo: 'jantic/DeOldify',
  desc: 'DeOldify是一个基于深度学习的项目，用于给老旧图片和视频上色与修复，支持多种平台使用。',
  raw: 'jantic/DeOldify DeOldify是一个基于深度学习的项目，用于给老旧图片和视频上色与修复，支持多种平台使用。',
  type: 'github_repo'
};

// [146] datalab-to/surya
var gh146 = {
  index: 146,
  repo: 'datalab-to/surya',
  desc: 'Surya是一个文档OCR工具包，支持90多种语言的文字识别、布局分析、阅读顺序检测和表格识别。',
  raw: 'datalab-to/surya Surya是一个文档OCR工具包，支持90多种语言的文字识别、布局分析、阅读顺序检测和表格识别。',
  type: 'github_repo'
};

// [147] modelcontextprotocol/python-sdk
var gh147 = {
  index: 147,
  repo: 'modelcontextprotocol/python-sdk',
  desc: '这是Model Context Protocol的官方Python SDK，方便开发者构建MCP服务器和客户端，支持多种功能和工具。',
  raw: 'modelcontextprotocol/python-sdk 这是Model Context Protocol的官方Python SDK，方便开发者构建MCP服务器和客户端，支持多种功能和工具。',
  type: 'github_repo'
};

// [148] nari-labs/dia
var gh148 = {
  index: 148,
  repo: 'nari-labs/dia',
  desc: 'Dia是一个生成超逼真对话的文本转语音模型，可以根据音频调节情感和语调，支持非语言交流。',
  raw: 'nari-labs/dia Dia是一个生成超逼真对话的文本转语音模型，可以根据音频调节情感和语调，支持非语言交流。',
  type: 'github_repo'
};

// [149] letta-ai/letta
var gh149 = {
  index: 149,
  repo: 'letta-ai/letta',
  desc: 'Letta是一个开源框架，用于构建具有高级推理能力和长期记忆功能的状态代理，适用于多种模型场景。',
  raw: 'letta-ai/letta Letta是一个开源框架，用于构建具有高级推理能力和长期记忆功能的状态代理，适用于多种模型场景。',
  type: 'github_repo'
};

// [150] camel-ai/owl
var gh150 = {
  index: 150,
  repo: 'camel-ai/owl',
  desc: 'OWL是一个优化的多智能体学习平台，旨在实现复杂任务的自动化，帮助用户构建和管理定制的AI工作队伍。',
  raw: 'camel-ai/owl OWL是一个优化的多智能体学习平台，旨在实现复杂任务的自动化，帮助用户构建和管理定制的AI工作队伍。',
  type: 'github_repo'
};

// [151] 1Panel-dev/MaxKB
var gh151 = {
  index: 151,
  repo: '1Panel-dev/MaxKB',
  desc: 'MaxKB是一个开源平台，旨在构建企业级智能体，集成了检索增强生成(RAG)管道，支持智能客服、知识库等场景。',
  raw: '1Panel-dev/MaxKB MaxKB是一个开源平台，旨在构建企业级智能体，集成了检索增强生成(RAG)管道，支持智能客服、知识库等场景。',
  type: 'github_repo'
};

// [152] Mikubill/sd-webui-controlnet
var gh152 = {
  index: 152,
  repo: 'Mikubill/sd-webui-controlnet',
  desc: '这是一个用于Stable Diffusion WebUI的ControlNet扩展，支持动态图像生成，并简化了控制模型的集成过程。',
  raw: 'Mikubill/sd-webui-controlnet 这是一个用于Stable Diffusion WebUI的ControlNet扩展，支持动态图像生成，并简化了控制模型的集成过程。',
  type: 'github_repo'
};

// [153] SYSTRAN/faster-whisper
var gh153 = {
  index: 153,
  repo: 'SYSTRAN/faster-whisper',
  desc: 'faster-whisper 是一个基于 CTranslate2 的 OpenAI Whisper 模型重实现，提供更快的转录速度和更低的内存消耗，适合需要高效音频转写的应用。',
  raw: 'SYSTRAN/faster-whisper faster-whisper 是一个基于 CTranslate2 的 OpenAI Whisper 模型重实现，提供更快的转录速度和更低的内存消耗，适合需要高效音频转写的应用。',
  type: 'github_repo'
};

// [154] langchain-ai/langgraph
var gh154 = {
  index: 154,
  repo: 'langchain-ai/langgraph',
  desc: 'LangGraph是一个低级别的编排框架，用于构建、管理和部署长期运行的状态代理，适用于各种信息处理任务。',
  raw: 'langchain-ai/langgraph LangGraph是一个低级别的编排框架，用于构建、管理和部署长期运行的状态代理，适用于各种信息处理任务。',
  type: 'github_repo'
};

// [155] m-bain/whisperX
var gh155 = {
  index: 155,
  repo: 'm-bain/whisperX',
  desc: 'WhisperX 是一个自动语音识别工具，支持单词级时间戳和说话人分离，提供快速高效的转录服务。',
  raw: 'm-bain/whisperX WhisperX 是一个自动语音识别工具，支持单词级时间戳和说话人分离，提供快速高效的转录服务。',
  type: 'github_repo'
};

// [156] getzep/graphiti
var gh156 = {
  index: 156,
  repo: 'getzep/graphiti',
  desc: 'Graphiti是一个框架，用于构建和查询时间感知的知识图谱，特别为在动态环境中运行的AI代理量身定制。',
  raw: 'getzep/graphiti Graphiti是一个框架，用于构建和查询时间感知的知识图谱，特别为在动态环境中运行的AI代理量身定制。',
  type: 'github_repo'
};

// [157] SWE-agent/SWE-agent
var gh157 = {
  index: 157,
  repo: 'SWE-agent/SWE-agent',
  desc: 'SWE-agent是一个利用语言模型自动修复GitHub问题的工具，适用于网络安全和编程挑战，旨在简化开发者工作流程。',
  raw: 'SWE-agent/SWE-agent SWE-agent是一个利用语言模型自动修复GitHub问题的工具，适用于网络安全和编程挑战，旨在简化开发者工作流程。',
  type: 'github_repo'
};

// [158] bytedance/deer-flow
var gh158 = {
  index: 158,
  repo: 'bytedance/deer-flow',
  desc: 'DeerFlow是一个社区驱动的深度研究框架，结合语言模型与网页搜索、爬虫和Python执行等工具，旨在为开源社区贡献力量。',
  raw: 'bytedance/deer-flow DeerFlow是一个社区驱动的深度研究框架，结合语言模型与网页搜索、爬虫和Python执行等工具，旨在为开源社区贡献力量。',
  type: 'github_repo'
};

// [159] pallets/click
var gh159 = {
  index: 159,
  repo: 'pallets/click',
  desc: 'Click是一个Python工具包，用于快速创建美观的命令行接口，支持命令嵌套、自动生成帮助文档，减少编码复杂度。',
  raw: 'pallets/click Click是一个Python工具包，用于快速创建美观的命令行接口，支持命令嵌套、自动生成帮助文档，减少编码复杂度。',
  type: 'github_repo'
};

// [160] jlowin/fastmcp
var gh160 = {
  index: 160,
  repo: 'jlowin/fastmcp',
  desc: 'FastMCP是一个快速构建MCP服务器和客户端的Python框架，提供全面的工具集，简化部署、身份验证和API集成等流程。',
  raw: 'jlowin/fastmcp FastMCP是一个快速构建MCP服务器和客户端的Python框架，提供全面的工具集，简化部署、身份验证和API集成等流程。',
  type: 'github_repo'
};

// [161] cool-RR/PySnooper
var gh161 = {
  index: 161,
  repo: 'cool-RR/PySnooper',
  desc: 'PySnooper 是一个简单易用的 Python 调试工具，通过装饰器轻松跟踪函数执行过程和变量变化，帮助开发者快速定位问题。',
  raw: 'cool-RR/PySnooper PySnooper 是一个简单易用的 Python 调试工具，通过装饰器轻松跟踪函数执行过程和变量变化，帮助开发者快速定位问题。',
  type: 'github_repo'
};

// [162] piskvorky/gensim
var gh162 = {
  index: 162,
  repo: 'piskvorky/gensim',
  desc: 'Gensim是一个用于主题建模、文档索引和相似性检索的Python库，专为自然语言处理和信息检索领域设计，能够处理超出内存大小的大型语料库。',
  raw: 'piskvorky/gensim Gensim是一个用于主题建模、文档索引和相似性检索的Python库，专为自然语言处理和信息检索领域设计，能够处理超出内存大小的大型语料库。',
  type: 'github_repo'
};

// [163] exaloop/codon
var gh163 = {
  index: 163,
  repo: 'exaloop/codon',
  desc: 'Codon是一个高性能的Python编译器，支持原生机器代码编译，提供NumPy支持，极大提升执行速度，是Python的静态编译版本。',
  raw: 'exaloop/codon Codon是一个高性能的Python编译器，支持原生机器代码编译，提供NumPy支持，极大提升执行速度，是Python的静态编译版本。',
  type: 'github_repo'
};

// [164] FunAudioLLM/CosyVoice
var gh164 = {
  index: 164,
  repo: 'FunAudioLLM/CosyVoice',
  desc: 'CosyVoice是一个多语言大规模语音生成模型，提供高质量的语音合成、训练和部署功能，支持多种语言和方言，具有低延迟和高准确性。',
  raw: 'FunAudioLLM/CosyVoice CosyVoice是一个多语言大规模语音生成模型，提供高质量的语音合成、训练和部署功能，支持多种语言和方言，具有低延迟和高准确性。',
  type: 'github_repo'
};

// [165] GaiZhenbiao/ChuanhuChatGPT
var gh165 = {
  index: 165,
  repo: 'GaiZhenbiao/ChuanhuChatGPT',
  desc: '川虎Chat为ChatGPT等多种语言模型提供友好的Web图形界面，支持文件问答、在线搜索和模型微调等功能。',
  raw: 'GaiZhenbiao/ChuanhuChatGPT 川虎Chat为ChatGPT等多种语言模型提供友好的Web图形界面，支持文件问答、在线搜索和模型微调等功能。',
  type: 'github_repo'
};

// [166] xming521/WeClone
var gh166 = {
  index: 166,
  repo: 'xming521/WeClone',
  desc: 'WeClone是一个一站式解决方案，通过聊天记录创建个性化数字分身，并优化大语言模型以展现独特风格。',
  raw: 'xming521/WeClone WeClone是一个一站式解决方案，通过聊天记录创建个性化数字分身，并优化大语言模型以展现独特风格。',
  type: 'github_repo'
};

// [167] fabric/fabric
var gh167 = {
  index: 167,
  repo: 'fabric/fabric',
  desc: 'Fabric是一个高层次的Python库，旨在通过SSH远程执行Shell命令，返回有用的Python对象，简化部署和命令执行。',
  raw: 'fabric/fabric Fabric是一个高层次的Python库，旨在通过SSH远程执行Shell命令，返回有用的Python对象，简化部署和命令执行。',
  type: 'github_repo'
};

// [168] lukas-blecher/LaTeX-OCR
var gh168 = {
  index: 168,
  repo: 'lukas-blecher/LaTeX-OCR',
  desc: 'LaTeX-OCR项目利用ViT模型将数学公式图像转换为LaTeX代码，旨在提高公式处理的效率和便捷性。',
  raw: 'lukas-blecher/LaTeX-OCR LaTeX-OCR项目利用ViT模型将数学公式图像转换为LaTeX代码，旨在提高公式处理的效率和便捷性。',
  type: 'github_repo'
};

// [169] chidiwilliams/buzz
var gh169 = {
  index: 169,
  repo: 'chidiwilliams/buzz',
  desc: 'Buzz是一款离线音频转录和翻译工具，基于OpenAI的Whisper，旨在提高个人计算机的音频处理效率。',
  raw: 'chidiwilliams/buzz Buzz是一款离线音频转录和翻译工具，基于OpenAI的Whisper，旨在提高个人计算机的音频处理效率。',
  type: 'github_repo'
};

// [170] mikf/gallery-dl
var gh170 = {
  index: 170,
  repo: 'mikf/gallery-dl',
  desc: 'gallery-dl是一个命令行程序，用于从多个图像托管网站下载图片画廊和集合，支持丰富的配置和文件命名选项。',
  raw: 'mikf/gallery-dl gallery-dl是一个命令行程序，用于从多个图像托管网站下载图片画廊和集合，支持丰富的配置和文件命名选项。',
  type: 'github_repo'
};

// [171] lra/mackup
var gh171 = {
  index: 171,
  repo: 'lra/mackup',
  desc: 'Mackup是一个工具，用于同步OS X和Linux上的应用程序设置，方便用户备份和恢复配置。支持Dropbox等存储方式。',
  raw: 'lra/mackup Mackup是一个工具，用于同步OS X和Linux上的应用程序设置，方便用户备份和恢复配置。支持Dropbox等存储方式。',
  type: 'github_repo'
};

// [172] anthropics/skills
var gh172 = {
  index: 172,
  repo: 'anthropics/skills',
  desc: 'Skills仓库包含动态加载的指令、脚本和资源，帮助Claude系统完成特定任务，实现文档创建、数据分析和个人任务自动化。',
  raw: 'anthropics/skills Skills仓库包含动态加载的指令、脚本和资源，帮助Claude系统完成特定任务，实现文档创建、数据分析和个人任务自动化。',
  type: 'github_repo'
};

// [173] kvcache-ai/ktransformers
var gh173 = {
  index: 173,
  repo: 'kvcache-ai/ktransformers',
  desc: 'KTransformers是一个灵活的Python框架，旨在通过先进的内核优化和并行策略提升Transformers体验，支持各类LLM推理优化。',
  raw: 'kvcache-ai/ktransformers KTransformers是一个灵活的Python框架，旨在通过先进的内核优化和并行策略提升Transformers体验，支持各类LLM推理优化。',
  type: 'github_repo'
};

// [174] mail-in-a-box/mailinabox
var gh174 = {
  index: 174,
  repo: 'mail-in-a-box/mailinabox',
  desc: 'Mail-in-a-Box 是一个简易的邮件服务器部署工具，帮助用户快速搭建和管理邮件服务，提升自主掌控邮件的能力。',
  raw: 'mail-in-a-box/mailinabox Mail-in-a-Box 是一个简易的邮件服务器部署工具，帮助用户快速搭建和管理邮件服务，提升自主掌控邮件的能力。',
  type: 'github_repo'
};

// [175] apprenticeharper/DeDRM_tools
var gh175 = {
  index: 175,
  repo: 'apprenticeharper/DeDRM_tools',
  desc: 'DeDRM_tools是一个用于移除电子书数字版权管理(DRM)的工具集合，支持多种格式的电子书解锁。',
  raw: 'apprenticeharper/DeDRM_tools DeDRM_tools是一个用于移除电子书数字版权管理(DRM)的工具集合，支持多种格式的电子书解锁。',
  type: 'github_repo'
};

// [176] saltstack/salt
var gh176 = {
  index: 176,
  repo: 'saltstack/salt',
  desc: 'Salt是一个基于Python的自动化工具，旨在高效管理和配置复杂的IT系统，支持基础设施的自动化操作。',
  raw: 'saltstack/salt Salt是一个基于Python的自动化工具，旨在高效管理和配置复杂的IT系统，支持基础设施的自动化操作。',
  type: 'github_repo'
};

// [177] Huanshere/VideoLingo
var gh177 = {
  index: 177,
  repo: 'Huanshere/VideoLingo',
  desc: 'VideoLingo是一个全能视频翻译、本地化和配音工具，旨在生成Netflix级别的字幕，支持一键自动化处理，打破语言障碍。',
  raw: 'Huanshere/VideoLingo VideoLingo是一个全能视频翻译、本地化和配音工具，旨在生成Netflix级别的字幕，支持一键自动化处理，打破语言障碍。',
  type: 'github_repo'
};

// [178] google/langextract
var gh178 = {
  index: 178,
  repo: 'google/langextract',
  desc: 'LangExtract是一个Python库，利用大型语言模型从非结构化文本中提取结构化信息，支持来源精确定位和互动可视化，适合处理临床笔记等文档。',
  raw: 'google/langextract LangExtract是一个Python库，利用大型语言模型从非结构化文本中提取结构化信息，支持来源精确定位和互动可视化，适合处理临床笔记等文档。',
  type: 'github_repo'
};

// [179] fauxpilot/fauxpilot
var gh179 = {
  index: 179,
  repo: 'fauxpilot/fauxpilot',
  desc: 'FauxPilot是一个开源项目，提供本地托管的GitHub Copilot替代方案，利用SalesForce CodeGen模型和NVIDIA Triton推理服务器实现代码自动补全功能。',
  raw: 'fauxpilot/fauxpilot FauxPilot是一个开源项目，提供本地托管的GitHub Copilot替代方案，利用SalesForce CodeGen模型和NVIDIA Triton推理服务器实现代码自动补全功能。',
  type: 'github_repo'
};

// [180] microsoft/pyright
var gh180 = {
  index: 180,
  repo: 'microsoft/pyright',
  desc: 'Pyright是一个功能全面的Python静态类型检查器，旨在高性能地处理大型Python代码库，支持命令行工具和VS Code扩展。',
  raw: 'microsoft/pyright Pyright是一个功能全面的Python静态类型检查器，旨在高性能地处理大型Python代码库，支持命令行工具和VS Code扩展。',
  type: 'github_repo'
};

// [181] facebookresearch/detr
var gh181 = {
  index: 181,
  repo: 'facebookresearch/detr',
  desc: 'DETR是基于Transformer的端到端目标检测工具，简化了目标检测流程，具备高效的推理能力，适合快速实验与实现。',
  raw: 'facebookresearch/detr DETR是基于Transformer的端到端目标检测工具，简化了目标检测流程，具备高效的推理能力，适合快速实验与实现。',
  type: 'github_repo'
};

// [182] laramies/theHarvester
var gh182 = {
  index: 182,
  repo: 'laramies/theHarvester',
  desc: 'theHarvester是一款用于进行开放源信息收集的工具，旨在评估域名的外部威胁环境，能够获取电子邮件、子域名、IP和URLs等信息。',
  raw: 'laramies/theHarvester theHarvester是一款用于进行开放源信息收集的工具，旨在评估域名的外部威胁环境，能够获取电子邮件、子域名、IP和URLs等信息。',
  type: 'github_repo'
};

// [183] NVlabs/stylegan
var gh183 = {
  index: 183,
  repo: 'NVlabs/stylegan',
  desc: 'StyleGAN是一个基于TensorFlow的官方实现，专注于生成对抗网络，能够自动分离高层次特征并控制图像合成，主要用于生成高质量人脸图像。',
  raw: 'NVlabs/stylegan StyleGAN是一个基于TensorFlow的官方实现，专注于生成对抗网络，能够自动分离高层次特征并控制图像合成，主要用于生成高质量人脸图像。',
  type: 'github_repo'
};

// [184] caronc/apprise
var gh184 = {
  index: 184,
  repo: 'caronc/apprise',
  desc: 'Apprise 是一个轻量级的通知库，支持几乎所有流行的通知服务，简化开发者和运维人员的通知发送工作。',
  raw: 'caronc/apprise Apprise 是一个轻量级的通知库，支持几乎所有流行的通知服务，简化开发者和运维人员的通知发送工作。',
  type: 'github_repo'
};

// [185] cvat-ai/cvat
var gh185 = {
  index: 185,
  repo: 'cvat-ai/cvat',
  desc: 'CVAT是一个用于计算机视觉的视频和图像标注工具，适用于各类规模的数据和团队，支持开发者和组织解决实际问题。',
  raw: 'cvat-ai/cvat CVAT是一个用于计算机视觉的视频和图像标注工具，适用于各类规模的数据和团队，支持开发者和组织解决实际问题。',
  type: 'github_repo'
};

// [186] s0md3v/XSStrike
var gh186 = {
  index: 186,
  repo: 's0md3v/XSStrike',
  desc: 'XSStrike是一个高级的XSS检测工具，结合了智能负载生成器和强大的模糊测试引擎，能够高效识别跨站脚本漏洞。',
  raw: 's0md3v/XSStrike XSStrike是一个高级的XSS检测工具，结合了智能负载生成器和强大的模糊测试引擎，能够高效识别跨站脚本漏洞。',
  type: 'github_repo'
};

// [187] dagster-io/dagster
var gh187 = {
  index: 187,
  repo: 'dagster-io/dagster',
  desc: 'Dagster是一个云原生的数据管道编排平台，支持数据资产的开发、生产和监控，提供集成的血统追踪和可观察性。',
  raw: 'dagster-io/dagster Dagster是一个云原生的数据管道编排平台，支持数据资产的开发、生产和监控，提供集成的血统追踪和可观察性。',
  type: 'github_repo'
};

// [188] mindverse/Second-Me
var gh188 = {
  index: 188,
  repo: 'mindverse/Second-Me',
  desc: 'Second-Me是一个开源原型，允许用户构建自己的AI自我，强调个体性和数据控制，同时在全球网络中扩展智能。',
  raw: 'mindverse/Second-Me Second-Me是一个开源原型，允许用户构建自己的AI自我，强调个体性和数据控制，同时在全球网络中扩展智能。',
  type: 'github_repo'
};

// [189] google/yapf
var gh189 = {
  index: 189,
  repo: 'google/yapf',
  desc: 'YAPF是一个Python代码格式化工具，旨在自动调整代码格式以符合设定的风格规范，简化代码维护工作。',
  raw: 'google/yapf YAPF是一个Python代码格式化工具，旨在自动调整代码格式以符合设定的风格规范，简化代码维护工作。',
  type: 'github_repo'
};

// [190] jianchang512/pyvideotrans
var gh190 = {
  index: 190,
  repo: 'jianchang512/pyvideotrans',
  desc: 'pyvideotrans是一个视频翻译和配音工具，支持语音识别、文字翻译和字幕生成，能将视频从一种语言翻译为另一种。还提供多种音频处理功能。',
  raw: 'jianchang512/pyvideotrans pyvideotrans是一个视频翻译和配音工具，支持语音识别、文字翻译和字幕生成，能将视频从一种语言翻译为另一种。还提供多种音频处理功能。',
  type: 'github_repo'
};

// [191] allenai/olmocr
var gh191 = {
  index: 191,
  repo: 'allenai/olmocr',
  desc: 'olmocr是一个工具包，用于将PDF和其他基于图像的文档格式转换为干净、可读的纯文本格式，支持复杂排版与数学公式。',
  raw: 'allenai/olmocr olmocr是一个工具包，用于将PDF和其他基于图像的文档格式转换为干净、可读的纯文本格式，支持复杂排版与数学公式。',
  type: 'github_repo'
};

// [192] psf/requests-html
var gh192 = {
  index: 192,
  repo: 'psf/requests-html',
  desc: 'requests-html 是一个用于简化 HTML 解析的 Python 库，支持 JavaScript、CSS 和 XPath 选择器，方便进行网页抓取。',
  raw: 'psf/requests-html requests-html 是一个用于简化 HTML 解析的 Python 库，支持 JavaScript、CSS 和 XPath 选择器，方便进行网页抓取。',
  type: 'github_repo'
};

// [193] Zulko/moviepy
var gh193 = {
  index: 193,
  repo: 'Zulko/moviepy',
  desc: 'MoviePy是一个用于视频编辑的Python库，支持剪切、合并、标题插入及视频处理等功能，适用于多种音视频格式。',
  raw: 'Zulko/moviepy MoviePy是一个用于视频编辑的Python库，支持剪切、合并、标题插入及视频处理等功能，适用于多种音视频格式。',
  type: 'github_repo'
};

// [194] Wan-Video/Wan2.1
var gh194 = {
  index: 194,
  repo: 'Wan-Video/Wan2.1',
  desc: 'Wan2.1是一个开放的先进视频生成模型套件，支持多种生成任务，如文本转视频、图像转视频等，性能优越且适用于消费级GPU。',
  raw: 'Wan-Video/Wan2.1 Wan2.1是一个开放的先进视频生成模型套件，支持多种生成任务，如文本转视频、图像转视频等，性能优越且适用于消费级GPU。',
  type: 'github_repo'
};

// [195] beetbox/beets
var gh195 = {
  index: 195,
  repo: 'beetbox/beets',
  desc: 'Beets 是一款音乐库管理工具，自动整理音乐收藏并改善元数据，可用于查找和处理音乐信息。',
  raw: 'beetbox/beets Beets 是一款音乐库管理工具，自动整理音乐收藏并改善元数据，可用于查找和处理音乐信息。',
  type: 'github_repo'
};

// [196] idank/explainshell
var gh196 = {
  index: 196,
  repo: 'idank/explainshell',
  desc: 'explainshell是一个能够解析命令行参数并与手册页帮助文本匹配的工具，提供网页界面以帮助用户理解命令用法。',
  raw: 'idank/explainshell explainshell是一个能够解析命令行参数并与手册页帮助文本匹配的工具，提供网页界面以帮助用户理解命令用法。',
  type: 'github_repo'
};

// [197] PaddlePaddle/PaddleDetection
var gh197 = {
  index: 197,
  repo: 'PaddlePaddle/PaddleDetection',
  desc: 'PaddleDetection是基于PaddlePaddle的目标检测开发工具包，支持目标检测、实例分割和多目标跟踪，旨在简化模型训练与部署流程。',
  raw: 'PaddlePaddle/PaddleDetection PaddleDetection是基于PaddlePaddle的目标检测开发工具包，支持目标检测、实例分割和多目标跟踪，旨在简化模型训练与部署流程。',
  type: 'github_repo'
};

// [198] comet-ml/opik
var gh198 = {
  index: 198,
  repo: 'comet-ml/opik',
  desc: 'Opik是一个开源的LLM评估平台，帮助用户构建、评估和优化LLM系统，提供全面的追踪、评估和仪表板功能。',
  raw: 'comet-ml/opik Opik是一个开源的LLM评估平台，帮助用户构建、评估和优化LLM系统，提供全面的追踪、评估和仪表板功能。',
  type: 'github_repo'
};

// [199] pyodide/pyodide
var gh199 = {
  index: 199,
  repo: 'pyodide/pyodide',
  desc: 'Pyodide是基于WebAssembly的Python发行版，可以在浏览器和Node.js中运行Python代码，支持安装和使用Python包。',
  raw: 'pyodide/pyodide Pyodide是基于WebAssembly的Python发行版，可以在浏览器和Node.js中运行Python代码，支持安装和使用Python包。',
  type: 'github_repo'
};

// [200] microsoft/playwright-python
var gh200 = {
  index: 200,
  repo: 'microsoft/playwright-python',
  desc: 'playwright-python 是一个用于自动化 Chromium、Firefox 和 WebKit 浏览器的 Python 库，提供统一的 API，支持高效的测试与自动化。',
  raw: 'microsoft/playwright-python playwright-python 是一个用于自动化 Chromium、Firefox 和 WebKit 浏览器的 Python 库，提供统一的 API，支持高效的测试与自动化。',
  type: 'github_repo'
};

// [201] netease-youdao/QAnything
var gh201 = {
  index: 201,
  repo: 'netease-youdao/QAnything',
  desc: 'QAnything是一个基于任何内容的问答系统，用户可以提出问题并获取相关答案，适用于多种需求。',
  raw: 'netease-youdao/QAnything QAnything是一个基于任何内容的问答系统，用户可以提出问题并获取相关答案，适用于多种需求。',
  type: 'github_repo'
};

// [202] onyx-dot-app/onyx
var gh202 = {
  index: 202,
  repo: 'onyx-dot-app/onyx',
  desc: 'Onyx是一个开源AI聊天平台，能够连接企业文档、应用和人员，支持团队知识搜索与定制AI代理，提升工作效率。',
  raw: 'onyx-dot-app/onyx Onyx是一个开源AI聊天平台，能够连接企业文档、应用和人员，支持团队知识搜索与定制AI代理，提升工作效率。',
  type: 'github_repo'
};

// [203] suitenumerique/docs
var gh203 = {
  index: 203,
  repo: 'suitenumerique/docs',
  desc: 'Docs是一个基于Django和React构建的协作笔记、维基和文档平台，旨在优化知识创建与分享，支持实时协作编辑。',
  raw: 'suitenumerique/docs Docs是一个基于Django和React构建的协作笔记、维基和文档平台，旨在优化知识创建与分享，支持实时协作编辑。',
  type: 'github_repo'
};

// [204] redis/redis-py
var gh204 = {
  index: 204,
  repo: 'redis/redis-py',
  desc: 'redis-py是Redis数据库的Python客户端，提供便捷的接口用于与Redis键值存储进行交互，适合开发者使用。',
  raw: 'redis/redis-py redis-py是Redis数据库的Python客户端，提供便捷的接口用于与Redis键值存储进行交互，适合开发者使用。',
  type: 'github_repo'
};

// [205] OpenTalker/SadTalker
var gh205 = {
  index: 205,
  repo: 'OpenTalker/SadTalker',
  desc: 'SadTalker 是一个用于生成基于音频驱动的单图像实时3D动画的工具，能够让静态人脸进行自然口语动画。',
  raw: 'OpenTalker/SadTalker SadTalker 是一个用于生成基于音频驱动的单图像实时3D动画的工具，能够让静态人脸进行自然口语动画。',
  type: 'github_repo'
};

// [206] python-pillow/Pillow
var gh206 = {
  index: 206,
  repo: 'python-pillow/Pillow',
  desc: 'Pillow是Python图像库PIL的友好分支，提供图像处理功能，包括打开、操作和保存多种格式的图像。适合开发者在Python项目中使用。',
  raw: 'python-pillow/Pillow Pillow是Python图像库PIL的友好分支，提供图像处理功能，包括打开、操作和保存多种格式的图像。适合开发者在Python项目中使用。',
  type: 'github_repo'
};

// [207] SWivid/F5-TTS
var gh207 = {
  index: 207,
  repo: 'SWivid/F5-TTS',
  desc: 'F5-TTS是一个利用扩散变换器技术生成流利且忠实语音的工具，适用于文本到语音的转化。',
  raw: 'SWivid/F5-TTS F5-TTS是一个利用扩散变换器技术生成流利且忠实语音的工具，适用于文本到语音的转化。',
  type: 'github_repo'
};

// [208] ahujasid/blender-mcp
var gh208 = {
  index: 208,
  repo: 'ahujasid/blender-mcp',
  desc: 'BlenderMCP是一个将Blender与Claude AI通过模型上下文协议连接的工具，使得用户能够直接在Blender中进行3D建模和场景创作，从而提高建模效率。',
  raw: 'ahujasid/blender-mcp BlenderMCP是一个将Blender与Claude AI通过模型上下文协议连接的工具，使得用户能够直接在Blender中进行3D建模和场景创作，从而提高建模效率。',
  type: 'github_repo'
};

// [209] plasma-umass/scalene
var gh209 = {
  index: 209,
  repo: 'plasma-umass/scalene',
  desc: 'Scalene是一个高性能、高精度的Python CPU、GPU和内存分析器，能够提供基于AI的优化建议，帮助开发者提升代码性能。',
  raw: 'plasma-umass/scalene Scalene是一个高性能、高精度的Python CPU、GPU和内存分析器，能够提供基于AI的优化建议，帮助开发者提升代码性能。',
  type: 'github_repo'
};

// [210] dottxt-ai/outlines
var gh210 = {
  index: 210,
  repo: 'dottxt-ai/outlines',
  desc: 'Outlines是一款用于结构化输出的高性能解决方案，旨在提升大语言模型（LLMs）的输出质量，广泛应用于客户支持、电商产品分类等领域。',
  raw: 'dottxt-ai/outlines Outlines是一款用于结构化输出的高性能解决方案，旨在提升大语言模型（LLMs）的输出质量，广泛应用于客户支持、电商产品分类等领域。',
  type: 'github_repo'
};

// [211] sml2h3/ddddocr
var gh211 = {
  index: 211,
  repo: 'sml2h3/ddddocr',
  desc: 'DdddOcr是一个开源的Python库，用于离线识别通用验证码，旨在提供简单易用的OCR解决方案，支持自定义模型和HTTP API服务。',
  raw: 'sml2h3/ddddocr DdddOcr是一个开源的Python库，用于离线识别通用验证码，旨在提供简单易用的OCR解决方案，支持自定义模型和HTTP API服务。',
  type: 'github_repo'
};

// [212] resemble-ai/chatterbox
var gh212 = {
  index: 212,
  repo: 'resemble-ai/chatterbox',
  desc: 'Chatterbox是一个开源的文本转语音(TTS)模型，支持情感增强控制，适用于视频、游戏和AI代理等多种场景。',
  raw: 'resemble-ai/chatterbox Chatterbox是一个开源的文本转语音(TTS)模型，支持情感增强控制，适用于视频、游戏和AI代理等多种场景。',
  type: 'github_repo'
};

// [213] LibreTranslate/LibreTranslate
var gh213 = {
  index: 213,
  repo: 'LibreTranslate/LibreTranslate',
  desc: 'LibreTranslate是一个免费的开源机器翻译API，支持自托管和离线使用，无需依赖商业翻译服务。',
  raw: 'LibreTranslate/LibreTranslate LibreTranslate是一个免费的开源机器翻译API，支持自托管和离线使用，无需依赖商业翻译服务。',
  type: 'github_repo'
};

// [214] trustedsec/social-engineer-toolkit
var gh214 = {
  index: 214,
  repo: 'trustedsec/social-engineer-toolkit',
  desc: 'Social-Engineer Toolkit是一个开源渗透测试框架，专注于社交工程攻击。',
  raw: 'trustedsec/social-engineer-toolkit Social-Engineer Toolkit是一个开源渗透测试框架，专注于社交工程攻击。',
  type: 'github_repo'
};

// [215] Rudrabha/Wav2Lip
var gh215 = {
  index: 215,
  repo: 'Rudrabha/Wav2Lip',
  desc: 'Wav2Lip是一个用于视频口型同步生成的工具，能够根据音频生成自然口型运动，适用于高质量的商业视频制作。',
  raw: 'Rudrabha/Wav2Lip Wav2Lip是一个用于视频口型同步生成的工具，能够根据音频生成自然口型运动，适用于高质量的商业视频制作。',
  type: 'github_repo'
};

// [216] google/adk-python
var gh216 = {
  index: 216,
  repo: 'google/adk-python',
  desc: 'adk-python是一个开源的Python工具包，用于灵活地构建、评估和部署复杂的AI代理，旨在简化代理开发流程。',
  raw: 'google/adk-python adk-python是一个开源的Python工具包，用于灵活地构建、评估和部署复杂的AI代理，旨在简化代理开发流程。',
  type: 'github_repo'
};

// [217] s0md3v/Photon
var gh217 = {
  index: 217,
  repo: 's0md3v/Photon',
  desc: 'Photon是一个快速的网络爬虫工具，专为OSINT（开放源情报）设计，可提取多种数据，如URL、电子邮件、文件等。',
  raw: 's0md3v/Photon Photon是一个快速的网络爬虫工具，专为OSINT（开放源情报）设计，可提取多种数据，如URL、电子邮件、文件等。',
  type: 'github_repo'
};

// [218] PaddlePaddle/PaddleSpeech
var gh218 = {
  index: 218,
  repo: 'PaddlePaddle/PaddleSpeech',
  desc: 'PaddleSpeech是一个易用的语音工具包，支持自监督学习模型、最先进的ASR、流式TTS、说话者验证、端到端语音翻译和关键词识别等功能，旨在帮助开发者快速构建语音应用。',
  raw: 'PaddlePaddle/PaddleSpeech PaddleSpeech是一个易用的语音工具包，支持自监督学习模型、最先进的ASR、流式TTS、说话者验证、端到端语音翻译和关键词识别等功能，旨在帮助开发者快速构建语音应用。',
  type: 'github_repo'
};

// [219] dbader/schedule
var gh219 = {
  index: 219,
  repo: 'dbader/schedule',
  desc: '这是一个用于Python的任务调度库，允许用户以简单友好的方式定期运行Python函数。',
  raw: 'dbader/schedule 这是一个用于Python的任务调度库，允许用户以简单友好的方式定期运行Python函数。',
  type: 'github_repo'
};

// [220] openai/shap-e
var gh220 = {
  index: 220,
  repo: 'openai/shap-e',
  desc: 'Shap-E是一个生成3D对象的工具，可以根据文本或图像生成条件的3D隐式函数，适用于各种创意设计。',
  raw: 'openai/shap-e Shap-E是一个生成3D对象的工具，可以根据文本或图像生成条件的3D隐式函数，适用于各种创意设计。',
  type: 'github_repo'
};

// [221] OpenMOSS/MOSS
var gh221 = {
  index: 221,
  repo: 'OpenMOSS/MOSS',
  desc: 'MOSS是复旦大学开发的开源对话语言模型工具，支持多轮对话及插件功能，适用于多种用途，如智能助手与交互式应用。',
  raw: 'OpenMOSS/MOSS MOSS是复旦大学开发的开源对话语言模型工具，支持多轮对话及插件功能，适用于多种用途，如智能助手与交互式应用。',
  type: 'github_repo'
};

// [222] tonybeltramelli/pix2code
var gh222 = {
  index: 222,
  repo: 'tonybeltramelli/pix2code',
  desc: 'pix2code是一个研究项目，利用深度学习技术从图形用户界面截图生成代码，支持iOS、Android和Web等平台。',
  raw: 'tonybeltramelli/pix2code pix2code是一个研究项目，利用深度学习技术从图形用户界面截图生成代码，支持iOS、Android和Web等平台。',
  type: 'github_repo'
};

// [223] oraios/serena
var gh223 = {
  index: 223,
  repo: 'oraios/serena',
  desc: 'Serena是一个强大的编程代理工具包，提供语义检索和编辑功能，旨在提升代码操作效率，类似于IDE的能力。',
  raw: 'oraios/serena Serena是一个强大的编程代理工具包，提供语义检索和编辑功能，旨在提升代码操作效率，类似于IDE的能力。',
  type: 'github_repo'
};

// [224] h2oai/h2ogpt
var gh224 = {
  index: 224,
  repo: 'h2oai/h2ogpt',
  desc: 'h2oGPT 是一个开源工具，允许用户与本地私有GPT模型进行聊天，支持文档、图片和视频交互，确保数据隐私。',
  raw: 'h2oai/h2ogpt h2oGPT 是一个开源工具，允许用户与本地私有GPT模型进行聊天，支持文档、图片和视频交互，确保数据隐私。',
  type: 'github_repo'
};

// [225] zai-org/CogVideo
var gh225 = {
  index: 225,
  repo: 'zai-org/CogVideo',
  desc: 'CogVideo 是一个用于图像和文本生成视频的工具，支持多模态生成，使用户能够通过简单的输入创造视频内容。',
  raw: 'zai-org/CogVideo CogVideo 是一个用于图像和文本生成视频的工具，支持多模态生成，使用户能够通过简单的输入创造视频内容。',
  type: 'github_repo'
};

// [226] cyrus-and/gdb-dashboard
var gh226 = {
  index: 226,
  repo: 'cyrus-and/gdb-dashboard',
  desc: 'GDB dashboard 是一个基于 Python 的独立 `.gdbinit` 文件，提供模块化的 GDB 界面，帮助开发者快速查看调试程序相关信息，减少命令输入。',
  raw: 'cyrus-and/gdb-dashboard GDB dashboard 是一个基于 Python 的独立 `.gdbinit` 文件，提供模块化的 GDB 界面，帮助开发者快速查看调试程序相关信息，减少命令输入。',
  type: 'github_repo'
};

// [227] mvt-project/mvt
var gh227 = {
  index: 227,
  repo: 'mvt-project/mvt',
  desc: 'MVT（Mobile Verification Toolkit）是一个工具集，用于简化和自动化收集移动设备取证痕迹，帮助识别Android和iOS设备的潜在安全风险。',
  raw: 'mvt-project/mvt MVT（Mobile Verification Toolkit）是一个工具集，用于简化和自动化收集移动设备取证痕迹，帮助识别Android和iOS设备的潜在安全风险。',
  type: 'github_repo'
};

// [228] index-tts/index-tts
var gh228 = {
  index: 228,
  repo: 'index-tts/index-tts',
  desc: 'Index-tts 是一种高效的零-shot 文本到语音系统，着重于情感表达和时长控制，适用于需要高度同步的应用，如视频配音。',
  raw: 'index-tts/index-tts Index-tts 是一种高效的零-shot 文本到语音系统，着重于情感表达和时长控制，适用于需要高度同步的应用，如视频配音。',
  type: 'github_repo'
};

// [229] guoyww/AnimateDiff
var gh229 = {
  index: 229,
  repo: 'guoyww/AnimateDiff',
  desc: 'AnimateDiff是一个将文本生成图像模型转变为动画生成器的模块，无需额外训练，支持多种社区模型。',
  raw: 'guoyww/AnimateDiff AnimateDiff是一个将文本生成图像模型转变为动画生成器的模块，无需额外训练，支持多种社区模型。',
  type: 'github_repo'
};

// [230] dbcli/mycli
var gh230 = {
  index: 230,
  repo: 'dbcli/mycli',
  desc: 'mycli是一个MySQL命令行客户端，支持自动补全和语法高亮，提升数据库操作效率。',
  raw: 'dbcli/mycli mycli是一个MySQL命令行客户端，支持自动补全和语法高亮，提升数据库操作效率。',
  type: 'github_repo'
};

// [231] coleifer/peewee
var gh231 = {
  index: 231,
  repo: 'coleifer/peewee',
  desc: 'Peewee是一个简单且小巧的ORM，支持SQLite、MySQL、MariaDB和PostgreSQL，易于学习和使用。',
  raw: 'coleifer/peewee Peewee是一个简单且小巧的ORM，支持SQLite、MySQL、MariaDB和PostgreSQL，易于学习和使用。',
  type: 'github_repo'
};

// [232] neuml/txtai
var gh232 = {
  index: 232,
  repo: 'neuml/txtai',
  desc: 'txtai是一个开源的全功能AI框架，支持语义搜索、大型语言模型编排和工作流，旨在帮助用户高效构建智能应用。',
  raw: 'neuml/txtai txtai是一个开源的全功能AI框架，支持语义搜索、大型语言模型编排和工作流，旨在帮助用户高效构建智能应用。',
  type: 'github_repo'
};

// [233] Tencent-Hunyuan/Hunyuan3D-2
var gh233 = {
  index: 233,
  repo: 'Tencent-Hunyuan/Hunyuan3D-2',
  desc: 'Hunyuan3D-2是一个高分辨率的3D资产生成工具，利用大规模的Hunyuan3D扩散模型，帮助用户创建和操控3D模型。',
  raw: 'Tencent-Hunyuan/Hunyuan3D-2 Hunyuan3D-2是一个高分辨率的3D资产生成工具，利用大规模的Hunyuan3D扩散模型，帮助用户创建和操控3D模型。',
  type: 'github_repo'
};

// [234] JoeanAmier/TikTokDownloader
var gh234 = {
  index: 234,
  repo: 'JoeanAmier/TikTokDownloader',
  desc: 'TikTokDownloader 是一款开源的工具，支持批量下载 TikTok 和抖音的各种内容，如视频、音乐和评论等数据。',
  raw: 'JoeanAmier/TikTokDownloader TikTokDownloader 是一款开源的工具，支持批量下载 TikTok 和抖音的各种内容，如视频、音乐和评论等数据。',
  type: 'github_repo'
};

// [235] pwxcoo/chinese-xinhua
var gh235 = {
  index: 235,
  repo: 'pwxcoo/chinese-xinhua',
  desc: '中华新华字典数据库提供丰富的汉字、成语、词语和歇后语数据，适合语言学习和应用开发使用。',
  raw: 'pwxcoo/chinese-xinhua 中华新华字典数据库提供丰富的汉字、成语、词语和歇后语数据，适合语言学习和应用开发使用。',
  type: 'github_repo'
};

// [236] bmaltais/kohya_ss
var gh236 = {
  index: 236,
  repo: 'bmaltais/kohya_ss',
  desc: 'Kohya\'s GUI是一个基于Gradio的图形用户界面，旨在简化扩散模型的训练，支持多种训练方法和参数设置，适合图像生成模型自定义及风格训练。',
  raw: 'bmaltais/kohya_ss Kohya\'s GUI是一个基于Gradio的图形用户界面，旨在简化扩散模型的训练，支持多种训练方法和参数设置，适合图像生成模型自定义及风格训练。',
  type: 'github_repo'
};

// [237] LonamiWebs/Telethon
var gh237 = {
  index: 237,
  repo: 'LonamiWebs/Telethon',
  desc: 'Telethon是一个Python 3库，专为用户和机器人账户设计，便于与Telegram API交互，支持发送消息、处理事件等功能。',
  raw: 'LonamiWebs/Telethon Telethon是一个Python 3库，专为用户和机器人账户设计，便于与Telegram API交互，支持发送消息、处理事件等功能。',
  type: 'github_repo'
};

// [238] NVIDIA/FastPhotoStyle
var gh238 = {
  index: 238,
  repo: 'NVIDIA/FastPhotoStyle',
  desc: 'FastPhotoStyle是一个深度学习风格迁移工具，可以将图像的风格转移到另一个图像上，适用于艺术创作和图像处理。',
  raw: 'NVIDIA/FastPhotoStyle FastPhotoStyle是一个深度学习风格迁移工具，可以将图像的风格转移到另一个图像上，适用于艺术创作和图像处理。',
  type: 'github_repo'
};

// [239] NVlabs/stylegan2
var gh239 = {
  index: 239,
  repo: 'NVlabs/stylegan2',
  desc: 'StyleGAN2是一个基于TensorFlow的生成对抗网络实现，旨在提高无条件生成图像的质量，适用于图像建模和分析。',
  raw: 'NVlabs/stylegan2 StyleGAN2是一个基于TensorFlow的生成对抗网络实现，旨在提高无条件生成图像的质量，适用于图像建模和分析。',
  type: 'github_repo'
};

// [240] Doriandarko/claude-engineer
var gh240 = {
  index: 240,
  repo: 'Doriandarko/claude-engineer',
  desc: 'Claude Engineer 是一个互动命令行界面（CLI），利用 Anthropic 的 Claude-3.5-Sonnet 模型辅助软件开发，可自动生成工具并通过对话不断扩展能力。',
  raw: 'Doriandarko/claude-engineer Claude Engineer 是一个互动命令行界面（CLI），利用 Anthropic 的 Claude-3.5-Sonnet 模型辅助软件开发，可自动生成工具并通过对话不断扩展能力。',
  type: 'github_repo'
};

// [241] QwenLM/Qwen-Agent
var gh241 = {
  index: 241,
  repo: 'QwenLM/Qwen-Agent',
  desc: 'Qwen-Agent是一个基于Qwen的框架，用于开发大型语言模型（LLM）应用，支持工具使用、规划和记忆功能，提供多种示例应用。',
  raw: 'QwenLM/Qwen-Agent Qwen-Agent是一个基于Qwen的框架，用于开发大型语言模型（LLM）应用，支持工具使用、规划和记忆功能，提供多种示例应用。',
  type: 'github_repo'
};

// [242] robotframework/robotframework
var gh242 = {
  index: 242,
  repo: 'robotframework/robotframework',
  desc: 'Robot Framework是一个通用的开源自动化框架，适用于验收测试和机器人流程自动化（RPA），支持简单的文本语法和扩展。',
  raw: 'robotframework/robotframework Robot Framework是一个通用的开源自动化框架，适用于验收测试和机器人流程自动化（RPA），支持简单的文本语法和扩展。',
  type: 'github_repo'
};

// [243] tweepy/tweepy
var gh243 = {
  index: 243,
  repo: 'tweepy/tweepy',
  desc: 'Tweepy是一个Python库，简化了Twitter API的使用，使开发者能够轻松获取和管理Twitter数据。',
  raw: 'tweepy/tweepy Tweepy是一个Python库，简化了Twitter API的使用，使开发者能够轻松获取和管理Twitter数据。',
  type: 'github_repo'
};

// [244] lengstrom/fast-style-transfer
var gh244 = {
  index: 244,
  repo: 'lengstrom/fast-style-transfer',
  desc: '这个仓库提供了基于TensorFlow的快速风格转换工具，可以将著名画作的风格应用于照片和视频，操作迅速且效果显著。',
  raw: 'lengstrom/fast-style-transfer 这个仓库提供了基于TensorFlow的快速风格转换工具，可以将著名画作的风格应用于照片和视频，操作迅速且效果显著。',
  type: 'github_repo'
};

// [245] cleanlab/cleanlab
var gh245 = {
  index: 245,
  repo: 'cleanlab/cleanlab',
  desc: 'Cleanlab是一个开源库，专注于数据质量和机器学习，帮助用户自动检测数据集中的问题，提升模型训练效果。',
  raw: 'cleanlab/cleanlab Cleanlab是一个开源库，专注于数据质量和机器学习，帮助用户自动检测数据集中的问题，提升模型训练效果。',
  type: 'github_repo'
};

// [246] gleitz/howdoi
var gh246 = {
  index: 246,
  repo: 'gleitz/howdoi',
  desc: 'howdoi是一个命令行工具，可以快速提供编程问题的即时答案，无需打开浏览器。',
  raw: 'gleitz/howdoi howdoi是一个命令行工具，可以快速提供编程问题的即时答案，无需打开浏览器。',
  type: 'github_repo'
};

// [247] kkroening/ffmpeg-python
var gh247 = {
  index: 247,
  repo: 'kkroening/ffmpeg-python',
  desc: 'ffmpeg-python是FFmpeg的Python绑定，支持简单及复杂的滤镜图形，方便进行视频处理与转换。',
  raw: 'kkroening/ffmpeg-python ffmpeg-python是FFmpeg的Python绑定，支持简单及复杂的滤镜图形，方便进行视频处理与转换。',
  type: 'github_repo'
};

// [248] microsoft/promptflow
var gh248 = {
  index: 248,
  repo: 'microsoft/promptflow',
  desc: 'Promptflow 是一款开发工具套件，旨在简化基于 LLM 的 AI 应用程序的全生命周期开发，包括原型设计、测试、部署和监控。',
  raw: 'microsoft/promptflow Promptflow 是一款开发工具套件，旨在简化基于 LLM 的 AI 应用程序的全生命周期开发，包括原型设计、测试、部署和监控。',
  type: 'github_repo'
};

// [249] speechbrain/speechbrain
var gh249 = {
  index: 249,
  repo: 'speechbrain/speechbrain',
  desc: 'SpeechBrain是一个基于PyTorch的开源工具包，旨在加速会话AI开发，包括语音助手和聊天机器人等技术的构建。',
  raw: 'speechbrain/speechbrain SpeechBrain是一个基于PyTorch的开源工具包，旨在加速会话AI开发，包括语音助手和聊天机器人等技术的构建。',
  type: 'github_repo'
};

// [250] x-hw/amazing-qr
var gh250 = {
  index: 250,
  repo: 'x-hw/amazing-qr',
  desc: 'Amazing-QR 是一个用 Python 编写的二维码生成器，支持生成静态和动态二维码，包括艺术风格的设计。',
  raw: 'x-hw/amazing-qr Amazing-QR 是一个用 Python 编写的二维码生成器，支持生成静态和动态二维码，包括艺术风格的设计。',
  type: 'github_repo'
};

// [251] guofei9987/blind_watermark
var gh251 = {
  index: 251,
  repo: 'guofei9987/blind_watermark',
  desc: '这是一个基于DWT-DCT-SVD的盲水印工具，能够在无需原图的情况下提取图片水印。',
  raw: 'guofei9987/blind_watermark 这是一个基于DWT-DCT-SVD的盲水印工具，能够在无需原图的情况下提取图片水印。',
  type: 'github_repo'
};

// [252] keephq/keep
var gh252 = {
  index: 252,
  repo: 'keephq/keep',
  desc: '这是一个开源的AIOps和告警管理平台，提供告警去重、丰富、过滤和关联功能，支持双向集成和自定义工作流程，旨在提升告警管理效率。',
  raw: 'keephq/keep 这是一个开源的AIOps和告警管理平台，提供告警去重、丰富、过滤和关联功能，支持双向集成和自定义工作流程，旨在提升告警管理效率。',
  type: 'github_repo'
};

// [253] amueller/word_cloud
var gh253 = {
  index: 253,
  repo: 'amueller/word_cloud',
  desc: 'word_cloud是一个基于Python的词云生成器，用户可以通过命令行或脚本生成视觉美观的词云。',
  raw: 'amueller/word_cloud word_cloud是一个基于Python的词云生成器，用户可以通过命令行或脚本生成视觉美观的词云。',
  type: 'github_repo'
};

// [254] SparkAudio/Spark-TTS
var gh254 = {
  index: 254,
  repo: 'SparkAudio/Spark-TTS',
  desc: 'Spark-TTS是一个高效的基于LLM的文本到语音模型的推理代码，使用PyTorch实现，旨在提供流畅的语音合成。',
  raw: 'SparkAudio/Spark-TTS Spark-TTS是一个高效的基于LLM的文本到语音模型的推理代码，使用PyTorch实现，旨在提供流畅的语音合成。',
  type: 'github_repo'
};

// [255] confident-ai/deepeval
var gh255 = {
  index: 255,
  repo: 'confident-ai/deepeval',
  desc: 'DeepEval 是一个用于大型语言模型（LLM）评估的框架，旨在提供实用的评估指标和功能，以支持科研和开发工作。',
  raw: 'confident-ai/deepeval DeepEval 是一个用于大型语言模型（LLM）评估的框架，旨在提供实用的评估指标和功能，以支持科研和开发工作。',
  type: 'github_repo'
};

// [256] thumbor/thumbor
var gh256 = {
  index: 256,
  repo: 'thumbor/thumbor',
  desc: 'thumbor是一个开源的照片缩略图服务，旨在帮助用户快速生成和管理图像缩略图。',
  raw: 'thumbor/thumbor thumbor是一个开源的照片缩略图服务，旨在帮助用户快速生成和管理图像缩略图。',
  type: 'github_repo'
};

// [257] rq/rq
var gh257 = {
  index: 257,
  repo: 'rq/rq',
  desc: 'RQ是一个简单的Python库，可用于后台处理作业，并支持与Redis或Valkey集成，适合各种规模的项目。',
  raw: 'rq/rq RQ是一个简单的Python库，可用于后台处理作业，并支持与Redis或Valkey集成，适合各种规模的项目。',
  type: 'github_repo'
};

// [258] harelba/q
var gh258 = {
  index: 258,
  repo: 'harelba/q',
  desc: 'q 是一个用于直接在分隔文件和多文件 SQLite 数据库上运行 SQL 查询的工具，极大简化了数据处理和分析的过程。',
  raw: 'harelba/q q 是一个用于直接在分隔文件和多文件 SQLite 数据库上运行 SQL 查询的工具，极大简化了数据处理和分析的过程。',
  type: 'github_repo'
};

// [259] wandb/wandb
var gh259 = {
  index: 259,
  repo: 'wandb/wandb',
  desc: 'Weights & Biases 是 AI 开发平台，帮助用户监控和优化机器学习模型，从实验到生产管理模型。提供可视化工具，提升模型训练效率。',
  raw: 'wandb/wandb Weights & Biases 是 AI 开发平台，帮助用户监控和优化机器学习模型，从实验到生产管理模型。提供可视化工具，提升模型训练效率。',
  type: 'github_repo'
};

// [260] benoitc/gunicorn
var gh260 = {
  index: 260,
  repo: 'benoitc/gunicorn',
  desc: 'Gunicorn是一个针对UNIX的Python WSGI HTTP服务器，适合快速客户端和资源占用低的应用程序。支持多种Web框架，使用简单，性能良好。',
  raw: 'benoitc/gunicorn Gunicorn是一个针对UNIX的Python WSGI HTTP服务器，适合快速客户端和资源占用低的应用程序。支持多种Web框架，使用简单，性能良好。',
  type: 'github_repo'
};

// [261] doccano/doccano
var gh261 = {
  index: 261,
  repo: 'doccano/doccano',
  desc: 'doccano是一个开源文本标注工具，主要用于机器学习中的数据标注，支持文本分类、序列标注等任务，帮助用户快速构建标注数据集。',
  raw: 'doccano/doccano doccano是一个开源文本标注工具，主要用于机器学习中的数据标注，支持文本分类、序列标注等任务，帮助用户快速构建标注数据集。',
  type: 'github_repo'
};

// [262] ymcui/Chinese-BERT-wwm
var gh262 = {
  index: 262,
  repo: 'ymcui/Chinese-BERT-wwm',
  desc: 'Chinese-BERT-wwm是基于全词掩码技术的中文预训练BERT模型，旨在提升中文自然语言处理的效果和研究。',
  raw: 'ymcui/Chinese-BERT-wwm Chinese-BERT-wwm是基于全词掩码技术的中文预训练BERT模型，旨在提升中文自然语言处理的效果和研究。',
  type: 'github_repo'
};

// [263] Megvii-BaseDetection/YOLOX
var gh263 = {
  index: 263,
  repo: 'Megvii-BaseDetection/YOLOX',
  desc: 'YOLOX 是一种高性能的无锚版本 YOLO，简化了设计，性能优越，支持多种深度学习框架，旨在促进研究与工业界的结合。',
  raw: 'Megvii-BaseDetection/YOLOX YOLOX 是一种高性能的无锚版本 YOLO，简化了设计，性能优越，支持多种深度学习框架，旨在促进研究与工业界的结合。',
  type: 'github_repo'
};

// [264] pypa/pip
var gh264 = {
  index: 264,
  repo: 'pypa/pip',
  desc: 'pip是Python的包管理工具，使用户能够从Python包索引及其他来源轻松安装和管理Python包。',
  raw: 'pypa/pip pip是Python的包管理工具，使用户能够从Python包索引及其他来源轻松安装和管理Python包。',
  type: 'github_repo'
};

// [265] lucidrains/denoising-diffusion-pytorch
var gh265 = {
  index: 265,
  repo: 'lucidrains/denoising-diffusion-pytorch',
  desc: '该仓库实现了去噪扩散概率模型的Pytorch版本，适用于生成建模，与GANs技术竞争。',
  raw: 'lucidrains/denoising-diffusion-pytorch 该仓库实现了去噪扩散概率模型的Pytorch版本，适用于生成建模，与GANs技术竞争。',
  type: 'github_repo'
};

// [266] nbedos/termtosvg
var gh266 = {
  index: 266,
  repo: 'nbedos/termtosvg',
  desc: 'termtosvg是一个基于Python的Unix终端录像工具，可以将命令行会话转换为独立的SVG动画，方便嵌入项目页面。',
  raw: 'nbedos/termtosvg termtosvg是一个基于Python的Unix终端录像工具，可以将命令行会话转换为独立的SVG动画，方便嵌入项目页面。',
  type: 'github_repo'
};

// [267] facebookresearch/pifuhd
var gh267 = {
  index: 267,
  repo: 'facebookresearch/pifuhd',
  desc: 'PIFuHD是一个高分辨率3D人体数字化工具，基于单张图像实现，可以通过PyTorch在Google Colab上运行和可视化。',
  raw: 'facebookresearch/pifuhd PIFuHD是一个高分辨率3D人体数字化工具，基于单张图像实现，可以通过PyTorch在Google Colab上运行和可视化。',
  type: 'github_repo'
};

// [268] modelscope/DiffSynth-Studio
var gh268 = {
  index: 268,
  repo: 'modelscope/DiffSynth-Studio',
  desc: 'DiffSynth-Studio 是一个开源扩散模型引擎，旨在推动技术创新和生成模型的探索，支持学术研究及前沿模型能力的开发。',
  raw: 'modelscope/DiffSynth-Studio DiffSynth-Studio 是一个开源扩散模型引擎，旨在推动技术创新和生成模型的探索，支持学术研究及前沿模型能力的开发。',
  type: 'github_repo'
};

// [269] facebookresearch/nougat
var gh269 = {
  index: 269,
  repo: 'facebookresearch/nougat',
  desc: 'Nougat是用于学术文档的PDF解析器，能够理解LaTeX数学公式和表格，使学术文献处理更加高效。',
  raw: 'facebookresearch/nougat Nougat是用于学术文档的PDF解析器，能够理解LaTeX数学公式和表格，使学术文献处理更加高效。',
  type: 'github_repo'
};

// [270] jiaaro/pydub
var gh270 = {
  index: 270,
  repo: 'jiaaro/pydub',
  desc: 'pydub是一个Python库，提供简单易用的高级接口，用于音频处理和操作。',
  raw: 'jiaaro/pydub pydub是一个Python库，提供简单易用的高级接口，用于音频处理和操作。',
  type: 'github_repo'
};

// [271] wangshub/Douyin-Bot
var gh271 = {
  index: 271,
  repo: 'wangshub/Douyin-Bot',
  desc: 'Douyin-Bot 是一个使用 Python 开发的抖音机器人，旨在通过自动翻页、颜值检测与人脸识别等功能，快速找到并关注抖音上的漂亮小姐姐。',
  raw: 'wangshub/Douyin-Bot Douyin-Bot 是一个使用 Python 开发的抖音机器人，旨在通过自动翻页、颜值检测与人脸识别等功能，快速找到并关注抖音上的漂亮小姐姐。',
  type: 'github_repo'
};

// [272] sloria/TextBlob
var gh272 = {
  index: 272,
  repo: 'sloria/TextBlob',
  desc: 'TextBlob是一个Python库，简化自然语言处理任务，如情感分析、词性标注和名词短语提取。',
  raw: 'sloria/TextBlob TextBlob是一个Python库，简化自然语言处理任务，如情感分析、词性标注和名词短语提取。',
  type: 'github_repo'
};

// [273] healthchecks/healthchecks
var gh273 = {
  index: 273,
  repo: 'healthchecks/healthchecks',
  desc: 'Healthchecks是一个开源的定时任务监控服务，能够监听来自定时任务的HTTP请求并发送警报，提供Web仪表板、API及多种通知集成功能。',
  raw: 'healthchecks/healthchecks Healthchecks是一个开源的定时任务监控服务，能够监听来自定时任务的HTTP请求并发送警报，提供Web仪表板、API及多种通知集成功能。',
  type: 'github_repo'
};

// [274] bytedance/trae-agent
var gh274 = {
  index: 274,
  repo: 'bytedance/trae-agent',
  desc: 'Trae Agent是一个基于大语言模型的通用软件工程任务代理，支持自然语言指令和复杂工作流的执行。',
  raw: 'bytedance/trae-agent Trae Agent是一个基于大语言模型的通用软件工程任务代理，支持自然语言指令和复杂工作流的执行。',
  type: 'github_repo'
};

// [275] py-pdf/pypdf
var gh275 = {
  index: 275,
  repo: 'py-pdf/pypdf',
  desc: 'pypdf是一个纯Python的PDF库，支持PDF文件的拆分、合并、剪裁及转换页面，同时能够提取文本和元数据，处理加密与解密。',
  raw: 'py-pdf/pypdf pypdf是一个纯Python的PDF库，支持PDF文件的拆分、合并、剪裁及转换页面，同时能够提取文本和元数据，处理加密与解密。',
  type: 'github_repo'
};

// [276] xuebinqin/U-2-Net
var gh276 = {
  index: 276,
  repo: 'xuebinqin/U-2-Net',
  desc: 'U-2-Net是一个用于显著目标检测的深度学习模型，采用嵌套U结构，旨在提高图像分割精度。',
  raw: 'xuebinqin/U-2-Net U-2-Net是一个用于显著目标检测的深度学习模型，采用嵌套U结构，旨在提高图像分割精度。',
  type: 'github_repo'
};

// [277] malwaredllc/byob
var gh277 = {
  index: 277,
  repo: 'malwaredllc/byob',
  desc: 'BYOB是一个开源的后渗透框架，专为学生、研究人员和开发者设计，提供命令与控制服务器、定制负载生成器及多种后渗透模块。',
  raw: 'malwaredllc/byob BYOB是一个开源的后渗透框架，专为学生、研究人员和开发者设计，提供命令与控制服务器、定制负载生成器及多种后渗透模块。',
  type: 'github_repo'
};

// [278] facebookresearch/demucs
var gh278 = {
  index: 278,
  repo: 'facebookresearch/demucs',
  desc: 'Demucs是一个先进的音乐源分离模型，能够将鼓声、低音和人声从伴奏中分离，基于混合变压器的构架实现高效音频处理。',
  raw: 'facebookresearch/demucs Demucs是一个先进的音乐源分离模型，能够将鼓声、低音和人声从伴奏中分离，基于混合变压器的构架实现高效音频处理。',
  type: 'github_repo'
};

// [279] shmilylty/OneForAll
var gh279 = {
  index: 279,
  repo: 'shmilylty/OneForAll',
  desc: 'OneForAll是一款强大的子域收集工具，旨在帮助用户高效地进行域名的子域信息收集与管理。',
  raw: 'shmilylty/OneForAll OneForAll是一款强大的子域收集工具，旨在帮助用户高效地进行域名的子域信息收集与管理。',
  type: 'github_repo'
};

// [280] PaddlePaddle/PaddleSeg
var gh280 = {
  index: 280,
  repo: 'PaddlePaddle/PaddleSeg',
  desc: 'PaddleSeg 是一款易于使用的图像分割库，提供丰富的预训练模型，支持多种语义分割、交互式分割等实用任务。',
  raw: 'PaddlePaddle/PaddleSeg PaddleSeg 是一款易于使用的图像分割库，提供丰富的预训练模型，支持多种语义分割、交互式分割等实用任务。',
  type: 'github_repo'
};

// [281] voicepaw/so-vits-svc-fork
var gh281 = {
  index: 281,
  repo: 'voicepaw/so-vits-svc-fork',
  desc: '这是一个支持实时功能的VITS唱歌声音转换工具的Fork版本，提供了改进的界面和更多功能，方便用户进行声音转换。',
  raw: 'voicepaw/so-vits-svc-fork 这是一个支持实时功能的VITS唱歌声音转换工具的Fork版本，提供了改进的界面和更多功能，方便用户进行声音转换。',
  type: 'github_repo'
};

// [282] PeterL1n/RobustVideoMatting
var gh282 = {
  index: 282,
  repo: 'PeterL1n/RobustVideoMatting',
  desc: 'Robust Video Matting是一个高效的视频抠像工具，支持实时处理，通过时间记忆提高抠像效果，旨在为用户提供高质量的视频处理体验。',
  raw: 'PeterL1n/RobustVideoMatting Robust Video Matting是一个高效的视频抠像工具，支持实时处理，通过时间记忆提高抠像效果，旨在为用户提供高质量的视频处理体验。',
  type: 'github_repo'
};

// [283] bunkerity/bunkerweb
var gh283 = {
  index: 283,
  repo: 'bunkerity/bunkerweb',
  desc: 'BunkerWeb是一个开源的下一代Web应用防火墙（WAF），旨在提供增强的安全性和实时防护。',
  raw: 'bunkerity/bunkerweb BunkerWeb是一个开源的下一代Web应用防火墙（WAF），旨在提供增强的安全性和实时防护。',
  type: 'github_repo'
};

// [284] Acly/krita-ai-diffusion
var gh284 = {
  index: 284,
  repo: 'Acly/krita-ai-diffusion',
  desc: '这个仓库提供Krita的生成式AI插件，简化图像创作与编辑流程，支持文本提示生成、局部修整等功能，适合艺术创作。',
  raw: 'Acly/krita-ai-diffusion 这个仓库提供Krita的生成式AI插件，简化图像创作与编辑流程，支持文本提示生成、局部修整等功能，适合艺术创作。',
  type: 'github_repo'
};

// [285] rany2/edge-tts
var gh285 = {
  index: 285,
  repo: 'rany2/edge-tts',
  desc: 'edge-tts是一个Python模块，允许用户通过Python代码使用Microsoft Edge的在线文本转语音服务，无需安装Edge或Windows，且不需要API密钥。',
  raw: 'rany2/edge-tts edge-tts是一个Python模块，允许用户通过Python代码使用Microsoft Edge的在线文本转语音服务，无需安装Edge或Windows，且不需要API密钥。',
  type: 'github_repo'
};

// [286] kyutai-labs/moshi
var gh286 = {
  index: 286,
  repo: 'kyutai-labs/moshi',
  desc: 'Moshi是一个实时对话的语音文本基础模型，提供全双工的语音对话框架，旨在实现高效的语音交互。',
  raw: 'kyutai-labs/moshi Moshi是一个实时对话的语音文本基础模型，提供全双工的语音对话框架，旨在实现高效的语音交互。',
  type: 'github_repo'
};

// [287] yihong0618/bilingual_book_maker
var gh287 = {
  index: 287,
  repo: 'yihong0618/bilingual_book_maker',
  desc: 'bilingual_book_maker是一个利用AI翻译工具生成双语epub书籍的应用，专为公共领域书籍设计，支持多种型号的GPT翻译。使用简单，适合需要创建多语言书籍的用户。',
  raw: 'yihong0618/bilingual_book_maker bilingual_book_maker是一个利用AI翻译工具生成双语epub书籍的应用，专为公共领域书籍设计，支持多种型号的GPT翻译。使用简单，适合需要创建多语言书籍的用户。',
  type: 'github_repo'
};

// [288] google/magika
var gh288 = {
  index: 288,
  repo: 'google/magika',
  desc: 'Magika是一个基于深度学习的文件类型检测工具，能够快速准确地识别不同类型的文件，提升用户安全性。',
  raw: 'google/magika Magika是一个基于深度学习的文件类型检测工具，能够快速准确地识别不同类型的文件，提升用户安全性。',
  type: 'github_repo'
};

// [289] activeloopai/deeplake
var gh289 = {
  index: 289,
  repo: 'activeloopai/deeplake',
  desc: 'Deep Lake是一个AI数据库，旨在存储、查询和可视化各类AI数据，如矢量、图像和文本，并支持PyTorch/TensorFlow实时流数据。',
  raw: 'activeloopai/deeplake Deep Lake是一个AI数据库，旨在存储、查询和可视化各类AI数据，如矢量、图像和文本，并支持PyTorch/TensorFlow实时流数据。',
  type: 'github_repo'
};

// [290] IDEA-Research/GroundingDINO
var gh290 = {
  index: 290,
  repo: 'IDEA-Research/GroundingDINO',
  desc: 'Grounding DINO 是一个开源物体检测框架，结合DINO和基础预训练技术，旨在提升开放集物体检测的性能。',
  raw: 'IDEA-Research/GroundingDINO Grounding DINO 是一个开源物体检测框架，结合DINO和基础预训练技术，旨在提升开放集物体检测的性能。',
  type: 'github_repo'
};

// [291] ashawkey/stable-dreamfusion
var gh291 = {
  index: 291,
  repo: 'ashawkey/stable-dreamfusion',
  desc: 'Stable-Dreamfusion 是一个基于 PyTorch 的文本到 3D 模型实现，结合了 Stable Diffusion，用于生成 3D 内容和导出网格。',
  raw: 'ashawkey/stable-dreamfusion Stable-Dreamfusion 是一个基于 PyTorch 的文本到 3D 模型实现，结合了 Stable Diffusion，用于生成 3D 内容和导出网格。',
  type: 'github_repo'
};

// [292] jianchang512/clone-voice
var gh292 = {
  index: 292,
  repo: 'jianchang512/clone-voice',
  desc: 'clone-voice是一个基于web界面的声音克隆工具，用户可以使用特定音色合成语音或将不同声音转换为特定音色，支持多种语言。',
  raw: 'jianchang512/clone-voice clone-voice是一个基于web界面的声音克隆工具，用户可以使用特定音色合成语音或将不同声音转换为特定音色，支持多种语言。',
  type: 'github_repo'
};

// [293] NVIDIA/vid2vid
var gh293 = {
  index: 293,
  repo: 'NVIDIA/vid2vid',
  desc: 'vid2vid是一个基于Pytorch的视频翻译实现，能够将语义标签图转化为高分辨率照片级真实感视频，支持多种输入形式，例如边缘图和姿态图。',
  raw: 'NVIDIA/vid2vid vid2vid是一个基于Pytorch的视频翻译实现，能够将语义标签图转化为高分辨率照片级真实感视频，支持多种输入形式，例如边缘图和姿态图。',
  type: 'github_repo'
};

// [294] bottlepy/bottle
var gh294 = {
  index: 294,
  repo: 'bottlepy/bottle',
  desc: 'Bottle是一个快速、简单的Python微框架，主要用于构建Web应用，具有路由、模板和实用工具等功能。',
  raw: 'bottlepy/bottle Bottle是一个快速、简单的Python微框架，主要用于构建Web应用，具有路由、模板和实用工具等功能。',
  type: 'github_repo'
};

// [295] fudan-generative-vision/hallo
var gh295 = {
  index: 295,
  repo: 'fudan-generative-vision/hallo',
  desc: 'Hallo是一个基于音频驱动的分层视觉合成工具，用于动画肖像图像，适用于生成生动的视觉表现。',
  raw: 'fudan-generative-vision/hallo Hallo是一个基于音频驱动的分层视觉合成工具，用于动画肖像图像，适用于生成生动的视觉表现。',
  type: 'github_repo'
};

// [296] evilsocket/pwnagotchi
var gh296 = {
  index: 296,
  repo: 'evilsocket/pwnagotchi',
  desc: 'Pwnagotchi是一个基于深度强化学习的工具，利用bettercap自动学习WiFi环境以捕获可破解的WPA密钥材料，帮助渗透测试和网络安全研究。',
  raw: 'evilsocket/pwnagotchi Pwnagotchi是一个基于深度强化学习的工具，利用bettercap自动学习WiFi环境以捕获可破解的WPA密钥材料，帮助渗透测试和网络安全研究。',
  type: 'github_repo'
};

// [297] fishaudio/Bert-VITS2
var gh297 = {
  index: 297,
  repo: 'fishaudio/Bert-VITS2',
  desc: 'Bert-VITS2是基于多语言BERT的自回归语音合成框架，旨在提供高质量的文本到语音转换，适合开发者进行自定义训练和应用。',
  raw: 'fishaudio/Bert-VITS2 Bert-VITS2是基于多语言BERT的自回归语音合成框架，旨在提供高质量的文本到语音转换，适合开发者进行自定义训练和应用。',
  type: 'github_repo'
};

// [298] JoeanAmier/XHS-Downloader
var gh298 = {
  index: 298,
  repo: 'JoeanAmier/XHS-Downloader',
  desc: 'XHS-Downloader是一个小红书链接提取与作品采集工具，支持提取账号作品、下载无水印文件及采集作品信息。',
  raw: 'JoeanAmier/XHS-Downloader XHS-Downloader是一个小红书链接提取与作品采集工具，支持提取账号作品、下载无水印文件及采集作品信息。',
  type: 'github_repo'
};

// [299] yandex/gixy
var gh299 = {
  index: 299,
  repo: 'yandex/gixy',
  desc: 'Gixy是一个用于分析Nginx配置的工具，旨在防止安全配置错误并自动检测漏洞。',
  raw: 'yandex/gixy Gixy是一个用于分析Nginx配置的工具，旨在防止安全配置错误并自动检测漏洞。',
  type: 'github_repo'
};

// [300] pdm-project/pdm
var gh300 = {
  index: 300,
  repo: 'pdm-project/pdm',
  desc: 'PDM是一个现代的Python包和依赖管理工具，支持最新的PEP标准，旨在提供简便实用的包管理体验。',
  raw: 'pdm-project/pdm PDM是一个现代的Python包和依赖管理工具，支持最新的PEP标准，旨在提供简便实用的包管理体验。',
  type: 'github_repo'
};
// 所有项目的数组
var gh_list = [gh001, gh002, gh003, gh004, gh005, gh006, gh007, gh008, gh009, gh010, gh011, gh012, gh013, gh014, gh015, gh016, gh017, gh018, gh019, gh020, gh021, gh022, gh023, gh024, gh025, gh026, gh027, gh028, gh029, gh030, gh031, gh032, gh033, gh034, gh035, gh036, gh037, gh038, gh039, gh040, gh041, gh042, gh043, gh044, gh045, gh046, gh047, gh048, gh049, gh050, gh051, gh052, gh053, gh054, gh055, gh056, gh057, gh058, gh059, gh060, gh061, gh062, gh063, gh064, gh065, gh066, gh067, gh068, gh069, gh070, gh071, gh072, gh073, gh074, gh075, gh076, gh077, gh078, gh079, gh080, gh081, gh082, gh083, gh084, gh085, gh086, gh087, gh088, gh089, gh090, gh091, gh092, gh093, gh094, gh095, gh096, gh097, gh098, gh099, gh100, gh101, gh102, gh103, gh104, gh105, gh106, gh107, gh108, gh109, gh110, gh111, gh112, gh113, gh114, gh115, gh116, gh117, gh118, gh119, gh120, gh121, gh122, gh123, gh124, gh125, gh126, gh127, gh128, gh129, gh130, gh131, gh132, gh133, gh134, gh135, gh136, gh137, gh138, gh139, gh140, gh141, gh142, gh143, gh144, gh145, gh146, gh147, gh148, gh149, gh150, gh151, gh152, gh153, gh154, gh155, gh156, gh157, gh158, gh159, gh160, gh161, gh162, gh163, gh164, gh165, gh166, gh167, gh168, gh169, gh170, gh171, gh172, gh173, gh174, gh175, gh176, gh177, gh178, gh179, gh180, gh181, gh182, gh183, gh184, gh185, gh186, gh187, gh188, gh189, gh190, gh191, gh192, gh193, gh194, gh195, gh196, gh197, gh198, gh199, gh200, gh201, gh202, gh203, gh204, gh205, gh206, gh207, gh208, gh209, gh210, gh211, gh212, gh213, gh214, gh215, gh216, gh217, gh218, gh219, gh220, gh221, gh222, gh223, gh224, gh225, gh226, gh227, gh228, gh229, gh230, gh231, gh232, gh233, gh234, gh235, gh236, gh237, gh238, gh239, gh240, gh241, gh242, gh243, gh244, gh245, gh246, gh247, gh248, gh249, gh250, gh251, gh252, gh253, gh254, gh255, gh256, gh257, gh258, gh259, gh260, gh261, gh262, gh263, gh264, gh265, gh266, gh267, gh268, gh269, gh270, gh271, gh272, gh273, gh274, gh275, gh276, gh277, gh278, gh279, gh280, gh281, gh282, gh283, gh284, gh285, gh286, gh287, gh288, gh289, gh290, gh291, gh292, gh293, gh294, gh295, gh296, gh297, gh298, gh299, gh300];