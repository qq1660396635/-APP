window.toolsConfig = {
  tools: [
    { "name": "Termux工具安装","file": "3.termux工具安装/termux_安装导航.html", "icon": "📦", "description": "Termux工具安装导航" },
    { "name": "Termux脚本",    "file": "4.termux脚本/tm脚本导航.html",   "icon": "⚙️", "description": "Termux脚本相关功能" },
    { "name": "宇宙时间戳", "file": "宇宙时间戳.html", "icon": "📅", "description": "宇宙时间戳" },

    { "name": "开源脚本",      "file": "1.命令配置/脚本_导航.html",    "icon": "📄", "description": "命令配置和脚本导航" },
    { "name": "标准库函数",    "file": "2.标准库函数/标准库_导航.html", "icon": "📚", "description": "标准库函数导航" },
    { "name": "本地服务",      "file": "7.本地服务/客户端_导航.html",  "icon": "🖥️", "description": "本地服务和客户端导航" },
    
    { "name": "小说素材导航",  "file": "5.小说素材/信息_导航.html",    "icon": "📓", "description": "小说素材和信息导航" },
    { "name": "生活导航",      "file": "6.生活导航/服务_导航.html",   "icon": "🏠", "description": "生活服务导航" },
  ],
  getAllTools() { return this.tools; },
};
