window.navConfig = {
  tools: [
    { name: '物理评论快报-12月', file: '1.物理评论快报-12月.html', icon: '📊', description: '物理评论快报数据分析' },
    { name: '科创版前60', file: '2.科创版前60.html', icon: '📈', description: '科创版前60数据分析' },
    { name: 'steam畅销榜', file: '3.steam畅销榜.html', icon: '🎮', description: 'Steam畅销榜数据分析' },
    { name: '中华小吃', file: '4.中华小吃.html', icon: '🥟', description: '中华小吃数据分析' },
    { name: '岁月史书', file: '5.岁月史书.html', icon: '👴', description: '岁月史书数据分析' }
  ],
  getAllTools() { return this.tools; }
};
