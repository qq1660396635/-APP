window.navConfig = {
  tools: [
    { name: '拉取语法高亮', file: '1.拉取语法高亮.html', icon: '🚀', description: '从服务器拉取语法高亮配置' },
    { name: '判断视频是否失效', file: '2.判断视频是否失效.html', icon: '📺', description: '判断视频链接是否失效' },
    { name: 'tm-VNC', file: '3.tm-VNC.html', icon: '🖥️', description: '服务器开机管理' },
    { name: 'tm-uniapp开发', file: '4.tm-uniapp开发.html', icon: '📱', description: 'UniApp开发工具' },
  ]
};
