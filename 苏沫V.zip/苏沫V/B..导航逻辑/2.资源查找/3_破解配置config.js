const sites = [
    {name: '笔趣阁', url: 'https://m.bqg128.cc/', icon: '📚'},
    {name: '娜娜', url: 'https://nana00.com/xs124595/', icon: '📝'},
    {name: '读之阁', url: 'https://www.xiaolipan.com/index.html', icon: '📖'},
    {name: '王者TV', url: 'https://wzzy.cc/', icon: '👑'},
    {name: '风车动漫', url: 'https://www.dm304.com/', icon: '🎬'},
    {name: '樱花动漫', url: 'https://m.yinghuadongmancn.com/', icon: '🌸'},
    {name: '好多漫画', url: 'https://m.haoduoman.com/ ', icon: '🎨'},
    {name: '漫画城', url: 'http://www.btmaps.cn/', icon: '🎏'}
];
