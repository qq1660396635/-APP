window.toolsConfig = {
  tools: [
    { name: '今天看点啥', file: '1.今天看点啥.html', icon: '📺', description: '今日推荐内容查看' },
    { name: '模型提示词', file: '2_提示词中心.html', icon: '💡', description: 'AI提示词管理与分享' },
  
  ],
  getAllTools() { return this.tools; },
};
