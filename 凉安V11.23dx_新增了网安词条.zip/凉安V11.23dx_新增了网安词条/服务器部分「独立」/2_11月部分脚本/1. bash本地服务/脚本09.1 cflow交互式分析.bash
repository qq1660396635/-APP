#!/bin/bash
# 一键生成干净、带序号的 cflow 调用树，保存在同级目录
# 用法：bash cflow_clean.sh

set -euo pipefail

# 1. 手动输入文件路径（支持空格）
read -r -p "请输入要分析的 C 源文件路径（支持空格）: " input_path
[[ -z "$input_path" ]] && { echo "❌ 未输入路径，退出"; exit 1; }

# 去掉首尾引号（如果有）
input_path="${input_path%\"}"
input_path="${input_path#\"}"

# 2. 检查文件是否存在
[[ -f "$input_path" ]] || { echo "❌ 文件不存在：$input_path"; exit 1; }

# 3. 取目录和文件名
dir=$(dirname "$input_path")
base=$(basename "$input_path" .c)
output="$dir/${base}_calltree.md"

# 4. 运行 cflow，失败则提示
echo "🔄 正在生成调用树 ..."
if ! cflow "$input_path" 2>"$dir/cflow.err" | \
awk '
BEGIN { idx=1 }
/^[^ \t]/ {
    # 顶层函数
    gsub(/<.*>/, "")  # 去掉 <...>
    gsub(/\(.*\)/, "") # 去掉 ()
    gsub(/^[ \t]+|[ \t]+$/, "")
    printf "%2d. %s\n", idx++, $0
}
/^[ \t]+/ {
    # 子函数
    gsub(/<.*>/, "")
    gsub(/\(.*\)/, "")
    gsub(/^[ \t]+|[ \t]+$/, "")
    printf "    ├─ %s\n", $0
}
' > "$output"; then
    echo "❌ cflow 报错："
    cat "$dir/cflow.err"
    rm -f "$output" "$dir/cflow.err"
    exit 1
fi

rm -f "$dir/cflow.err"
echo "✅ 干净调用树已生成：$output"
