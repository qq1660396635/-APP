#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[0;33m'; RST='\033[0m'
log_info(){ echo -e "${YLW}[INFO]${RST} $*"; }
log_ok(){ echo -e "${GRN}[OK]${RST} $*"; }
log_err(){ echo -e "${RED}[ERR]${RST} $*"; }

PREFIX="/data/data/com.termux/files/usr"
WORK="$HOME/cflow-work"
TARBALL="$WORK/cflow-1.7.tar.gz"
SOURCE="$WORK/cflow-1.7"

########## 1. 准备 ##########
log_info "① 创建工作目录"
mkdir -p "$WORK"
cd "$WORK"

########## 2. 依赖 ##########
log_info "② 安装依赖"
for dep in clang make wget autoconf automake gettext binutils; do
    command -v "$dep" &>/dev/null || pkg install -y "$dep"
done
log_ok "依赖就绪"

########## 3. 下载 ##########
log_info "③ 下载源码"
[[ -f $TARBALL ]] || wget -O "$TARBALL" https://ftp.gnu.org/gnu/cflow/cflow-1.7.tar.gz
log_ok "下载完成"

########## 4. 解压 ##########
log_info "④ 解压"
tar -xzf "$TARBALL"
cd "$SOURCE"
log_ok "源码已解压到 $SOURCE"

########## 5. 直接 configure ##########
log_info "⑤ 配置"
./configure --prefix="$PREFIX"
log_ok "配置完成"

########## 6. 编译 ##########
log_info "⑥ 编译"
make -j"$(nproc)"
log_ok "编译完成"

########## 7. 安装 ##########
log_info "⑦ 安装"
make install
log_ok "安装完成"

########## 8. 验证 ##########
log_info "⑧ 验证"
cflow --version
log_ok "全部完成！用法：cflow <源文件>"
