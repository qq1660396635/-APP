#!/bin/bash
# 一键中文分析报告：调用树 + 符号列表，结果与源文件同目录
set -euo pipefail

# 1. 读文件（支持空格）
read -r -p "请输入要分析的 C 源文件路径（支持空格）: " SRC
[[ -z "$SRC" ]] && { echo "❌ 未输入路径，退出"; exit 1; }
SRC="${SRC%\"}"
SRC="${SRC#\"}"
[[ -f "$SRC" ]] || { echo "❌ 文件不存在：$SRC"; exit 1; }

DIR=$(dirname "$SRC")
BASE=$(basename "$SRC" | sed 's/\.[^.]*$//')
REPORT="$DIR/${BASE}_分析报告.md"

# 2. 写报告头
cat > "$REPORT" <<EOF
# ${BASE}  中文分析报告
> 文件：\`$SRC\`  
> 生成时间：$(date "+%Y-%m-%d %H:%M:%S")

---

## 一、函数调用关系
EOF

# 3. 生成调用树（带序号）
echo "🔄 生成调用树 ..."
if ! cflow "$SRC" 2>/dev/null | awk '
BEGIN{idx=1}
/^[^ \t]/{gsub(/<.*>/,"");gsub(/\(.*\)/,"");gsub(/^[ \t]+|[ \t]+$/,"");printf "%2d. %s\n",idx++,$0}
/^[ \t]+/{gsub(/<.*>/,"");gsub(/\(.*\)/,"");gsub(/^[ \t]+|[ \t]+$/,"");printf "    ├─ %s\n",$0}
' >> "$REPORT"; then
   echo "⚠️  cflow 未安装或解析失败，已跳过调用树"
fi

# 4. 生成符号列表（中文归类，一行三列）
echo "🔄 生成符号列表 ..."
ctags --output-format=json \
  --kinds-c=+c+d+e+f+g+l+m+n+p+s+t+u+v+x \
  --kinds-c++=+c+d+e+f+g+l+m+n+p+s+t+u+v+x \
  --fields=+iafkmnsSt \
  --extras=+F+q+r \
  "$SRC" 2>/dev/null \
| jq -r 'select(.name|startswith("__anon")|not)|(.kind+"\t"+.name)' \
| awk -v OFS="" '
BEGIN{
  map["f"]="函数"; map["p"]="原型"; map["d"]="宏定义"
  map["s"]="结构体"; map["u"]="联合体"; map["e"]="枚举"
  map["g"]="枚举值"; map["t"]="类型"; map["v"]="变量"
  map["l"]="局部"; map["h"]="头文件"; map["x"]="外部变量"
}
{
  k=(($1 in map)?map[$1]:$1); list[k]=list[k] (list[k]?" ":"") $2
}
END{
  print "\n---\n## 二、符号列表"
  idx=0
  for(k in list){
    n=split(list[k],arr," ")
    printf "\n**%s**：\n",k
    for(i=1;i<=n;i++){
      idx++
      printf " %2d. %-22s",idx,arr[i]
      if(i%3==0) printf "\n"
    }
    if(n%3) printf "\n"
  }
}' >> "$REPORT"

echo "✅ 中文分析报告已生成：$REPORT"
