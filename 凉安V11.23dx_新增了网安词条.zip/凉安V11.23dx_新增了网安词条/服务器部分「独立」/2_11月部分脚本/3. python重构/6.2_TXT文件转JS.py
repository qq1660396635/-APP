#!/usr/bin/env python3
import os
from datetime import datetime

def get_txt_file():
    """获取txt文件路径"""
    while True:
        file_path = input("请输入txt文件路径: ").strip()
        if not file_path:
            print("❌ 请输入文件路径")
            continue
            
        if not os.path.isfile(file_path):
            print(f"❌ 文件不存在: {file_path}")
            continue
            
        if not file_path.lower().endswith('.txt'):
            print("⚠️ 警告: 不是txt文件，但继续处理")
        
        return file_path

def get_var_prefix():
    """获取变量名前缀"""
    while True:
        prefix = input("请输入变量名前缀 (2-5个字符，如: repo, item, data): ").strip()
        if not prefix:
            print("⚠️ 使用默认前缀: item")
            return "item"
        
        # 验证前缀：2-5个字符，只能是字母、数字、下划线
        if len(prefix) < 2 or len(prefix) > 5:
            print("❌ 前缀长度必须是2-5个字符")
            continue
            
        if not all(c.isalnum() or c == '_' for c in prefix):
            print("❌ 前缀只能包含字母、数字和下划线")
            continue
            
        return prefix

def parse_line(line, idx):
    """解析一行内容，提取仓库名和描述"""
    line = line.strip()
    if not line:
        return None
    
    # 尝试分割仓库名和描述
    if ' ' in line:
        parts = line.split(' ', 1)
        repo = parts[0]
        desc = parts[1] if len(parts) > 1 else ""
    else:
        repo = line
        desc = ""
    
    return {
        'repo': repo,
        'desc': desc,
        'raw': line
    }

def esc(s):
    """转义 JS 字符串"""
    return s.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")

def main():
    # 获取txt文件路径
    txt_file = get_txt_file()
    target_dir = os.path.dirname(os.path.abspath(txt_file))
    print(f"📁 工作目录: {target_dir}")
    
    # 输出js文件路径
    js_file = os.path.join(target_dir, f"{os.path.splitext(os.path.basename(txt_file))[0]}.js")
    
    # 获取变量名前缀
    var_prefix = get_var_prefix()
    
    # 读取txt文件
    try:
        with open(txt_file, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
    except Exception as e:
        print(f"❌ 读取文件失败: {e}")
        return
    
    print(f"\n📖 读取到 {len(lines)} 行")
    
    # 生成JS变量
    js_vars = []
    valid_count = 0
    
    for idx, line in enumerate(lines, 1):
        parsed = parse_line(line, idx)
        if not parsed:
            continue
            
        var_name = f"{var_prefix}{idx:03d}"
        valid_count += 1
        
        js_var = f"""// [{idx:03d}] {parsed['repo']}
var {var_name} = {{
  index: {idx},
  repo: '{esc(parsed['repo'])}',
  desc: '{esc(parsed['desc'])}',
  raw: '{esc(parsed['raw'])}',
  type: 'github_repo'
}};"""
        
        js_vars.append(js_var)
        print(f"[{idx:03d}] {parsed['repo']} -> {var_name}")
    
    if not js_vars:
        print("❌ 没有有效内容")
        return
    
    # 生成数组
    array_name = f"{var_prefix}_list"
    array_code = f"\n// 所有项目的数组\nvar {array_name} = [{', '.join([f'{var_prefix}{i:03d}' for i in range(1, valid_count + 1)])}];"
    
    # 写入JS文件
    header = f"""// ==========================================
// 自动生成于 {datetime.now():%F %T}
// 源文件: {txt_file}
// 变量前缀: {var_prefix}
// 共 {valid_count} 个项目
// ==========================================

"""
    
    content = header + "\n\n".join(js_vars) + array_code
    
    try:
        with open(js_file, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"\n✅ 已生成: {js_file}")
        print(f"📊 统计: 共处理 {valid_count} 个项目")
        print(f"📝 数组变量: {array_name}")
    except Exception as e:
        print(f"❌ 写入文件失败: {e}")

if __name__ == "__main__":
    main()
