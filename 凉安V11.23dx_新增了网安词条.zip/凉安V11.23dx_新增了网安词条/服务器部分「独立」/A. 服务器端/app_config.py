import os

class AppConfig:
    # 服务器监听的主机地址，'0.0.0.0'表示监听所有网络接口
    HOST = '0.0.0.0'
    # 服务器监听的端口号
    PORT = 8080
    # 是否启用调试模式，生产环境建议设置为False
    DEBUG = False
    # 是否启用多线程处理请求
    THREADED = True
    
    # Shell执行器的路径，这里指向Termux的bash
    SHELL_PATH = '/data/data/com.termux/files/usr/bin/bash'
    # 启动Shell时传递的参数，-i表示交互式模式
    SHELL_ARGS = ['-i']
    # 缓冲区大小，0表示使用系统默认值
    BUFFER_SIZE = 0
    # Shell启动后的延迟时间（秒），确保Shell完全启动
    STARTUP_DELAY = 1
    
    # 命令执行超时时间（秒）
    COMMAND_TIMEOUT = 30
    # Server-Sent Events超时时间（秒）
    SSE_TIMEOUT = 1
    # Shell准备就绪的超时时间（秒）
    SHELL_READY_TIMEOUT = 5
    
    # 网络连接测试使用的IP地址
    TEST_CONNECTION_IP = '8.8.8.8'
    # 网络连接测试使用的端口号
    TEST_CONNECTION_PORT = 80
    
    # CORS跨域请求头设置
    CORS_HEADERS = {
        # 允许所有域名跨域访问
        'Access-Control-Allow-Origin': '*',
        # 允许的请求头
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        # 允许的HTTP方法
        'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,OPTIONS'
    }
    
    # 静态文件存放目录，'.'表示当前目录
    STATIC_FOLDER = '.'
    # 静态文件URL路径前缀，空字符串表示使用根路径
    STATIC_URL_PATH = ''
    # 复制当前环境变量
    ENV = os.environ.copy()
