需求    爬取91视频 学习网站
修改    输入地址。保存目录地址。  「视频地址可以在源码中获得。」
未完成  没有针对下载速度优化，没有对观看限额进行优化，   没有更换公网IP，换源等

一.  源码
ffmpeg -loglevel error -stats -progress pipe:1 \
  -user_agent "Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36" \
  -i "视频网站地址，18＋教学视频，未成年人不可观看「输入你自己的地址💊💊💊」" \
  -c copy \
  "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/2025-ouikk-4.mp4" 2>&1 | \
awk -F'=' '/^progress=end/ {print; fflush(); exit}
           /^progress=/    {print; fflush()}
           /^size=|^time=/ {printf "%s  ", $0; fflush()}' | \
while read -r line; do echo "$(date '+%H:%M:%S')  $line"; sleep 10; done


二.   代码解析
ffmpeg -loglevel error -stats -progress pipe:1 \
# ffmpeg: 多媒体处理工具
# -loglevel error: 只显示错误日志（error级别）
# -stats: 显示编码统计信息
# -progress pipe:1: 将进度信息输出到标准输出（管道1）
# \: 行续接符，表示命令继续到下一行

  -user_agent "Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36" \
  # -user_agent: 设置HTTP请求的User-Agent头部
  # "Mozilla/...": 模拟Android设备的浏览器标识
  # \: 行续接符

  -i "视频网站地址，18＋教学视频，未成年人不可观看「输入你自己的地址💊💊💊    " \
  # -i: 指定输入文件/URL
  # "https://...": HLS视频流的m3u8索引文件地址
  # \: 行续接符

  -c copy \
  # -c copy: 流复制模式（不重新编码，直接复制原始流）
  # \: 行续接符

  "/storage/emulated/0/Download/OnePlus Share/GITHUB 开源项目/项目01/脚本/2025-ouikk-4.mp4" 2>&1 | \
  # 输出文件路径（Android设备存储路径）
  # 2>&1: 将标准错误(stderr)重定向到标准输出(stdout)
  # |: 管道符，将前命令输出作为后命令输入

awk -F'=' '/^progress=end/ {print; fflush(); exit}
           # awk: 文本处理工具
           # -F'=': 设置字段分隔符为等号(=)
           # /^progress=end/: 匹配以"progress=end"开头的行
           # {print; fflush(); exit}: 打印该行，立即刷新缓冲区，然后退出awk

           /^progress=/    {print; fflush()}
           # /^progress=/: 匹配以"progress="开头的行（不含end）
           # {print; fflush()}: 打印该行并刷新缓冲区

           /^size=|^time=/ {printf "%s  ", $0; fflush()}' | \
           # /^size=|^time=/: 匹配以"size="或"time="开头的行
           # {printf "%s  ", $0}: 打印整行内容（末尾加两个空格）
           # fflush(): 立即刷新输出缓冲区
           # |: 管道符

while read -r line; do echo "$(date '+%H:%M:%S')  $line"; sleep 10; done
# while read -r line: 逐行读取输入（-r防止反斜杠转义）
# do...done: 循环体开始/结束
# echo "$(date '+%H:%M:%S')  $line": 打印当前时间(时:分:秒) + 行内容
# sleep 10: 每次循环暂停10秒（控制输出频率）

