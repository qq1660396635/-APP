# -*- coding: utf-8 -*-
"""
实时留言板服务器 (Flask版)
- 提供静态文件服务
- 接收前端提交的留言，并保存到 message.txt
- 自动维护 message.txt 只保留最新10条

服务端   cd "你的目录"    ， python server_flask.py
客户端   http://localhost:8080/
"""

from flask import Flask, request, abort, jsonify, send_file
import os
from datetime import datetime
import logging

# --- 服务器配置 ---
HOST = '0.0.0.0'
PORT = 8080
DATA_FILE = 'message.txt'  # 存储留言的文件
MAX_MESSAGES = 10          # 最大保留留言数

app = Flask(__name__)

# --- 路由定义 ---
@app.route('/')
def serve_index():
    """处理根路径请求，返回 index.html"""
    if not os.path.exists('index.html'):
        abort(404, "index.html not found. Please ensure it is in the same directory as server_flask.py")
    return send_file('index.html')

@app.route('/message.txt')
def serve_messages():
    """处理 /message.txt 请求，返回留言数据"""
    if not os.path.exists(DATA_FILE):
        return "" # 如果文件不存在，返回空字符串
    try:
        return send_file(DATA_FILE)
    except Exception as e:
        abort(500, description=f"Server Error: {e}")

@app.route('/submit', methods=['POST'])
def submit_message():
    """接收新留言，处理并保存到文件"""
    data = request.get_json()
    if not data or 'content' not in data:
        abort(400, description="Invalid request: missing content")

    content = data['content'].strip()
    if not content:
        abort(400, description="Content cannot be empty")

    # 1. 创建新留言行
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    new_line = f"{timestamp} | {content}\n"

    # 2. 读取现有所有行
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
    except FileNotFoundError:
        lines = []

    # 3. 追加新留言
    lines.append(new_line)

    # 4. 保留最新的 MAX_MESSAGES 条
    recent_lines = lines[-MAX_MESSAGES:]

    # 5. 重新写入文件，覆盖旧内容
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            f.writelines(recent_lines)
    except Exception as e:
        abort(500, description=f"Failed to save message: {e}")

    return jsonify({"status": "success", "message": "Message saved"})


# --- 辅助函数 ---
def get_local_ip():
    """获取本机IP地址"""
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

def print_startup_info(local_ip):
    """格式化并打印服务器启动信息"""
    separator = "=" * 60
    print(separator)
    print("🎯 实时留言板服务器启动成功！")
    print(separator)
    print("📱 访问方式：")
    print(f"   ▪ 本地访问: http://localhost:{PORT}")
    print(f"   ▪ 网络访问: http://{local_ip}:{PORT}")
    print()
    print("⚙️  服务器信息：")
    print(f"   ▪ 绑定地址: {HOST}")
    print(f"   ▪ 端口号: {PORT}")
    print(f"   ▪ 数据文件: {DATA_FILE} (最多保留{MAX_MESSAGES}条)")
    print()
    print("⏹️  停止服务：按 Ctrl + C")
    print(separator)

def main():
    """主函数"""
    # 如果数据文件不存在，创建一个空的
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            f.write("") # 创建空文件
        print(f"✅ 已创建空的数据文件: {DATA_FILE}")

    local_ip = get_local_ip()
    print_startup_info(local_ip)

    try:
        # 设置 Flask 的日志级别为 WARNING，以实现静默启动
        log = logging.getLogger('werkzeug')
        log.setLevel(logging.WARNING)

        # 使用标准方式启动服务器
        app.run(host=HOST, port=PORT, debug=False, use_reloader=False)

    except KeyboardInterrupt:
        print("\n🛑 服务器已停止")
    except Exception as e:
        print(f"\n❌ 服务器发生错误: {e}")

if __name__ == '__main__':
    main()
