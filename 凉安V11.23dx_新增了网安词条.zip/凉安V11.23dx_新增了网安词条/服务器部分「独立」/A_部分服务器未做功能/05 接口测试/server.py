from flask import Flask, render_template, jsonify, request
import requests
import json
import base64
from datetime import datetime

app = Flask(__name__)
app.template_folder = 'templates'

# 真实的免费API配置（无需密钥）
FREE_APIS = [
    {
        "id": 1, 
        "category": "图片", 
        "name": "随机猫咪图片", 
        "url": "https://api.thecatapi.com/v1/images/search",
        "params": {"limit": "1"},
        "type": "image",
        "description": "获取随机猫咪图片"
    },
    {
        "id": 2, 
        "category": "图片", 
        "name": "随机狗狗图片", 
        "url": "https://dog.ceo/api/breeds/image/random",
        "params": {},
        "type": "image",
        "description": "获取随机狗狗图片"
    },
    {
        "id": 3, 
        "category": "图片", 
        "name": "随机狐狸图片", 
        "url": "https://randomfox.ca/floof/",
        "params": {},
        "type": "image",
        "description": "获取随机狐狸图片"
    },
    {
        "id": 4, 
        "category": "用户数据", 
        "name": "随机用户信息", 
        "url": "https://randomuser.me/api/",
        "params": {"results": "1"},
        "type": "user",
        "description": "获取随机生成的用户信息（含头像）"
    },
    {
        "id": 5, 
        "category": "娱乐", 
        "name": "随机笑话", 
        "url": "https://official-joke-api.appspot.com/random_joke",
        "params": {},
        "type": "text",
        "description": "获取随机英文笑话"
    },
    {
        "id": 6, 
        "category": "名言", 
        "name": "随机名言", 
        "url": "https://api.quotable.io/random",
        "params": {"maxLength": "100"},
        "type": "quote",
        "description": "获取随机励志名言"
    },
    {
        "id": 7, 
        "category": "活动", 
        "name": "随机活动建议", 
        "url": "https://www.boredapi.com/api/activity",
        "params": {},
        "type": "activity",
        "description": "当你无聊时，获取一个活动建议"
    },
    {
        "id": 8, 
        "category": "IP信息", 
        "name": "IP地址信息", 
        "url": "https://ipapi.co/json/",
        "params": {},
        "type": "location",
        "description": "获取当前IP的地理位置信息"
    },
    {
        "id": 9, 
        "category": "天气", 
        "name": "天气预报", 
        "url": "https://api.open-meteo.com/v1/forecast",
        "params": {"latitude": "39.9042", "longitude": "116.4074", "current_weather": "true"},
        "type": "weather",
        "description": "获取北京当前天气"
    },
    {
        "id": 10, 
        "category": "测试", 
        "name": "JSON占位符-用户", 
        "url": "https://jsonplaceholder.typicode.com/users/1",
        "params": {},
        "type": "user",
        "description": "测试用的用户数据"
    },
    {
        "id": 11, 
        "category": "测试", 
        "name": "JSON占位符-文章", 
        "url": "https://jsonplaceholder.typicode.com/posts/1",
        "params": {},
        "type": "post",
        "description": "测试用的文章数据"
    },
    {
        "id": 12, 
        "category": "图片", 
        "name": "随机图片(400x300)", 
        "url": "https://picsum.photos/400/300",
        "params": {"random": ""},
        "type": "image",
        "description": "获取随机图片"
    },
    {
        "id": 13, 
        "category": "图片", 
        "name": "随机头像", 
        "url": "https://i.pravatar.cc/150",
        "params": {"u": "random"},
        "type": "image",
        "description": "获取随机头像"
    },
    {
        "id": 14, 
        "category": "图片", 
        "name": "随机艺术图片", 
        "url": "https://api.artic.edu/api/v1/artworks/search",
        "params": {"limit": "1", "fields": "id,title,image_id"},
        "type": "artwork",
        "description": "获取随机艺术作品"
    },
    {
        "id": 15, 
        "category": "节假日", 
        "name": "公共节假日", 
        "url": "https://date.nager.at/api/v3/NextPublicHolidays/CN",
        "params": {},
        "type": "holiday",
        "description": "获取中国下一个公共节假日"
    },
    {
        "id": 16, 
        "category": "图片", 
        "name": "随机风景图片", 
        "url": "https://source.unsplash.com/400x300/?landscape",
        "params": {},
        "type": "image",
        "description": "获取随机风景图片"
    },
    {
        "id": 17, 
        "category": "图片", 
        "name": "随机城市图片", 
        "url": "https://source.unsplash.com/400x300/?city",
        "params": {},
        "type": "image",
        "description": "获取随机城市图片"
    },
    {
        "id": 18, 
        "category": "图片", 
        "name": "随机自然图片", 
        "url": "https://source.unsplash.com/400x300/?nature",
        "params": {},
        "type": "image",
        "description": "获取随机自然图片"
    },
    {
        "id": 19, 
        "category": "测试", 
        "name": "JSON占位符-评论", 
        "url": "https://jsonplaceholder.typicode.com/comments/1",
        "params": {},
        "type": "comment",
        "description": "测试用的评论数据"
    },
    {
        "id": 20, 
        "category": "测试", 
        "name": "JSON占位符-相册", 
        "url": "https://jsonplaceholder.typicode.com/albums/1",
        "params": {},
        "type": "album",
        "description": "测试用的相册数据"
    }
]

def format_api_response(api_info, response_data, param):
    """格式化API响应数据"""
    try:
        if api_info["name"] == "随机猫咪图片":
            if response_data and len(response_data) > 0:
                cat = response_data[0]
                image_url = cat.get('url', '')
                return {
                    'type': 'image',
                    'title': '🐱 随机猫咪',
                    'image_url': image_url,
                    'content': f'''
                    <div class="image-result">
                        <img src="{image_url}" alt="随机猫咪" loading="lazy">
                        <div class="image-info">
                            <p><strong>ID:</strong> {cat.get('id', '未知')}</p>
                            <p><strong>尺寸:</strong> {cat.get('width', '未知')} x {cat.get('height', '未知')}</p>
                            <p><strong>链接:</strong> <a href="{image_url}" target="_blank">查看原图</a></p>
                        </div>
                    </div>
                    '''
                }
                
        elif api_info["name"] == "随机狗狗图片":
            image_url = response_data.get('message', '')
            return {
                'type': 'image',
                'title': '🐕 随机狗狗',
                'image_url': image_url,
                'content': f'''
                <div class="image-result">
                    <img src="{image_url}" alt="随机狗狗" loading="lazy">
                    <div class="image-info">
                        <p><strong>状态:</strong> {response_data.get('status', '未知')}</p>
                        <p><strong>链接:</strong> <a href="{image_url}" target="_blank">查看原图</a></p>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "随机狐狸图片":
            image_url = response_data.get('image', '')
            return {
                'type': 'image',
                'title': '🦊 随机狐狸',
                'image_url': image_url,
                'content': f'''
                <div class="image-result">
                    <img src="{image_url}" alt="随机狐狸" loading="lazy">
                    <div class="image-info">
                        <p><strong>链接:</strong> <a href="{image_url}" target="_blank">查看原图</a></p>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "随机用户信息":
            user = response_data.get("results", [{}])[0]
            name = user.get("name", {})
            location = user.get("location", {})
            picture = user.get("picture", {})
            dob = user.get("dob", {})
            registered = user.get("registered", {})
            return {
                'type': 'user',
                'title': '👤 随机用户',
                'image_url': picture.get('large', ''),
                'content': f'''
                <div class="user-result">
                    <div class="user-header">
                        <img src="{picture.get('large', '')}" alt="用户头像">
                        <div class="user-info">
                            <h3>{name.get('title', '')} {name.get('first', '')} {name.get('last', '')}</h3>
                            <p class="gender">{user.get('gender', '未知')}</p>
                        </div>
                    </div>
                    <div class="user-details">
                        <div class="detail-item">
                            <span class="icon">📧</span>
                            <span>{user.get('email', '')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="icon">📱</span>
                            <span>{user.get('phone', '')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="icon">🎂</span>
                            <span>{dob.get('date', '').split('T')[0]} ({dob.get('age', '')}岁)</span>
                        </div>
                        <div class="detail-item">
                            <span class="icon">📍</span>
                            <span>{location.get('street', {}).get('number', '')} {location.get('street', {}).get('name', '')}, {location.get('city', '')}, {location.get('state', '')}, {location.get('country', '')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="icon">📅</span>
                            <span>注册于 {registered.get('date', '').split('T')[0]}</span>
                        </div>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "随机笑话":
            return {
                'type': 'joke',
                'title': '😄 随机笑话',
                'content': f'''
                <div class="joke-result">
                    <div class="joke-type">类型: {response_data.get('type', '未知')}</div>
                    <div class="joke-setup">
                        <strong>Q:</strong> {response_data.get('setup', '')}
                    </div>
                    <div class="joke-punchline">
                        <strong>A:</strong> {response_data.get('punchline', '')}
                    </div>
                    <div class="joke-id">ID: {response_data.get('id', 0)}</div>
                </div>
                '''
            }
            
        elif api_info["name"] == "随机名言":
            return {
                'type': 'quote',
                'title': '💭 随机名言',
                'content': f'''
                <div class="quote-result">
                    <div class="quote-text">"{response_data.get('content', '')}"</div>
                    <div class="quote-author">— {response_data.get('author', '未知')}</div>
                    <div class="quote-meta">
                        <span>长度: {response_data.get('length', 0)} 字符</span>
                        <span>标签: {', '.join(response_data.get('tags', []))}</span>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "随机活动建议":
            return {
                'type': 'activity',
                'title': '🎯 活动建议',
                'content': f'''
                <div class="activity-result">
                    <div class="activity-name">{response_data.get('activity', '未知活动')}</div>
                    <div class="activity-details">
                        <div class="activity-item">
                            <span class="label">类型:</span>
                            <span class="value">{response_data.get('type', '未知')}</span>
                        </div>
                        <div class="activity-item">
                            <span class="label">参与人数:</span>
                            <span class="value">{response_data.get('participants', 0)} 人</span>
                        </div>
                        <div class="activity-item">
                            <span class="label">价格:</span>
                            <span class="value">{'免费' if response_data.get('price', 0) == 0 else f'¥{response_data.get("price", 0)}'}</span>
                        </div>
                        <div class="activity-item">
                            <span class="label">可及性:</span>
                            <span class="value">{response_data.get('accessibility', 0) * 100}%</span>
                        </div>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "IP地址信息":
            return {
                'type': 'location',
                'title': '🌐 IP地址信息',
                'content': f'''
                <div class="location-result">
                    <div class="location-header">
                        <h3>{response_data.get('ip', '未知IP')}</h3>
                        <p class="location-org">{response_data.get('org', '未知ISP')}</p>
                    </div>
                    <div class="location-details">
                        <div class="location-item">
                            <span class="icon">📍</span>
                            <div>
                                <strong>位置</strong><br>
                                {response_data.get('city', '')}, {response_data.get('region', '')}, {response_data.get('country_name', '')}
                            </div>
                        </div>
                        <div class="location-item">
                            <span class="icon">🌍</span>
                            <div>
                                <strong>坐标</strong><br>
                                {response_data.get('latitude', '')}, {response_data.get('longitude', '')}<br>
                                <small>时区: {response_data.get('timezone', '')}</small>
                            </div>
                        </div>
                        <div class="location-item">
                            <span class="icon">📞</span>
                            <div>
                                <strong>区号</strong><br>
                                {response_data.get('country_calling_code', '')} {response_data.get('area_code', '')}
                            </div>
                        </div>
                        <div class="location-item">
                            <span class="icon">💰</span>
                            <div>
                                <strong>货币</strong><br>
                                {response_data.get('currency_name', '')} ({response_data.get('currency', '')})
                            </div>
                        </div>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "天气预报":
            weather = response_data.get("current_weather", {})
            return {
                'type': 'weather',
                'title': '🌤️ 北京天气',
                'content': f'''
                <div class="weather-result">
                    <div class="weather-main">
                        <div class="temperature">{weather.get('temperature', '未知')}°C</div>
                        <div class="weather-desc">
                            <p>风速: {weather.get('windspeed', '未知')} m/s</p>
                            <p>风向: {weather.get('winddirection', '未知')}°</p>
                        </div>
                    </div>
                    <div class="weather-time">
                        更新时间: {weather.get('time', '未知')}
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "JSON占位符-用户":
            return {
                'type': 'user',
                'title': '👤 测试用户',
                'content': f'''
                <div class="user-result">
                    <div class="user-header">
                        <div class="user-info">
                            <h3>{response_data.get('name', '')}</h3>
                            <p class="username">@{response_data.get('username', '')}</p>
                        </div>
                    </div>
                    <div class="user-details">
                        <div class="detail-item">
                            <span class="icon">📧</span>
                            <span>{response_data.get('email', '')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="icon">📱</span>
                            <span>{response_data.get('phone', '')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="icon">🌐</span>
                            <span><a href="http://{response_data.get('website', '')}" target="_blank">{response_data.get('website', '')}</a></span>
                        </div>
                        <div class="detail-item">
                            <span class="icon">🏢</span>
                            <span>{response_data.get('company', {}).get('name', '')}</span>
                        </div>
                        <div class="detail-item">
                            <span class="icon">📍</span>
                            <span>{response_data.get('address', {}).get('suite', '')} {response_data.get('address', {}).get('street', '')}, {response_data.get('address', {}).get('city', '')}</span>
                        </div>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "JSON占位符-文章":
            return {
                'type': 'post',
                'title': '📝 测试文章',
                'content': f'''
                <div class="post-result">
                    <h3>{response_data.get('title', '')}</h3>
                    <div class="post-body">
                        {response_data.get('body', '')}
                    </div>
                    <div class="post-meta">
                        <span>文章ID: {response_data.get('id', '')}</span>
                        <span>用户ID: {response_data.get('userId', '')}</span>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] in ["随机图片(400x300)", "随机风景图片", "随机城市图片", "随机自然图片"]:
            return {
                'type': 'image',
                'title': f'🖼️ {api_info["name"]}',
                'image_url': response_data if isinstance(response_data, str) else api_info["url"],
                'content': f'''
                <div class="image-result">
                    <img src="{response_data if isinstance(response_data, str) else api_info['url']}" alt="随机图片" loading="lazy">
                    <div class="image-info">
                        <p><strong>类型:</strong> {api_info["name"]}</p>
                        <p><strong>链接:</strong> <a href="{response_data if isinstance(response_data, str) else api_info['url']}" target="_blank">查看原图</a></p>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "随机头像":
            return {
                'type': 'image',
                'title': '👤 随机头像',
                'image_url': response_data,
                'content': f'''
                <div class="image-result">
                    <img src="{response_data}" alt="随机头像" loading="lazy" style="width: 150px; height: 150px; border-radius: 50%;">
                    <div class="image-info">
                        <p><strong>尺寸:</strong> 150x150</p>
                        <p><strong>链接:</strong> <a href="{response_data}" target="_blank">查看原图</a></p>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "随机艺术图片":
            if response_data.get("data") and len(response_data["data"]) > 0:
                artwork = response_data["data"][0]
                image_id = artwork.get("image_id", "")
                image_url = f"https://www.artic.edu/iiif/2/{image_id}/full/843,/0/default.jpg"
                return {
                    'type': 'artwork',
                    'title': '🎨 随机艺术作品',
                    'image_url': image_url,
                    'content': f'''
                    <div class="artwork-result">
                        <img src="{image_url}" alt="艺术作品" loading="lazy">
                        <div class="artwork-info">
                            <h3>{artwork.get('title', '未知作品')}</h3>
                            <p><strong>ID:</strong> {artwork.get('id', '未知')}</p>
                            <p><strong>图片ID:</strong> {image_id}</p>
                            <p><a href="https://www.artic.edu/artworks/{artwork.get('id', '')}" target="_blank">查看详情</a></p>
                        </div>
                    </div>
                    '''
                }
            
        elif api_info["name"] == "公共节假日":
            if response_data and len(response_data) > 0:
                holiday = response_data[0]
                return {
                    'type': 'holiday',
                    'title': '🎉 下一个公共节假日',
                    'content': f'''
                    <div class="holiday-result">
                        <div class="holiday-name">{holiday.get('name', '未知')}</div>
                        <div class="holiday-date">{holiday.get('date', '未知')}</div>
                        <div class="holiday-details">
                            <p><strong>国家:</strong> {holiday.get('countryCode', '未知')}</p>
                            <p><strong>固定日期:</strong> {'是' if holiday.get('fixed', False) else '否'}</p>
                            <p><strong>全球性:</strong> {'是' if holiday.get('global', False) else '否'}</p>
                            {f'<p><strong>各州:</strong> {", ".join(holiday.get("launchYear", []))}</p>' if holiday.get('launchYear') else ''}
                        </div>
                    </div>
                    '''
                }
                
        elif api_info["name"] == "JSON占位符-评论":
            return {
                'type': 'comment',
                'title': '💬 测试评论',
                'content': f'''
                <div class="comment-result">
                    <div class="comment-header">
                        <strong>{response_data.get('name', '')}</strong>
                        <span class="comment-email">{response_data.get('email', '')}</span>
                    </div>
                    <div class="comment-body">
                        {response_data.get('body', '')}
                    </div>
                    <div class="comment-meta">
                        <span>评论ID: {response_data.get('id', '')}</span>
                        <span>文章ID: {response_data.get('postId', '')}</span>
                    </div>
                </div>
                '''
            }
            
        elif api_info["name"] == "JSON占位符-相册":
            return {
                'type': 'album',
                'title': '📁 测试相册',
                'content': f'''
                <div class="album-result">
                    <h3>{response_data.get('title', '')}</h3>
                    <div class="album-meta">
                        <p><strong>相册ID:</strong> {response_data.get('id', '')}</p>
                        <p><strong>用户ID:</strong> {response_data.get('userId', '')}</p>
                    </div>
                </div>
                '''
            }
            
        else:
            # 默认格式化
            return {
                'type': 'json',
                'title': '📄 API响应',
                'content': f'''
                <div class="json-result">
                    <pre>{json.dumps(response_data, indent=2, ensure_ascii=False)}</pre>
                </div>
                '''
            }
            
    except Exception as e:
        return {
            'type': 'error',
            'title': '❌ 解析错误',
            'content': f'''
            <div class="error-result">
                <p><strong>错误信息:</strong> {str(e)}</p>
                <p><strong>原始数据:</strong></p>
                <pre>{str(response_data)[:500]}</pre>
            </div>
            '''
        }

def call_real_api(api_info, param=""):
    """调用真实的API"""
    try:
        # 构建请求参数
        params = api_info.get("params", {})
        
        # 如果有自定义参数，添加到请求中
        if param and api_info["name"] in ["JSON占位符-用户", "JSON占位符-文章", "JSON占位符-评论", "JSON占位符-相册", "JSON占位符-照片", "JSON占位符-待办"]:
            # 对于JSONPlaceholder，可以改变ID
            try:
                api_id = int(param) if param else 1
                url = api_info["url"].rsplit('/', 1)[0] + f"/{api_id}"
            except:
                url = api_info["url"]
        else:
            url = api_info["url"]
        
        # 发送请求
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        response = requests.get(url, params=params, timeout=10, headers=headers)
        
        if response.status_code == 200:
            try:
                data = response.json()
                formatted = format_api_response(api_info, data, param)
                return {
                    'status': 'success',
                    'status_code': response.status_code,
                    'response_time': round(response.elapsed.total_seconds(), 2),
                    'formatted_data': formatted,
                    'raw_data': data
                }
            except:
                # 对于直接返回图片的API
                if 'image' in response.headers.get('content-type', ''):
                    return {
                        'status': 'success',
                        'status_code': response.status_code,
                        'response_time': round(response.elapsed.total_seconds(), 2),
                        'formatted_data': {
                            'type': 'image',
                            'title': f'🖼️ {api_info["name"]}',
                            'image_url': url,
                            'content': f'<img src="{url}" alt="图片" style="max-width: 100%;">'
                        },
                        'raw_data': url
                    }
                else:
                    return {
                        'status': 'success',
                        'status_code': response.status_code,
                        'response_time': round(response.elapsed.total_seconds(), 2),
                        'formatted_data': {
                            'type': 'text',
                            'title': '📄 文本响应',
                            'content': f'<pre>{response.text[:500]}</pre>'
                        },
                        'raw_data': response.text
                    }
        else:
            return {
                'status': 'failed',
                'status_code': response.status_code,
                'error': f"HTTP {response.status_code}: {response.text[:200]}"
            }
            
    except Exception as e:
        return {
            'status': 'error',
            'error': str(e)
        }

@app.route('/')
def index():
    """返回主页面"""
    return render_template('index.html', apis=FREE_APIS)

@app.route('/test_single', methods=['POST'])
def test_single():
    """测试单个API"""
    try:
        data = request.json
        api_id = data.get('id')
        param = data.get('param', '')
        
        # 找到对应的API信息
        api_info = next((api for api in FREE_APIS if api['id'] == api_id), None)
        if not api_info:
            return jsonify({'status': 'error', 'error': 'API not found'}), 404
        
        # 调用真实API
        result = call_real_api(api_info, param)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'status': 'error', 'error': str(e)}), 500

@app.route('/favicon.ico')
def favicon():
    return '', 204

if __name__ == '__main__':
    app.run(debug=True, port=8080, host='0.0.0.0')
