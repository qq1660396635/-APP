from flask import Flask, request, jsonify, send_from_directory
import random

app = Flask(__name__)

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<filename>')
def static_files(filename):
    return send_from_directory('.', filename)

@app.route('/hit', methods=['POST'])
def hit():
    score = random.randint(10, 100)
    comments = [
        "啪！好响！",
        "哇！这一下很重！",
        "啪啪啪！连击！",
        "哇塞！力道十足！",
        "啪！完美一击！",
        "哎呀！好疼！",
        "啪！清脆响亮！",
        "哇！技术不错！"
    ]
    comment = random.choice(comments)
    
    return jsonify({
        'score': score,
        'comment': comment
    })

if __name__ == '__main__':
    print("🎮 打屁股游戏启动成功！")
    print("📱 请在浏览器中访问: http://localhost:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)
