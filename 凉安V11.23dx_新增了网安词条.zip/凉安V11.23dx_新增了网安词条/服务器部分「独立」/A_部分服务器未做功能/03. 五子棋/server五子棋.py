from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__)

# ============================================================================
# 大任务一：服务器基础配置
# ============================================================================

# 小逻辑1：CORS跨域处理
@app.after_request
def after_request(response):
    """处理跨域请求，允许前端访问API"""
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# 小逻辑2：静态文件服务
@app.route('/')
def index():
    """提供游戏主页"""
    return send_from_directory('.', 'index.html')

@app.route('/<path:filename>')
def serve_static(filename):
    """提供静态资源文件"""
    return send_from_directory('.', filename)

# 小逻辑3：服务器启动提示
def print_server_info():
    """打印服务器启动信息和访问地址"""
    print("=" * 50)
    print("🎯 五子棋AI服务器启动成功！")
    print("=" * 50)
    print("📱 服务器提供算法的API地址：")
    print("   http://localhost:5000/api/best_move")
    print("   http://localhost:5000/api/check_winner")
    print("")
    print("🎮 游戏页面访问地址：")
    print("   http://localhost:5000")
    print("=" * 50)
    print("按 Ctrl+C 停止服务器")
    print("=" * 50)

# ============================================================================
# 大任务二：五子棋AI算法核心
# ============================================================================

class GomokuAI:
    """五子棋AI算法类"""
    
    def __init__(self):
        self.board_size = 15
        
    # 小逻辑1：胜负判断
    def check_winner(self, board, row, col, player):
        """检查指定位置是否形成五子连珠"""
        directions = [(1,0), (0,1), (1,1), (1,-1)]  # 四个方向：横、竖、正斜、反斜
        
        for dx, dy in directions:
            count = 1
            # 正向检查
            for i in range(1, 5):
                nx, ny = row + dx*i, col + dy*i
                if 0 <= nx < self.board_size and 0 <= ny < self.board_size and board[nx][ny] == player:
                    count += 1
                else:
                    break
            # 反向检查
            for i in range(1, 5):
                nx, ny = row - dx*i, col - dy*i
                if 0 <= nx < self.board_size and 0 <= ny < self.board_size and board[nx][ny] == player:
                    count += 1
                else:
                    break
            if count >= 5:
                return True
        return False
        
    # 小逻辑2：位置评估
    def evaluate_position(self, board, row, col, player):
        """评估某个位置的战术价值"""
        if not (0 <= row < self.board_size and 0 <= col < self.board_size) or board[row][col] != 0:
            return -1
            
        score = 0
        directions = [(1,0), (0,1), (1,1), (1,-1)]
        
        for dx, dy in directions:
            line_count = 0
            block_count = 0
            
            # 正向扫描
            for i in range(1, 5):
                nx, ny = row + dx*i, col + dy*i
                if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                    if board[nx][ny] == player:
                        line_count += 1
                    elif board[nx][ny] == 0:
                        break
                    else:
                        block_count += 1
                        break
                else:
                    block_count += 1
                    break
                    
            # 反向扫描
            for i in range(1, 5):
                nx, ny = row - dx*i, col - dy*i
                if 0 <= nx < self.board_size and 0 <= ny < self.board_size:
                    if board[nx][ny] == player:
                        line_count += 1
                    elif board[nx][ny] == 0:
                        break
                    else:
                        block_count += 1
                        break
                else:
                    block_count += 1
                    break
                    
            # 根据连子数和封堵情况评分
            if line_count >= 4:
                score += 10000  # 五连
            elif line_count == 3:
                if block_count == 0:
                    score += 1000  # 活四
                elif block_count == 1:
                    score += 100   # 冲四
            elif line_count == 2:
                if block_count == 0:
                    score += 100   # 活三
                elif block_count == 1:
                    score += 10    # 眠三
            elif line_count == 1:
                if block_count == 0:
                    score += 10    # 活二
                    
        return score
        
    # 小逻辑3：最佳落子决策
    def get_best_move(self, board):
        """通过局势分析获取最佳落子位置"""
        best_score = -1
        best_move = None
        
        # 优先级1：检查是否能直接获胜
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    board[i][j] = 2  # AI是白棋
                    if self.check_winner(board, i, j, 2):
                        board[i][j] = 0
                        return {'row': i, 'col': j}
                    board[i][j] = 0
                    
        # 优先级2：检查是否需要阻止对手获胜
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    board[i][j] = 1  # 玩家是黑棋
                    if self.check_winner(board, i, j, 1):
                        board[i][j] = 0
                        return {'row': i, 'col': j}
                    board[i][j] = 0
                    
        # 优先级3：评估所有位置的战术价值
        for i in range(self.board_size):
            for j in range(self.board_size):
                if board[i][j] == 0:
                    # 进攻评分
                    attack_score = self.evaluate_position(board, i, j, 2)
                    # 防守评分（权重0.8）
                    defense_score = self.evaluate_position(board, i, j, 1) * 0.8
                    # 综合评分
                    total_score = attack_score + defense_score
                    
                    if total_score > best_score:
                        best_score = total_score
                        best_move = {'row': i, 'col': j}
                        
        # 优先级4：选择中心附近位置（开局策略）
        if best_move is None:
            center = self.board_size // 2
            for i in range(max(0, center-2), min(self.board_size, center+3)):
                for j in range(max(0, center-2), min(self.board_size, center+3)):
                    if board[i][j] == 0:
                        return {'row': i, 'col': j}
                        
        return best_move

# ============================================================================
# 大任务三：API接口路由
# ============================================================================

# 创建AI实例
ai = GomokuAI()

# 小逻辑1：最佳落子API
@app.route('/api/best_move', methods=['POST'])
def get_best_move():
    """提供AI最佳落子位置的API接口"""
    data = request.json
    board = data.get('board', [])
    
    # 验证棋盘数据
    if not board or len(board) != 15:
        return jsonify({'error': '无效的棋盘数据'}), 400
        
    # 获取AI推荐的最佳落子
    best_move = ai.get_best_move(board)
    
    if best_move:
        return jsonify({
            'success': True,
            'move': best_move
        })
    else:
        return jsonify({
            'success': False,
            'error': '没有可落子的位置'
        }), 400

# 小逻辑2：胜负判断API
@app.route('/api/check_winner', methods=['POST'])
def check_winner():
    """检查游戏胜负状态的API接口"""
    data = request.json
    board = data.get('board', [])
    last_move = data.get('last_move', {})
    
    # 验证必要参数
    if not board or not last_move:
        return jsonify({'error': '缺少必要参数'}), 400
        
    row = last_move.get('row')
    col = last_move.get('col')
    player = last_move.get('player')
    
    if row is None or col is None or player is None:
        return jsonify({'error': '落子信息不完整'}), 400
        
    # 调用AI判断胜负
    winner = ai.check_winner(board, row, col, player)
    
    return jsonify({
        'success': True,
        'winner': player if winner else 0
    })

# ============================================================================
# 大任务四：主程序入口
# ============================================================================

def main():
    """主程序入口函数"""
    # 打印服务器信息
    print_server_info()
    # 启动Flask应用
    app.run(debug=True, host='0.0.0.0', port=5000)

if __name__ == '__main__':
    main()
